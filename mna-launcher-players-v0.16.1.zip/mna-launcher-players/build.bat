@echo off
cd /d "%~dp0"
set CSC_IDENTITY_AUTO_DISCOVERY=false
echo === Installing (needs internet, 2-5 min) ===
call npm install || goto err
echo === Building MNA-Launcher.exe ===
call npm run build || goto err
echo.
echo DONE: dist\MNA-Launcher.exe
explorer dist
pause
exit /b
:err
echo ERROR. If you see "symbolic link" - run build.bat as Administrator.
pause
