'use strict';
// Распаковка и упаковка zip без внешних программ (работает одинаково на Windows, macOS и Linux).
// Защита: запрещены пути с «..» и абсолютные пути, проверяется CRC32, символьные ссылки пропускаются.
const fs = require('fs'), path = require('path'), zlib = require('zlib');

const T = new Uint32Array(256);
for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; T[n] = c >>> 0; }
function crc32(buf) { let c = 0xFFFFFFFF; for (let i = 0; i < buf.length; i++) c = T[(c ^ buf[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }

function readFull(fd, buf, pos) {
  let got = 0;
  while (got < buf.length) { const n = fs.readSync(fd, buf, got, buf.length - got, pos + got); if (!n) throw new Error('zip обрезан'); got += n; }
  return buf;
}
function central(fd, size) {
  const back = Math.min(size, 65557), tail = readFull(fd, Buffer.alloc(back), size - back);
  const i = tail.lastIndexOf(Buffer.from([0x50, 0x4b, 0x05, 0x06]));
  if (i < 0) throw new Error('это не zip-архив или он повреждён');
  const total = tail.readUInt16LE(i + 10), cdSize = tail.readUInt32LE(i + 12), cdOff = tail.readUInt32LE(i + 16);
  if (total === 0xFFFF || cdSize === 0xFFFFFFFF || cdOff === 0xFFFFFFFF) throw new Error('zip64 не поддерживается');
  const cd = readFull(fd, Buffer.alloc(cdSize), cdOff), out = [];
  for (let p = 0; p + 46 <= cd.length && cd.readUInt32LE(p) === 0x02014b50;) {
    const nl = cd.readUInt16LE(p + 28), el = cd.readUInt16LE(p + 30), cl = cd.readUInt16LE(p + 32);
    out.push({
      madeBy: cd.readUInt16LE(p + 4), flags: cd.readUInt16LE(p + 8), method: cd.readUInt16LE(p + 10), crc: cd.readUInt32LE(p + 16),
      csize: cd.readUInt32LE(p + 20), usize: cd.readUInt32LE(p + 24), attr: cd.readUInt32LE(p + 38), off: cd.readUInt32LE(p + 42),
      name: cd.toString('utf8', p + 46, p + 46 + nl)
    });
    p += 46 + nl + el + cl;
  }
  return out;
}
function safeName(raw) {
  const n = String(raw).replace(/\\/g, '/');
  if (n.includes('\0') || n.startsWith('/') || /^[A-Za-z]:/.test(n) || n.split('/').includes('..')) throw new Error('небезопасный путь в архиве: ' + raw);
  return n;
}
function data(fd, e) {
  if (e.flags & 1) throw new Error('архив зашифрован');
  if (e.usize > 1.5 * 2 ** 30) throw new Error('файл в архиве слишком большой: ' + e.name);
  const lh = readFull(fd, Buffer.alloc(30), e.off);
  if (lh.readUInt32LE(0) !== 0x04034b50) throw new Error('zip повреждён (заголовок файла)');
  const raw = readFull(fd, Buffer.alloc(e.csize), e.off + 30 + lh.readUInt16LE(26) + lh.readUInt16LE(28));
  let out;
  if (e.method === 0) out = raw; else if (e.method === 8) out = zlib.inflateRawSync(raw); else throw new Error('метод сжатия ' + e.method + ' не поддерживается');
  if (out.length !== e.usize || crc32(out) !== e.crc) throw new Error('zip повреждён (контрольная сумма): ' + e.name);
  return out;
}
const inside = (dir, t) => { const d = path.resolve(dir), x = path.resolve(t); return x === d || x.startsWith(d + path.sep); };

// Распаковать. opts.map(name) → новое имя или null (пропустить). Возвращает список записанных файлов.
function extractZip(file, dest, opts = {}) {
  const fd = fs.openSync(file, 'r'), written = [];
  try {
    const root = path.resolve(dest), list = central(fd, fs.fstatSync(fd).size);
    for (const e of list) safeName(e.name); // сначала проверяем все имена, и только потом пишем на диск
    fs.mkdirSync(root, { recursive: true });
    for (const e of list) {
      let name = safeName(e.name), isDir = name.endsWith('/');
      if (opts.map) { name = opts.map(name); if (name == null) continue; name = safeName(name); }
      if (!name || name === '/') continue;
      const target = path.join(root, name);
      if (!inside(root, target)) throw new Error('небезопасный путь в архиве: ' + e.name);
      const unix = (e.madeBy >> 8) === 3, mode = e.attr >>> 16;
      if (unix && (mode & 0o170000) === 0o120000) continue;
      if (isDir) { fs.mkdirSync(target, { recursive: true }); continue; }
      const buf = data(fd, e);
      fs.mkdirSync(path.dirname(target), { recursive: true }); fs.writeFileSync(target, buf);
      if (unix && process.platform !== 'win32' && (mode & 0o111)) { try { fs.chmodSync(target, mode & 0o777); } catch {} }
      written.push(name);
    }
  } finally { fs.closeSync(fd); }
  return written;
}
// Прочитать один файл из архива (или null).
function readZipFile(file, name) {
  const fd = fs.openSync(file, 'r');
  try { const e = central(fd, fs.fstatSync(fd).size).find(x => safeName(x.name) === name); return e ? data(fd, e) : null; }
  finally { fs.closeSync(fd); }
}

// Упаковать папку srcDir в zip; внутри архива всё лежит под папкой prefix (например, имя мира).
function writeZip(dest, srcDir, prefix) {
  const fd = fs.openSync(dest, 'w'), cd = []; let off = 0, count = 0;
  const w = b => { fs.writeSync(fd, b); off += b.length; };
  const dosTime = d => ({ t: (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1), d: (Math.max(0, d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate() });
  const add = (name, buf, mtime) => {
    const nb = Buffer.from(name, 'utf8'), crc = buf ? crc32(buf) : 0, dt = dosTime(mtime || new Date());
    let comp = buf || Buffer.alloc(0), method = 0;
    if (buf && buf.length > 64) { const z = zlib.deflateRawSync(buf, { level: 6 }); if (z.length < buf.length) { comp = z; method = 8; } }
    if (off > 0xFFFFFF00 || count >= 0xFFFE || comp.length > 0xFFFFFF00) throw new Error('мир слишком большой для zip (нужен zip64)');
    const lh = Buffer.alloc(30); lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(0x800, 6); lh.writeUInt16LE(method, 8);
    lh.writeUInt16LE(dt.t, 10); lh.writeUInt16LE(dt.d, 12); lh.writeUInt32LE(crc, 14); lh.writeUInt32LE(comp.length, 18); lh.writeUInt32LE(buf ? buf.length : 0, 22); lh.writeUInt16LE(nb.length, 26);
    const c = Buffer.alloc(46); c.writeUInt32LE(0x02014b50, 0); c.writeUInt16LE(20, 4); c.writeUInt16LE(20, 6); c.writeUInt16LE(0x800, 8); c.writeUInt16LE(method, 10);
    c.writeUInt16LE(dt.t, 12); c.writeUInt16LE(dt.d, 14); c.writeUInt32LE(crc, 16); c.writeUInt32LE(comp.length, 20); c.writeUInt32LE(buf ? buf.length : 0, 24); c.writeUInt16LE(nb.length, 28);
    c.writeUInt32LE(buf ? 0 : 0x10, 38); c.writeUInt32LE(off, 42);
    cd.push(Buffer.concat([c, nb])); w(lh); w(nb); w(comp); count++;
  };
  try {
    const walk = (dir, rel) => {
      for (const f of fs.readdirSync(dir, { withFileTypes: true })) {
        const full = path.join(dir, f.name), r = rel + '/' + f.name;
        if (f.isDirectory()) { add(r + '/', null); walk(full, r); }
        else if (f.isFile()) { let b; try { b = fs.readFileSync(full); } catch { continue; } add(r, b, fs.statSync(full).mtime); }
      }
    };
    add(prefix + '/', null); walk(srcDir, prefix);
    const start = off, all = Buffer.concat(cd); w(all);
    const e = Buffer.alloc(22); e.writeUInt32LE(0x06054b50, 0); e.writeUInt16LE(count, 8); e.writeUInt16LE(count, 10); e.writeUInt32LE(all.length, 12); e.writeUInt32LE(start, 16);
    w(e);
  } finally { fs.closeSync(fd); }
  return count;
}

module.exports = { extractZip, readZipFile, writeZip, crc32 };
