'use strict';
// Сквозная проверка: настоящие main.js + index.html + Hub-сервер. Подменены только Electron, Minecraft и сеть до Modrinth/Forge.
// Запуск: NODE_PATH=$(npm root -g) node test/e2e.js   (нужны playwright с Chromium и python3/python)
const fs = require('fs'), os = require('os'), path = require('path'), http = require('http'), crypto = require('crypto'), assert = require('assert');
const { spawn, execFileSync, spawnSync } = require('child_process');
const EventEmitter = require('events');
const Module = require('module');
let chromium; try { ({ chromium } = require('playwright')); } catch { console.log('playwright не найден: сквозная проверка пропущена'); process.exit(0); }
const { Hub } = require('../hub.js');

const LAUNCHER = path.join(__dirname, '..'), HUBSRV = path.join(LAUNCHER, '..', 'mna-hub', 'server.js');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'mna-e2e-')), appData = path.join(tmp, 'appdata'), root = path.join(appData, '.mna');
fs.mkdirSync(root, { recursive: true });
let n = 0; const ok = s => { n++; console.log('  ✔', s); };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const PY = ['python3', 'python'].find(c => !spawnSync(c, ['--version'], { stdio: 'ignore' }).error);
const until = async (fn, ms = 8000, what = '') => { const t = Date.now(); for (;;) { const v = await fn(); if (v) return v; if (Date.now() - t > ms) throw new Error('не дождались: ' + what); await sleep(30); } };

// ---------- подмена Electron / Minecraft ----------
const zlib = require('zlib'), { crc32 } = require('../zip.js');
const handlers = new Map(), sent = [], notes = [], launches = [], icons = [], opened = []; let dialogResult = { canceled: true, filePaths: [] }; let theWin = null, focusFlag = false, pageSend = () => {}, trayMade = 0;
const mkImg = (b, w, h) => ({ isEmpty: () => !b || !b.length, getSize: () => ({ width: w, height: h }), resize(o) { const k = o.width ? o.width / w : o.height / h; return mkImg(b, Math.round(w * k), Math.round(h * k)); }, toPNG: () => b, toJPEG: () => b });
function mkPng(w, h, [r, g, bl]) { const raw = Buffer.alloc((w * 3 + 1) * h); for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const o = y * (w * 3 + 1) + 1 + x * 3; raw[o] = r; raw[o + 1] = g; raw[o + 2] = bl; } const ck = (t, d) => { const len = Buffer.alloc(4); len.writeUInt32BE(d.length); const td = Buffer.concat([Buffer.from(t), d]), c = Buffer.alloc(4); c.writeUInt32BE(crc32(td)); return Buffer.concat([len, td, c]); }; const ih = Buffer.alloc(13); ih.writeUInt32BE(w, 0); ih.writeUInt32BE(h, 4); ih[8] = 8; ih[9] = 2; return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), ck('IHDR', ih), ck('IDAT', zlib.deflateSync(raw)), ck('IEND', Buffer.alloc(0))]); }
class BW {
  constructor(o) { theWin = this; this.destroyed = false; this.icon = o && o.icon; this.webContents = { send: (ch, d) => { sent.push([ch, d]); pageSend(ch, d); }, focus() {}, isFocused: () => focusFlag }; }
  loadFile() {} on() {} isDestroyed() { return this.destroyed; } isFocused() { return focusFlag; } isMinimized() { return false; } show() {} setIcon(i) { icons.push(i); } focus() {} restore() {} minimize() {} destroy() { this.destroyed = true; }
}
class Notif { static isSupported() { return true; } constructor(o) { this.o = o; this.h = {}; } on(e, f) { this.h[e] = f; } show() { notes.push(this); } }
const electron = {
  app: { getPath: () => appData, getVersion: () => '0.17.0', setAppUserModelId() {}, requestSingleInstanceLock: () => true, whenReady: () => Promise.resolve(), on() {}, quit() {}, isPackaged: true, getAppPath: () => LAUNCHER },
  BrowserWindow: BW, ipcMain: { handle: (ch, fn) => handlers.set(ch, fn) }, shell: { openPath() {}, showItemInFolder() {}, openExternal(u) { opened.push(u); } }, dialog: { showOpenDialog: async () => dialogResult },
  safeStorage: { encryptString: s => Buffer.from('ENC' + s), decryptString: b => { const t = String(b); if (!t.startsWith('ENC')) throw new Error('bad'); return t.slice(3); } },
  Tray: class { constructor() { trayMade++; } setToolTip() {} setContextMenu() {} on() {} destroy() {} }, Menu: { buildFromTemplate: x => x },
  nativeImage: { createFromPath: p => { try { const b = fs.readFileSync(p); if (b.slice(1, 4).toString() === 'PNG') return mkImg(b, b.readUInt32BE(16), b.readUInt32BE(20)); if (b[0] === 0xff && b[1] === 0xd8) return mkImg(b, 1000, 600); } catch {} return mkImg(null, 0, 0); } }, Notification: Notif
};
class MCClient extends EventEmitter { launch(o) { launches.push({ o, client: this }); return Promise.resolve({ pid: 4242 }); } }
const origLoad = Module._load;
Module._load = function (req) {
  if (req === 'electron') return electron;
  if (req === 'minecraft-launcher-core') return { Client: MCClient, Authenticator: { getAuth: nick => ({ name: nick, access_token: 'x', uuid: 'u' }) } };
  if (req === 'msmc') return { Auth: class {} };
  return origLoad.apply(this, arguments);
};

// ---------- фальшивые внешние сайты (Modrinth CDN, Forge) ----------
const files = new Map(); // "host/path" -> Buffer
const fake = http.createServer((q, r) => { const b = files.get(q.headers['x-fake-host'] + q.url.split('?')[0]); if (!b) { r.writeHead(404); return r.end(); } r.writeHead(200); r.end(b); }).listen(0, '127.0.0.1');
const realFetch = global.fetch, FAKE = ['cdn.modrinth.com', 'files.minecraftforge.net', 'maven.minecraftforge.net'];
global.fetch = (u, o = {}) => { try { const x = new URL(String(u)); if (FAKE.includes(x.hostname)) return realFetch(`http://127.0.0.1:${fake.address().port}${x.pathname}${x.search}`, { ...o, headers: { ...(o.headers || {}), 'x-fake-host': x.hostname } }); } catch {} return realFetch(u, o); };
const sha = (a, b) => crypto.createHash(a).update(b).digest('hex');

(async () => {
  // Hub-сервер
  fs.mkdirSync(path.join(tmp, 'hubdata'), { recursive: true }); fs.writeFileSync(path.join(tmp, 'hubdata', 'config.json'), JSON.stringify({ buyUrls: { plus: 'https://pay.example.com/plus' } }));
  const hubProc = spawn(process.execPath, [HUBSRV], { env: { ...process.env, PORT: '0', HOST: '127.0.0.1', DATA_DIR: path.join(tmp, 'hubdata'), REG_CODE: 'code1', REG_PER_HOUR: '100', ADMIN_KEY: 'adm1' }, stdio: ['ignore', 'pipe', 'inherit'] });
  process.on('exit', () => { try { hubProc.kill(); } catch {} });
  const port = await new Promise((res, rej) => { hubProc.stdout.on('data', d => { const m = /:(\d+)/.exec(String(d)); if (m) res(+m[1]); }); hubProc.on('exit', c => rej(new Error('hub exit ' + c))); });
  const hubUrl = 'http://127.0.0.1:' + port;
  // «java»: скрипт-пустышка, который изображает установщик Forge
  const javaStub = path.join(tmp, 'java'); fs.writeFileSync(javaStub, '#!/bin/sh\nmkdir -p "$4/versions/1.20.1-forge-47.3.0" && echo \'{"id":"1.20.1-forge-47.3.0"}\' > "$4/versions/1.20.1-forge-47.3.0/1.20.1-forge-47.3.0.json"\n', { mode: 0o755 });
  fs.writeFileSync(path.join(root, 'config.json'), JSON.stringify({ hubUrl, java: javaStub, loader: 'vanilla', mc: '1.21.1', autover: false, onlaunch: 'none', featured: false, nick: 'Player' }));
  require('../main.js'); await sleep(100); assert(theWin && handlers.size > 40); ok(`main.js загружен: ${handlers.size} обработчиков, окно создано`);

  const browser = await chromium.launch(), page = await browser.newPage({ viewport: { width: 1180, height: 740 } });
  const pageErrors = []; page.on('pageerror', e => pageErrors.push(e.message));
  await page.exposeFunction('__invoke', async (ch, d) => { const h = handlers.get(ch); if (!h) throw new Error('нет обработчика ' + ch); return h({}, d); });
  await page.addInitScript(() => { window.__l = {}; window.mna = { invoke: (c, d) => window.__invoke(c, d), on: (c, f) => { (window.__l[c] = window.__l[c] || []).push(f); }, pathFor: () => '' }; });
  pageSend = (ch, d) => page.evaluate(([c, x]) => (window.__l[c] || []).forEach(f => f(x)), [ch, d]).catch(() => {});
  await page.goto('file://' + path.join(LAUNCHER, 'index.html'));
  const shot = async nm => { if (process.env.SHOTS) { fs.mkdirSync(process.env.SHOTS, { recursive: true }); await page.screenshot({ path: path.join(process.env.SHOTS, nm + '.png') }); } };
  const vis = sel => page.isVisible(sel), txt = sel => page.textContent(sel), tab = () => page.click('nav button:has-text("Друзья")');
  const flistHas = async s => (await txt('#flist')).includes(s);

  console.log('Вход и уникальные ники (интерфейс)');
  await tab(); await until(() => vis('#fgate'), 4000, 'форма входа'); await shot('1-login'); ok('без аккаунта вкладка «Друзья» показывает форму входа');
  await until(() => vis('#fcodew'), 4000, 'поле кода'); ok('сервер требует код приглашения, поле показано');
  await page.fill('#fnick', 'Anna_Real'); await until(async () => (await txt('#fnickst')).includes('свободен'), 3000, 'свободен'); ok('ник свободен: подсказка');
  await page.fill('#fpass', 'secret12'); await page.click('#freg'); await until(async () => (await txt('#ferr')).includes('код'), 3000, 'ошибка кода'); ok('регистрация без кода: понятная ошибка');
  const clone = new Hub({}); clone.configure(hubUrl); await clone.register('Zed_One', 'secret12', 'code1');
  await page.fill('#fcode', 'code1'); await page.fill('#fnick', 'zed_one'); await until(async () => (await txt('#fnickst')).includes('занят'), 3000, 'занят'); ok('чужой ник (в другом регистре) показан как занятый');
  await page.click('#freg'); await until(async () => (await txt('#ferr')).includes('занят'), 3000, 'ошибка занят'); ok('занять чужой ник нельзя');
  await clone.logout();
  await page.fill('#fnick', 'Anna_Real'); await page.click('#freg'); await until(() => vis('#fmain'), 5000, 'вход выполнен');
  assert.strictEqual((await txt('#fmen')).trim(), 'Anna_Real'); assert.strictEqual((await txt('#who')).trim(), 'Anna_Real'); assert(await page.isDisabled('#nick')); assert.strictEqual(await page.inputValue('#nick'), 'Anna_Real'); ok('аккаунт создан, ник закреплён, поле ника в настройках заблокировано');
  assert(fs.existsSync(path.join(root, 'hub.bin'))); assert(!fs.readFileSync(path.join(root, 'hub.bin'), 'latin1').includes('secret12')); ok('сессия сохранена в зашифрованном файле, пароля там нет');

  console.log('Друзья, статусы, чат');
  const B = new Hub({}), evB = []; B.configure(hubUrl); B.on('event', e => evB.push(e)); await B.register('Boris', 'secret12', 'code1'); await until(() => B.connected, 4000, 'B онлайн');
  const aId = (await B.request('anna_real'), (await B.friends()).outgoing[0].id);
  await until(() => vis('#freqc'), 4000, 'заявка'); assert((await txt('#freq')).includes('Boris')); await until(async () => (await txt('nav')).includes('1'), 3000, 'значок'); ok('входящая заявка видна, на вкладке счётчик');
  assert(notes.some(x => x.o.title === 'Заявка в друзья' && x.o.body.includes('Boris'))); ok('пришло уведомление о заявке');
  await page.click('#freq button[data-a]'); await until(() => flistHas('Boris'), 4000, 'друг в списке'); assert((await txt('#flist')).includes('в сети')); await shot('2-list'); ok('заявка принята, Boris в списке и «в сети»');
  B.setPresence('ingame', 'mc.test.net'); await until(() => flistHas('играет на mc.test.net'), 4000, 'играет'); assert(await page.$('#flist button[data-j="mc.test.net"]')); ok('статус «играет на сервере» и кнопка «К другу»');
  const before = notes.length; await B.send(aId, 'привет, Anna!');
  await until(async () => (await txt('#flist .bdg')) === '1', 4000, 'непрочитанное'); await until(() => notes.length > before, 3000, 'уведомление');
  const nt = notes[notes.length - 1].o; assert.strictEqual(nt.title, 'Boris'); assert.strictEqual(nt.body, 'привет, Anna!'); ok('сообщение при закрытом чате: счётчик и уведомление');
  await page.click('#flist .item .t'); await until(() => vis('#fchat'), 3000, 'чат'); await until(async () => (await txt('#fmsgs')).includes('привет, Anna!'), 3000, 'история');
  await until(async () => (await handlers.get('hub:snapshot')({}, {})).friends.friends[0].unread === 0, 3000, 'прочитано'); ok('чат открыт, история показана, непрочитанное сброшено');
  await page.fill('#fmsg', 'ответ от Anna'); await page.press('#fmsg', 'Enter'); await until(() => evB.find(e => e.type === 'message' && e.data.text === 'ответ от Anna'), 3000, 'B получил'); ok('сообщение из интерфейса дошло до друга');
  focusFlag = true; const n2 = notes.length; await B.send(aId, 'ты тут?');
  await until(async () => (await txt('#fmsgs')).includes('ты тут?'), 3000, 'в открытом чате'); await sleep(300); assert.strictEqual(notes.length, n2); assert.strictEqual((await handlers.get('hub:snapshot')({}, {})).friends.friends[0].unread, 0); ok('в открытом и активном чате: без уведомления и без непрочитанного');

  console.log('Приглашение и запуск игры');
  await B.invite(aId, 'play.test.net:25565', 'го на ферму');
  await until(async () => (await txt('#fmsgs')).includes('play.test.net:25565'), 3000, 'invite в чате'); assert(await page.$('#fmsgs button[data-j="play.test.net:25565"]')); assert.strictEqual((await page.$$('#invbar .inv')).length, 0); await shot('4-chat'); ok('приглашение в открытом чате: кнопка «Присоединиться», баннера нет');
  focusFlag = false; await page.click('#fback'); await B.invite(aId, 'srv.test.org', 'ещё раз');
  await until(async () => (await page.$$('#invbar .inv')).length === 1, 3000, 'баннер'); assert((await txt('#invbar')).includes('srv.test.org')); assert(notes.some(x => /приглашает в игру/.test(x.o.title) && x.o.body.includes('srv.test.org'))); ok('приглашение при закрытом чате: баннер поверх интерфейса и уведомление');
  await shot('5-invite-banner'); await page.click('#invbar button[data-y]');
  await until(() => launches.length === 1, 6000, 'запуск'); const L = launches[0].o;
  assert.strictEqual(L.quickPlay.identifier, 'srv.test.org'); assert.strictEqual(L.quickPlay.type, 'multiplayer'); assert.strictEqual(L.authorization.name, 'Anna_Real'); ok('«Играть» в приглашении запускает игру сразу на сервере друга, ник берётся из аккаунта (не из настроек)');
  const pe = await until(() => evB.find(e => e.type === 'presence' && e.data.id === aId && e.data.state === 'ingame' && e.data.server === 'srv.test.org'), 4000, 'presence'); ok('друг видит, что Anna играет на srv.test.org');
  assert.strictEqual(await handlers.get('play')({}, 'other.net'), false); assert(sent.some(([c, d]) => c === 'status' && /уже запущена/.test(d))); ok('вторая игра при запущенной не стартует');
  launches[0].client.emit('close'); await until(() => evB.find(e => e.type === 'presence' && e.data.id === aId && e.data.state === 'online' && e.data.server === ''), 4000, 'вернулся online'); ok('после выхода из игры статус снова «в сети»');

  console.log('Выход и требование аккаунта');
  await tab(); await page.click('#flogout'); await page.click('#my'); await until(() => vis('#fgate'), 4000, 'форма после выхода'); assert(!fs.existsSync(path.join(root, 'hub.bin'))); ok('выход: форма входа вернулась, файл сессии удалён');
  sent.length = 0; await page.click('nav button:first-child'); await page.click('#play'); await until(() => sent.some(([c, d]) => c === 'status' && /Войди в аккаунт MNA/.test(d)), 4000, 'отказ'); assert.strictEqual(launches.length, 1); ok('без аккаунта и без Microsoft запуск запрещён (ники уникальны)');
  await tab(); await page.fill('#fnick', 'Anna_Real'); await page.fill('#fpass', 'wrong-pass'); await page.click('#flogin'); await until(async () => (await txt('#ferr')).includes('Неверный'), 3000, 'неверный пароль'); ok('чужой пароль к чужому нику не подходит');
  await page.fill('#fpass', 'secret12'); await page.click('#flogin'); await until(() => vis('#fmain'), 4000, 'повторный вход'); await until(() => flistHas('Boris'), 4000, 'друзья после входа'); ok('повторный вход: друзья на месте');
  assert.deepStrictEqual(pageErrors, []); ok('в интерфейсе нет ошибок JavaScript');

  console.log('Уровни и внешний вид');
  const adm = (p, b) => fetch(hubUrl + p, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Admin-Key': 'adm1' }, body: JSON.stringify(b) }).then(r => r.json());
  const grant = t => adm('/api/admin/grant', { nick: 'Anna_Real', tier: t });
  const cssv = n => page.evaluate(k => getComputedStyle(document.documentElement).getPropertyValue(k).trim(), n);
  const cfgTheme = () => JSON.parse(fs.readFileSync(path.join(root, 'config.json'), 'utf8')).theme || {};
  const lookTab = () => page.click('nav button:has-text("Внешний вид")');
  await lookTab(); await until(async () => (await page.$$('#lktiers .tr')).length >= 4, 4000, 'таблица уровней'); await shot('6-look-free');
  assert.strictEqual((await txt('#lkt')).trim(), 'Обычный'); assert(await page.$eval('.lkb[data-f="palette"]', e => e.classList.contains('locked'))); assert(await page.$eval('.lkb[data-f="logo"]', e => e.classList.contains('locked'))); assert(await page.$eval('.lkb[data-f="nickStyle"]', e => e.classList.contains('locked'))); ok('обычный уровень: платные блоки закрыты замком');
  await until(async () => !!(await page.$('#lktiers [data-buy]')), 4000, 'кнопки покупки'); assert.strictEqual((await page.$$('#lktiers [data-buy]')).length, 1); await page.click('#lktiers [data-buy]'); assert.deepStrictEqual(opened, ['https://pay.example.com/plus']); ok('кнопка «Купить» есть там, где в config.json задана ссылка оплаты, и открывает её в браузере');
  await page.click('#lkpresets button[data-p="emerald"]'); await until(async () => (await cssv('--blue')) === '#22c55e', 3000, 'тема изумруд'); await until(() => cfgTheme().preset === 'emerald', 3000, 'тема сохранена'); ok('готовая тема меняет цвета всего интерфейса и сохраняется');
  await page.$eval('#lkacc', e => { e.value = '#ff00aa'; e.dispatchEvent(new Event('input')); }); await until(async () => (await cssv('--blue')) === '#ff00aa', 2000, 'акцент'); await until(() => cfgTheme().accent === '#ff00aa', 3000, 'акцент сохранён'); ok('свой акцентный цвет доступен всем');
  let tp = await handlers.get('theme:set')({}, { radius: 24, bg: '#111111', logo: true, uiFont: 'comic', bgMode: 'url', bgUrl: 'https://a.com/b.gif' }); assert.strictEqual(tp.theme.radius, 12); assert.strictEqual(tp.theme.bg, '#04120a'); assert.strictEqual(tp.theme.logo, false); assert.strictEqual(tp.theme.uiFont, 'segoe'); assert.strictEqual(tp.theme.bgMode, 'none'); ok('обход через прямой вызов: платные настройки на обычном уровне отбрасываются');
  await tset0(); async function tset0() { await handlers.get('theme:set')({}, { preset: 'classic' }); }
  await assert.rejects(handlers.get('theme:pickLogo')({}, null), /Plus/); await assert.rejects(handlers.get('theme:pickBg')({}, null), /Plus\+/); await assert.rejects(handlers.get('hub:style')({}, { style: { font: 'serif' } }), /Pro|Оформление|вход/); ok('выбор логотипа, фона и стиля ника без нужного уровня отклоняется');

  assert.strictEqual((await grant('plus')).ok, true); await until(async () => (await txt('#lkt')).trim() === 'Plus', 5000, 'Plus'); await until(async () => !(await page.$eval('.lkb[data-f="palette"]', e => e.classList.contains('locked'))), 3000, 'палитра открыта'); assert((await txt('#lktiers .tr.cur')).includes('Plus')); ok('владелец выдал Plus: уровень обновился в интерфейсе сразу, без перезапуска');
  await page.$eval('#lkr', e => { e.value = 20; e.dispatchEvent(new Event('input')); }); await until(async () => (await cssv('--r')) === '20px', 2000, 'скругление'); await page.$eval('#lkbg', e => { e.value = '#101820'; e.dispatchEvent(new Event('input')); }); await until(async () => (await cssv('--bg')) === '#101820', 2000, 'фон'); await page.selectOption('#lkfont', 'georgia'); await until(async () => (await cssv('--font')).startsWith('Georgia'), 2000, 'шрифт'); await until(() => cfgTheme().radius === 20 && cfgTheme().bg === '#101820' && cfgTheme().uiFont === 'georgia', 3000, 'сохранено'); ok('Plus: палитра, скругление и шрифт интерфейса работают и сохраняются');
  const logoFile = path.join(tmp, 'mylogo.png'); fs.writeFileSync(logoFile, mkPng(600, 300, [200, 30, 30])); dialogResult = { canceled: false, filePaths: [logoFile] }; const ic0 = icons.length;
  await page.click('#lkpl'); await until(async () => (await page.$eval('#lg', i => i.src)).startsWith('data:image/png'), 4000, 'логотип'); assert(await page.$eval('#lg', i => i.complete && i.naturalWidth > 0)); assert(fs.existsSync(path.join(root, 'custom', 'logo.png'))); assert(icons.length > ic0); ok('Plus: свой логотип показан в лаунчере, сохранён и передан значку окна');
  await page.$eval('#lkbm', e => { e.value = 'image'; e.dispatchEvent(new Event('change')); }); await sleep(300); assert(!fs.existsSync(path.join(root, 'custom', 'bg.jpg'))); ok('Plus: свой фон пока закрыт (нужен Plus+)');
  const c1 = (await adm('/api/admin/code', { tier: 'plusplus' })).codes[0]; await page.fill('#lkcode', c1.toLowerCase()); await page.click('#lkredeem'); await until(async () => (await txt('#lkmsg')).includes('Plus+'), 4000, 'код принят'); await until(async () => (await txt('#lkt')).trim() === 'Plus+', 3000, 'Plus+'); ok('Plus+: код активации из интерфейса повысил уровень');
  const bgFile = path.join(tmp, 'mybg.png'); fs.writeFileSync(bgFile, mkPng(2400, 1200, [20, 60, 120])); dialogResult = { canceled: false, filePaths: [bgFile] };
  await page.$eval('#lkbm', e => { e.value = 'image'; e.dispatchEvent(new Event('change')); }); await until(async () => page.$eval('body', b => b.classList.contains('hasbg')), 4000, 'фон включён'); assert((await page.$eval('#cbgi', e => e.style.backgroundImage)).includes('data:image')); assert(fs.existsSync(path.join(root, 'custom', 'bg.jpg'))); ok('Plus+: своя картинка стала фоном лаунчера'); await shot('7-look-bg');
  await page.$eval('#lkd', e => { e.value = 70; e.dispatchEvent(new Event('input')); }); await until(async () => (await page.$eval('#cbg', e => e.style.getPropertyValue('--dim-o'))) === '0.7', 2000, 'затемнение'); await page.click('#lksc'); await until(async () => page.$eval('body', b => b.classList.contains('nostage')), 3000, 'без 3D'); ok('Plus+: затемнение и скрытие 3D-сцены');
  tp = await handlers.get('theme:set')({}, { bgMode: 'url', bgUrl: 'https://media.example.com/a.gif' }); assert.strictEqual(tp.theme.bgMode, 'image'); assert.strictEqual(tp.theme.radius, 20); assert.strictEqual(tp.theme.logo, true); await assert.rejects(handlers.get('hub:style')({}, { style: { font: 'serif' } }), /Pro/); ok('Plus+: анимированный фон и стиль ника закрыты, а свой фон и остальные настройки остались');

  assert.strictEqual((await grant('pro')).ok, true); await until(async () => (await txt('#lkt')).trim() === 'Pro', 5000, 'Pro');
  await page.selectOption('#lkbm', 'url'); await page.fill('#lkurl', 'https://media.example.com/bg.mp4'); await page.click('#lkua'); await until(async () => !!(await page.$('#cbg video')), 4000, 'видео-фон'); assert.strictEqual(await page.$eval('#cbg video', v => v.muted && v.loop && v.autoplay), true); assert.strictEqual(await page.$eval('#cbg video', v => v.src), 'https://media.example.com/bg.mp4'); ok('Pro: видео по ссылке стало фоном (без звука, по кругу)');
  await page.fill('#lkurl', 'https://media.example.com/anim.gif'); await page.click('#lkua'); await until(async () => !(await page.$('#cbg video')) && (await page.$eval('#cbgi', e => e.style.backgroundImage)).includes('anim.gif'), 4000, 'гиф-фон'); ok('Pro: анимированная картинка по ссылке');
  await page.fill('#lkurl', 'https://x.com/a b.png'); await page.click('#lkua'); await until(async () => (await txt('#toast')).includes('https://'), 3000, 'ошибка ссылки'); assert.strictEqual(cfgTheme().bgUrl, 'https://media.example.com/anim.gif'); assert.strictEqual((await handlers.get('theme:get')({}, null)).theme.bgMode, 'url'); ok('Pro: небезопасная ссылка отклонена, прежний фон остался');
  await page.selectOption('#lknf', 'script'); await page.selectOption('#lkne', 'rainbow'); await page.$eval('#lkn1', e => { e.value = '#ff66cc'; e.dispatchEvent(new Event('input')); }); await page.check('#lknb'); assert((await page.$eval('#lkprev', e => e.innerHTML)).includes('e-rainbow')); await page.click('#lkns');
  await until(async () => (await page.$eval('#who', e => e.innerHTML)).includes('e-rainbow'), 4000, 'ник со стилем'); const wh = await page.$eval('#who', e => e.innerHTML); assert(wh.includes('f-script') && wh.includes('tb-pro') && wh.includes('--c1:#ff66cc') && wh.includes('nb')); ok('Pro: ник со стилем и значком сразу виден в лаунчере');
  await until(async () => { const f = (await B.friends()).friends[0]; return f && f.style && f.style.effect === 'rainbow' && f.tier === 'pro'; }, 4000, 'друг видит стиль'); ok('друг видит новый стиль ника у себя');
  await shot('8-look-pro');

  console.log('Глобальный и локальный чаты (интерфейс)');
  await tab(); await page.click('#fseg button[data-k="global"]'); await until(() => vis('#rchat'), 3000, 'комната'); assert((await txt('#rtitle')).includes('Глобальный')); ok('вкладка «Глобальный» открыта');
  B.roomSend = B.roomSend.bind(B); await B.roomSend('global', 'привет всем из глобала'); await until(async () => (await txt('#rmsgs')).includes('привет всем из глобала'), 4000, 'сообщение B'); assert((await txt('#rmsgs')).includes('Boris')); ok('сообщение другого игрока пришло в глобальный чат');
  await page.fill('#rmsg', 'это Anna'); await page.press('#rmsg', 'Enter'); await until(() => evB.find(e => e.type === 'room' && e.data.msg.text === 'это Anna'), 4000, 'B получил'); const mine = await page.$eval('#rmsgs', e => e.innerHTML); assert(mine.includes('e-rainbow') && mine.includes('tb-pro')); const em = evB.find(e => e.type === 'room' && e.data.msg.text === 'это Anna'); assert.strictEqual(em.data.msg.style.effect, 'rainbow'); ok('моё сообщение видно всем, ник со стилем и значком Pro');
  await shot('9-global-chat');
  await page.click('#fseg button[data-k="friends"]'); await B.roomSend('global', 'ещё одно'); await until(async () => (await txt('#fseg')).includes('1'), 3000, 'счётчик'); ok('непрочитанные сообщения глобального чата считаются на вкладке');
  await page.click('#fseg button[data-k="local"]'); await until(async () => (await txt('#rsub')).includes('Запусти игру'), 3000, 'вне игры'); assert(await page.isDisabled('#rmsg')); ok('локальный чат вне игры: подсказка, ввод заблокирован');
  B.setPresence('ingame', 'Room.Test:25565'); const nL1 = launches.length; assert.strictEqual(await handlers.get('play')({}, 'room.test'), true);
  await until(async () => (await txt('#rtitle')).includes('room.test'), 5000, 'комната сервера'); assert(!(await page.isDisabled('#rmsg'))); ok('запуск игры на сервере открывает локальный чат этого сервера');
  await B.roomSend('local', 'кто на спавне?'); await until(async () => (await txt('#rmsgs')).includes('кто на спавне?'), 4000, 'локальное'); await page.fill('#rmsg', 'я у шахты'); await page.press('#rmsg', 'Enter'); await until(() => evB.find(e => e.type === 'room' && e.data.kind === 'local' && e.data.msg.text === 'я у шахты'), 4000, 'B получил локальное'); ok('локальный чат: игроки одного сервера переписываются');
  launches[nL1].client.emit('close'); await until(async () => (await txt('#rsub')).includes('Запусти игру'), 5000, 'после игры'); ok('после выхода из игры локальный чат снова закрывается');

  console.log('Команды администратора и откат уровня');
  assert.strictEqual((await grant('admin')).ok, true); await until(async () => (await txt('#lkt')).trim() === 'Admin', 5000, 'Admin'); await page.click('#fseg button[data-k="global"]');
  await page.fill('#rmsg', '/help'); await page.press('#rmsg', 'Enter'); await until(async () => (await page.$$('#rmsgs .sys')).length === 1, 3000, 'справка'); assert((await txt('#rmsgs .sys')).includes('/grant')); ok('админ: /help показывает справку только ему');
  const nr = evB.filter(e => e.type === 'room').length; await page.fill('#rmsg', '/mute boris 5'); await page.press('#rmsg', 'Enter'); await until(async () => (await page.$$('#rmsgs .sys')).length === 2, 3000, 'mute'); await assert.rejects(B.roomSend('global', 'можно?'), /заглушен/); assert.strictEqual(evB.filter(e => e.type === 'room').length, nr); ok('админ: /mute заглушил игрока, команда в чат не попала');
  await page.fill('#rmsg', '/unmute boris'); await page.press('#rmsg', 'Enter'); await until(async () => (await page.$$('#rmsgs .sys')).length === 3, 3000, 'unmute'); await B.roomSend('global', 'снова могу'); ok('админ: /unmute вернул право писать');
  assert.strictEqual((await grant('free')).ok, true); await until(async () => (await txt('#lkt')).trim() === 'Обычный', 5000, 'free'); await until(async () => (await cssv('--r')) === '12px', 3000, 'скругление сброшено'); assert(!(await page.$eval('body', b => b.classList.contains('hasbg')))); assert((await page.$eval('#lg', i => i.src)).includes('assets/logo.png')); assert(!(await page.$eval('#who', e => e.innerHTML)).includes('e-rainbow')); assert.strictEqual((await handlers.get('theme:get')({}, null)).theme.bgMode, 'none'); ok('понижение до обычного: фон, логотип, скругление и стиль ника отключились сами');
  await grant('pro'); await until(async () => (await page.$eval('#who', e => e.innerHTML)).includes('e-rainbow'), 5000, 'вернулся'); await until(async () => (await cssv('--r')) === '20px', 3000, 'тема вернулась'); ok('возврат Pro: сохранённые настройки снова действуют');
  // переподключение: открытый чат перезагружается, чтобы не потерять сообщения за время обрыва
  const calls = { room: 0, hist: 0 }; for (const [k, f] of [['hub:room', 'room'], ['hub:history', 'hist']]) { const orig = handlers.get(k); handlers.set(k, async (e, a) => { calls[f]++; return orig(e, a); }); }
  const snapState = (await handlers.get('hub:snapshot')({}, {})).state, flip = async () => { pageSend('hub:ev', { t: 'state', d: { ...snapState, connected: false } }); await sleep(100); pageSend('hub:ev', { t: 'state', d: { ...snapState, connected: true } }); };
  await tab(); await page.click('#fseg button[data-k="global"]'); await sleep(300); const r0 = calls.room; await flip(); await until(() => calls.room > r0, 3000, 'перезагрузка комнаты'); ok('после переподключения глобальный чат загружается заново');
  await page.click('#fseg button[data-k="friends"]'); await page.click('#flist .item .t'); await until(() => vis('#fchat'), 3000, 'чат с другом'); await sleep(300); const h0 = calls.hist; await flip(); await until(() => calls.hist > h0, 3000, 'перезагрузка истории'); ok('после переподключения личный чат загружается заново');
  // окно, открытое во время игры, знает, что игра идёт
  const nL2 = launches.length; assert.strictEqual(await handlers.get('play')({}, 'last.test'), true); await page.reload(); await until(async () => (await page.isDisabled('#play')) && (await txt('#st')).includes('Игра запущена'), 5000, 'игра запущена');
  launches[nL2].client.emit('close'); await until(async () => !(await page.isDisabled('#play')), 5000, 'кнопка снова доступна'); ok('окно, открытое во время игры, показывает «Игра запущена», а после выхода кнопка снова работает');
  assert.deepStrictEqual(pageErrors, []); ok('в интерфейсе нет ошибок JavaScript');
  await grant('free'); await sleep(300);

  console.log('Сборки .mrpack и Forge');
  const mod = crypto.randomBytes(5000), skip = crypto.randomBytes(100);
  const idx = (over = {}) => JSON.stringify({ formatVersion: 1, game: 'minecraft', name: 'Test Pack', dependencies: { minecraft: '1.20.1', forge: '47.3.0' }, files: [
    { path: 'mods/a.jar', hashes: { sha1: sha('sha1', mod), sha512: sha('sha512', mod) }, downloads: ['https://cdn.modrinth.com/data/x/a.jar'], fileSize: mod.length },
    { path: 'mods/server-only.jar', env: { client: 'unsupported' }, hashes: { sha1: sha('sha1', skip) }, downloads: ['https://cdn.modrinth.com/data/x/s.jar'] }], ...over });
  const mk = (name, index, extra = {}) => { const f = path.join(tmp, name); fs.writeFileSync(path.join(tmp, 'idx.json'), index);
    execFileSync(PY, ['-c', 'import zipfile,sys,json\nz=zipfile.ZipFile(sys.argv[1],"w",zipfile.ZIP_DEFLATED)\nz.write(sys.argv[2],"modrinth.index.json")\nz.writestr("overrides/config/x.toml","A")\nz.writestr("client-overrides/config/x.toml","CLIENT")\nz.writestr("overrides/readme.txt","hi")\nfor k,v in json.loads(sys.argv[3]).items(): z.writestr(k,v)\nz.close()', f, path.join(tmp, 'idx.json'), JSON.stringify(extra)]); return fs.readFileSync(f); };
  files.set('cdn.modrinth.com/data/x/a.jar', mod); files.set('cdn.modrinth.com/data/x/s.jar', skip);
  files.set('cdn.modrinth.com/good.mrpack', mk('good.mrpack', idx()));
  const r = await handlers.get('packs:url')({}, 'https://cdn.modrinth.com/good.mrpack');
  assert.deepStrictEqual(r, { mc: '1.20.1', loader: 'forge', mods: 1 }); const dir = path.join(root, 'instances', 'Test_Pack');
  assert(fs.readFileSync(path.join(dir, 'mods', 'a.jar')).equals(mod)); assert(!fs.existsSync(path.join(dir, 'mods', 'server-only.jar'))); assert.strictEqual(fs.readFileSync(path.join(dir, 'config', 'x.toml'), 'utf8'), 'CLIENT'); assert(fs.existsSync(path.join(dir, 'readme.txt')));
  assert(!fs.existsSync(path.join(root, 'pack.mrpack'))); const cfg = JSON.parse(fs.readFileSync(path.join(root, 'config.json'), 'utf8')); assert.strictEqual(cfg.loader, 'forge'); assert.strictEqual(cfg.lv, '47.3.0'); assert.strictEqual(cfg.pack, 'Test_Pack'); ok('сборка Forge: мод скачан и проверен, серверный пропущен, overrides применены, временный файл удалён');
  const bad = async (name, index, re, extra) => { files.set('cdn.modrinth.com/' + name, mk(name, index, extra)); await assert.rejects(handlers.get('packs:url')({}, 'https://cdn.modrinth.com/' + name), re); assert(!fs.existsSync(path.join(root, 'pack.mrpack'))); };
  const J = JSON.parse(idx());
  await bad('h.mrpack', JSON.stringify({ ...J, files: [{ ...J.files[0], path: 'mods/h.jar', hashes: { sha1: 'a'.repeat(40) } }] }), /повреждён или подменён/); ok('сборка с неверной суммой отклонена');
  await bad('t.mrpack', JSON.stringify({ ...J, files: [{ ...J.files[0], path: '../../evil.jar' }] }), /небезопасный путь/); ok('сборка с путём «../» отклонена до скачивания');
  await bad('s.mrpack', JSON.stringify({ ...J, files: [{ ...J.files[0], path: '../Test_Pack-evil/x.jar' }] }), /небезопасный путь/); ok('обход через соседнюю папку с похожим именем остановлен');
  await bad('o.mrpack', JSON.stringify({ ...J, files: [{ ...J.files[0], downloads: ['https://evil.example.com/a.jar'] }] }), /разрешённой ссылки/); ok('ссылка с неразрешённого сайта отклонена');
  await bad('n.mrpack', JSON.stringify({ ...J, files: [{ path: 'mods/n.jar', downloads: ['https://cdn.modrinth.com/data/x/a.jar'] }] }), /нет контрольных сумм/); ok('файл без контрольной суммы отклонён');
  await bad('q.mrpack', JSON.stringify({ ...J, dependencies: { minecraft: '1.20.1', 'quilt-loader': '0.2' } }), /Quilt/); ok('Quilt: понятное сообщение');
  await bad('z.mrpack', idx(), /небезопасный путь в архиве/, { '../../zipslip.txt': 'x' }); assert(!fs.existsSync(path.join(tmp, 'zipslip.txt'))); ok('zip-slip в overrides остановлен');

  // Forge через «Играть»: версия из promotions, установщик со сверкой sha1
  fs.writeFileSync(path.join(root, 'config.json'), JSON.stringify({ ...cfg, pack: '', lv: '', mc: '1.20.1', loader: 'forge', hubUrl, instances: [] }));
  files.set('files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json', Buffer.from(JSON.stringify({ promos: { '1.20.1-recommended': '47.3.0', '1.20.1-latest': '47.3.5' } })));
  const jar = crypto.randomBytes(3000), jp = '/net/minecraftforge/forge/1.20.1-47.3.0/forge-1.20.1-47.3.0-installer.jar';
  files.set('maven.minecraftforge.net' + jp, jar); files.set('maven.minecraftforge.net' + jp + '.sha1', Buffer.from('f'.repeat(40)));
  sent.length = 0; assert.strictEqual(await handlers.get('play')({}, null), false); assert(sent.some(([c, d]) => c === 'status' && /повреждён или подменён/.test(d))); assert(!fs.existsSync(path.join(root, 'forge-installer.jar'))); ok('Forge: установщик с неверной суммой не запускается');
  files.set('maven.minecraftforge.net' + jp + '.sha1', Buffer.from(sha('sha1', jar) + '  forge-installer.jar\n'));
  sent.length = 0; const nL0 = launches.length; assert.strictEqual(await handlers.get('play')({}, null), true); const L2 = launches[nL0].o;
  assert.strictEqual(L2.version.custom, '1.20.1-forge-47.3.0'); assert(fs.existsSync(path.join(root, 'game', 'versions', '1.20.1-forge-47.3.0'))); ok('Forge: «рекомендованная» версия 47.3.0 выбрана, установщик проверен и выполнен, игра запускается с ней');
  launches[nL0].client.emit('close');
  assert.strictEqual(await handlers.get('play')({}, '-Dbad=1'), false); assert(sent.some(([c, d]) => c === 'status' && /Неверный адрес/.test(d))); assert.strictEqual(launches.length, nL0 + 1); ok('адрес сервера, похожий на параметр JVM, отклонён');

  console.log(`\nГотово: ${n} проверок прошли`);
  await browser.close(); hubProc.kill(); fake.close(); fs.rmSync(tmp, { recursive: true, force: true }); process.exit(0);
})().catch(e => { console.error('\n✖ ОШИБКА:', e.stack || e); process.exit(1); });
