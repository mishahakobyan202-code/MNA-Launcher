'use strict';
// Проверка уровней, тем и оформления ника: node test/tiers.js
const assert = require('assert');
const T = require('../tiers.js');
let n = 0; const ok = s => { n++; console.log('  ✔', s); };

const ids = T.TIERS.map(t => t.id); assert.deepStrictEqual(ids, ['free', 'plus', 'plusplus', 'pro', 'admin']);
const matrix = { preset: 'free', accent: 'free', palette: 'plus', radius: 'plus', uiFont: 'plus', logo: 'plus', bgImage: 'plusplus', bgUrl: 'pro', nickStyle: 'pro' };
for (const [f, min] of Object.entries(matrix)) for (const t of ids) assert.strictEqual(T.can(t, f), T.rank(t) >= T.rank(min), f + '/' + t);
for (const k of ['__proto__', 'constructor', 'toString', 'hasOwnProperty']) { assert(!T.can(k, 'logo') && T.rank(k) === 0); assert.strictEqual(T.sanitizeTheme({ preset: k, uiFont: k }, 'admin').preset, 'classic'); assert.strictEqual(T.sanitizeTheme({ uiFont: k }, 'admin').uiFont, 'segoe'); assert.strictEqual(T.normalizeStyle({ font: k, effect: k }).font, 'sans'); assert(!T.nickHtml('A', null, k).includes('tb-')); }
assert(!T.can('unknown', 'logo') && !T.can(undefined, 'palette') && T.can('admin', 'nickStyle')); ok('таблица уровней: каждая возможность открывается с нужного уровня, неизвестный уровень = обычный');

const want = { accent: '#ff0000', bg: '#101010', panel: '#202020', text: '#eeeeee', radius: 20, uiFont: 'georgia', logo: true, bgMode: 'image', bgFile: true, bgDim: 40, bgBlur: 5, scene: true };
let f = T.sanitizeTheme({ ...want, preset: 'emerald' }, 'free');
assert.strictEqual(f.preset, 'emerald'); assert.strictEqual(f.accent, '#ff0000'); assert.strictEqual(f.bg, T.PRESETS.emerald.bg); assert.strictEqual(f.panel, T.PRESETS.emerald.panel); assert.strictEqual(f.radius, 12); assert.strictEqual(f.uiFont, 'segoe'); assert.strictEqual(f.logo, false); assert.strictEqual(f.bgMode, 'none'); ok('обычный: тема и свой акцентный цвет есть, остальное сброшено');
let p = T.sanitizeTheme(want, 'plus'); assert.strictEqual(p.bg, '#101010'); assert.strictEqual(p.radius, 20); assert.strictEqual(p.uiFont, 'georgia'); assert.strictEqual(p.logo, true); assert.strictEqual(p.bgMode, 'none'); ok('Plus: палитра, скругление, шрифт, логотип; фон-картинка закрыта');
let pp = T.sanitizeTheme(want, 'plusplus'); assert.strictEqual(pp.bgMode, 'image'); assert.strictEqual(pp.bgDim, 40); assert.strictEqual(pp.bgBlur, 5); assert.strictEqual(pp.scene, true); assert.strictEqual(T.sanitizeTheme({ ...want, bgFile: false }, 'plusplus').bgMode, 'none'); ok('Plus+: фон-картинка работает только если файл выбран');
assert.strictEqual(T.sanitizeTheme({ bgMode: 'url', bgUrl: 'https://x.com/a.gif' }, 'plusplus').bgMode, 'none'); ok('Plus+: фон из интернета закрыт');
const U = 'https://media.example.com/bg.webm?x=1'; let pro = T.sanitizeTheme({ bgMode: 'url', bgUrl: U }, 'pro'); assert.strictEqual(pro.bgMode, 'url'); assert.strictEqual(pro.bgUrl, U); assert(T.isVideo(U) && !T.isVideo('https://a.com/b.gif')); ok('Pro: анимированный фон по ссылке, видео и гифки различаются');
for (const bad of ['http://x.com/a.gif', 'https://x.com/a.png);background:url(javascript:1', 'https://x.com/a b.png', "https://x.com/a'.png", 'https://x.com/"><script>', 'javascript:alert(1)', 'https://x.com/' + 'a'.repeat(600), 'https://x.com/a\\.png']) assert.strictEqual(T.sanitizeTheme({ bgMode: 'url', bgUrl: bad }, 'admin').bgMode, 'none', bad);
ok('ссылки на фон: только https, без пробелов, кавычек, скобок (защита от подстановки в CSS)');
const stored = T.sanitizeTheme({ ...want, bgMode: 'url', bgUrl: U }, 'pro'); const down = T.sanitizeTheme(stored, 'free'); assert.strictEqual(down.bgMode, 'none'); assert.strictEqual(down.radius, 12); assert.strictEqual(down.bg, T.PRESETS.classic.bg); assert.strictEqual(down.logo, false); ok('понижение уровня: платные настройки перестают действовать сами');
const weird = T.sanitizeTheme({ preset: 'nope', accent: 'red', radius: 'abc', bgDim: 999, bgBlur: -4, bgMode: 'image', bgFile: true }, 'admin'); assert.strictEqual(weird.preset, 'classic'); assert.strictEqual(weird.accent, T.PRESETS.classic.accent); assert.strictEqual(weird.radius, 12); assert.strictEqual(weird.bgDim, 90); assert.strictEqual(weird.bgBlur, 0); assert.deepStrictEqual(T.sanitizeTheme(null, 'free'), T.DEFAULT_THEME); ok('мусор вместо значений: безопасные значения по умолчанию, числа ограничены');

for (const [k, pr] of Object.entries(T.PRESETS)) { const v = T.deriveVars(T.sanitizeTheme({ preset: k }, 'free')); for (const [name, val] of Object.entries(v)) assert(/^(#[0-9a-f]{6}|rgba\(\d+,\d+,\d+,[\d.]+\)|\d+px|[A-Za-z' ,\-]+)$/.test(val), k + ' ' + name + '=' + val);
  const lum = h => { const c = [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16) / 255); return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]; };
  assert(lum(pr.text) - lum(pr.panel) > 0.55, k + ' контраст текста'); assert(lum(v['--dim']) - lum(pr.panel) > 0.25, k + ' контраст второстепенного текста'); }
ok('все темы: оттенки получаются корректными, текст читается на фоне панелей');

assert.strictEqual(T.sanitizeStyle({ font: 'serif', color: '#ff00aa' }, 'plusplus'), null); assert.strictEqual(T.sanitizeStyle({ font: 'serif' }, 'free'), null); ok('стиль ника доступен только с Pro');
const st = T.sanitizeStyle({ font: 'script', color: '#FF00AA', color2: '#00ffcc', effect: 'rainbow', bold: true, italic: 'yes' }, 'pro'); assert.deepStrictEqual(st, { font: 'script', color: '#ff00aa', color2: '#00ffcc', effect: 'rainbow', bold: true, italic: false }); ok('Pro: стиль ника принимается и нормализуется');
const evil = T.normalizeStyle({ font: "x;background:url(//evil)", color: 'red;x', color2: '#12345', effect: '__proto__', bold: 1 }); assert.deepStrictEqual(evil, { font: 'sans', color: '#ffffff', color2: '#ffffff', effect: 'none', bold: false, italic: false }); ok('подставной шрифт, цвет и эффект заменяются безопасными');
const h = T.nickHtml('<img src=x onerror=alert(1)>', { font: 'mono', color: '#112233', color2: '#445566', effect: 'glow' }, 'pro'); assert(!h.includes('<img') && h.includes('&lt;img') && h.includes('--c1:#112233') && h.includes('tb-pro') && h.includes('f-mono') && h.includes('e-glow')); ok('ник в чате экранируется, в разметку попадают только проверенные значения');
assert(!T.nickHtml('A', null, 'free').includes('tb ') && T.nickHtml('A', null, 'admin').includes('ADMIN') && !T.nickHtml('A', null, '"><x').includes('<x')); ok('значок уровня только у известных платных уровней');
console.log(`\nГотово: ${n} проверок прошли`);
