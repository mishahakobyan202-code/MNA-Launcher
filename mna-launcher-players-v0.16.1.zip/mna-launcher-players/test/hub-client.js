'use strict';
// Проверка клиента Hub против настоящего сервера: node test/hub-client.js
const { spawn } = require('child_process'), assert = require('assert'), fs = require('fs'), os = require('os'), path = require('path');
const { Hub } = require('../hub.js');
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'mna-hubc-')), SRV = path.join(__dirname, '..', '..', 'mna-hub', 'server.js');
let n = 0; const ok = s => { n++; console.log('  ✔', s); };
const start = port => new Promise((res, rej) => {
  const p = spawn(process.execPath, [SRV], { env: { ...process.env, PORT: String(port), HOST: '127.0.0.1', DATA_DIR: dir, REG_PER_HOUR: '100' }, stdio: ['ignore', 'pipe', 'inherit'] });
  process.on('exit', () => { try { p.kill(); } catch {} }); p.stdout.on('data', d => { const m = /:(\d+)/.exec(String(d)); if (m) res({ p, port: +m[1] }); }); p.on('exit', c => rej(new Error('exit ' + c)));
});
const until = async (fn, ms = 6000) => { const t = Date.now(); for (;;) { const v = fn(); if (v) return v; if (Date.now() - t > ms) throw new Error('не дождались'); await new Promise(r => setTimeout(r, 25)); } };

(async () => {
  assert.strictEqual(Hub.normalize('hub.example.com/'), 'https://hub.example.com'); assert.strictEqual(Hub.normalize('http://127.0.0.1:8787'), 'http://127.0.0.1:8787');
  assert.strictEqual(Hub.normalize('http://192.168.1.5:8787/x/'), 'http://192.168.1.5:8787/x'); assert.strictEqual(Hub.normalize(''), '');
  assert.throws(() => Hub.normalize('http://hub.example.com'), /https/); for (const bad of ['http://10.evil.com', 'http://192.168.1.5.evil.com', 'http://localhost.evil.com', 'http://127.0.0.1.evil.com', 'http://172.15.0.1']) assert.throws(() => Hub.normalize(bad), /https/, bad); ok('адрес: https по умолчанию, http только для локальной сети');
  let { p, port } = await start(0); const url = 'http://127.0.0.1:' + port;
  const A = new Hub({ 'User-Agent': 't' }), B = new Hub({ 'User-Agent': 't' }), evA = [], evB = []; let lost = 0;
  A.on('event', e => evA.push(e)); B.on('event', e => evB.push(e)); A.on('auth-lost', () => lost++);
  A.configure(url); B.configure(url);
  assert.deepStrictEqual((await A.info()).proto, 2); await A.register('Anna', 'secret12'); await B.register('Boris', 'secret12'); ok('регистрация двух клиентов');
  await assert.rejects(new Hub({}).register('x', 'y'), /не настроен/); await assert.rejects(Object.assign(new Hub({}), { base: url }).register('Anna', 'secret12'), /занят/); ok('занятый ник отклонён');
  await until(() => A.connected && B.connected); assert(evA.some(e => e.type === 'hello')); ok('SSE подключился после входа');
  await A.request('boris'); await until(() => evB.some(e => e.type === 'friends')); const inc = (await B.friends()).incoming; assert.strictEqual(inc[0].nick, 'Anna'); await B.accept(inc[0].id); ok('заявка и принятие');
  const bid = (await A.friends()).friends[0].id; B.setPresence('ingame', 'mc.example.com'); const pe = await until(() => evA.find(e => e.type === 'presence' && e.data.state === 'ingame')); assert.strictEqual(pe.data.server, 'mc.example.com'); ok('статус «в игре на сервере» дошёл до друга');
  await A.send(bid, 'как дела?'); await until(() => evB.find(e => e.type === 'message' && e.data.text === 'как дела?')); await A.invite(bid, 'mc.example.com', 'го'); const inv = await until(() => evB.find(e => e.type === 'message' && e.data.type === 'invite')); assert.strictEqual(inv.data.server, 'mc.example.com'); ok('сообщение и приглашение');
  assert.strictEqual((await B.history((await B.friends()).friends[0].id)).messages.length, 2); assert.strictEqual((await B.friends()).friends[0].unread, 2); await B.markRead(inv.data.from); assert.strictEqual((await B.friends()).friends[0].unread, 0); ok('история и непрочитанные');
  // переподключение: перезапускаем сервер на том же порту и тех же данных
  evA.length = 0; p.kill('SIGTERM'); await new Promise(r => p.on('exit', r)); await until(() => !A.connected); ok('обрыв сервера замечен');
  ({ p } = await start(port)); await until(() => A.connected && B.connected, 15000); await until(() => evA.some(e => e.type === 'hello')); ok('клиенты сами переподключились, сессии пережили перезапуск');
  const pe2 = await until(() => (B.presence.state === 'ingame') && evA.find(e => e.type === 'presence' && e.data.state === 'ingame'), 8000); assert.strictEqual(pe2.data.server, 'mc.example.com'); ok('после переподключения статус «в игре» восстановлен');
  // потеря сессии
  await B.logout(); assert(!B.loggedIn && !B.snapshot().loggedIn); A.token = 'f'.repeat(64); await assert.rejects(A.friends(), /Сессия|вход/); assert.strictEqual(lost, 1); assert(!A.snapshot().loggedIn); ok('недействительный токен → auth-lost, вход сброшен');
  A.disconnect(); p.kill(); console.log(`\nГотово: ${n} проверок прошли`); fs.rmSync(dir, { recursive: true, force: true }); process.exit(0);
})().catch(e => { console.error('\n✖ ОШИБКА:', e.stack || e); process.exit(1); });
