'use strict';
// Проверка net.js и zip.js без Electron: node test/units.js (нужны python3 и zip для создания эталонных архивов)
const assert = require('assert'), fs = require('fs'), os = require('os'), path = require('path'), http = require('http'), crypto = require('crypto');
const { execFileSync, spawnSync } = require('child_process');
const has = (c, a) => { const r = spawnSync(c, a || ['--version'], { stdio: 'ignore' }); return !r.error; };
const PY = ['python3', 'python'].find(c => has(c)), HAS_ZIP = has('zip', ['-v']), HAS_UNZIP = has('unzip', ['-v']);
if (!PY) console.log('  (python не найден: проверки на эталонных архивах пропущены)');
const py = (code, ...args) => execFileSync(PY, ['-c', code, ...args]);
const { createNet, badHash, allowedPackUrl, inside } = require('../net.js');
const { extractZip, readZipFile, writeZip } = require('../zip.js');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'mna-units-'));
let n = 0; const ok = s => { n++; console.log('  ✔', s); };
const h = (a, b) => crypto.createHash(a).update(b).digest('hex');

(async () => {
  console.log('net.js');
  const body = crypto.randomBytes(200000); let reqs = 0;
  const srv = http.createServer((q, r) => { reqs++; if (q.url === '/404') { r.writeHead(404); return r.end(); } r.writeHead(200); r.end(body); }).listen(0, '127.0.0.1');
  await new Promise(r => srv.on('listening', r));
  const U = 'http://127.0.0.1:' + srv.address().port, net = createNet({ 'User-Agent': 'test' });
  let f = path.join(tmp, 'a', 'ok.bin');
  await net.download(U + '/x', f, { sha1: h('sha1', body), sha512: h('sha512', body) }); assert(fs.readFileSync(f).equals(body)); assert(!fs.existsSync(f + '.part')); ok('верные sha1+sha512: файл записан, .part убран');
  await net.download(U + '/x', f, { sha256: h('sha256', body).toUpperCase() }); ok('сумма в верхнем регистре тоже принимается');
  f = path.join(tmp, 'bad.bin'); reqs = 0;
  await assert.rejects(net.download(U + '/x', f, { sha1: 'a'.repeat(40) }), /повреждён или подменён: контрольная сумма sha1/);
  assert(!fs.existsSync(f) && !fs.existsSync(f + '.part')); assert.strictEqual(reqs, 3); ok('чужая сумма: ошибка, файла нет, 3 попытки');
  reqs = 0; await assert.rejects(net.download(U + '/404', path.join(tmp, 'x'), {}), /HTTP 404/); assert.strictEqual(reqs, 1); ok('404 не повторяется');
  const g = path.join(tmp, 'ok2.bin'); fs.writeFileSync(g, body);
  assert(net.fileOk(g, { sha1: h('sha1', body) })); assert(!net.fileOk(g, { sha1: 'b'.repeat(40) })); assert(!net.fileOk(g + 'x', {})); assert(net.fileOk(g, null)); ok('fileOk: совпало / не совпало / нет файла / без сумм');
  assert.strictEqual(badHash(body, {}), ''); ok('без сумм проверка не требуется (вызывающий код сам решает)');
  assert(allowedPackUrl('https://cdn.modrinth.com/data/x/a.jar') && allowedPackUrl('https://github.com/a/b') && !allowedPackUrl('http://cdn.modrinth.com/a') && !allowedPackUrl('https://evil.com/a') && !allowedPackUrl('https://cdn.modrinth.com.evil.com/a') && !allowedPackUrl('nope')); ok('белый список хостов для .mrpack');
  const d = path.join(tmp, 'pack');
  assert(inside(d, path.join(d, 'mods', 'a.jar')) && inside(d, d) && !inside(d, d + '-evil/x') && !inside(d, path.join(d, '..', 'x'))); ok('inside: «pack-evil» не внутри «pack»');
  srv.close();

  console.log('zip.js');
  if (!PY) { console.log(`\nГотово: ${n} проверок прошли (zip.js пропущен: нужен python)`); return; }
  // эталонные архивы из Python и Info-ZIP
  const src = path.join(tmp, 'src'); fs.mkdirSync(path.join(src, 'sub', 'deep'), { recursive: true });
  fs.writeFileSync(path.join(src, 'empty.txt'), ''); fs.writeFileSync(path.join(src, 'мир.txt'), 'привет, мир'); fs.writeFileSync(path.join(src, 'sub', 'deep', 'a.json'), JSON.stringify({ a: 1 }).repeat(500));
  fs.writeFileSync(path.join(src, 'big.bin'), Buffer.concat([crypto.randomBytes(3e6), Buffer.alloc(20e6, 7)]));
  for (let i = 0; i < 3000; i++) fs.writeFileSync(path.join(src, 'sub', `f${i}.txt`), 'x' + i);
  const same = (a, b) => { const walk = d => fs.readdirSync(d, { withFileTypes: true }).flatMap(e => e.isDirectory() ? walk(path.join(d, e.name)).map(x => e.name + '/' + x) : [e.name]); const A = walk(a).sort(), B = walk(b).sort(); assert.deepStrictEqual(A, B); for (const r of A) assert(fs.readFileSync(path.join(a, r)).equals(fs.readFileSync(path.join(b, r))), r); return A.length; };
  const pz = path.join(tmp, 'py.zip');
  py(`import zipfile,os,sys\nz=zipfile.ZipFile(sys.argv[1],'w',zipfile.ZIP_DEFLATED)\nfor r,ds,fs in os.walk(sys.argv[2]):\n  for d in ds: z.write(os.path.join(r,d), os.path.relpath(os.path.join(r,d),sys.argv[2])+'/')\n  for f in fs: z.write(os.path.join(r,f), os.path.relpath(os.path.join(r,f),sys.argv[2]))\nz.writestr(zipfile.ZipInfo('stored.txt'),'stored data',zipfile.ZIP_STORED)\nz.close()`, pz, src);
  let out = path.join(tmp, 'o1'); const names = extractZip(pz, out); fs.rmSync(path.join(out, 'stored.txt')); const cnt = same(src, out); assert(names.includes('мир.txt') && names.includes('stored.txt')); ok(`Python-архив: ${cnt} файлов совпали, юникод и stored работают`);
  if (HAS_ZIP) { const iz = path.join(tmp, 'iz.zip'); execFileSync('zip', ['-qr', iz, '.'], { cwd: src }); out = path.join(tmp, 'o2'); extractZip(iz, out); same(src, out); ok('архив Info-ZIP: всё совпало'); }
  // защита
  const evil = path.join(tmp, 'evil.zip');
  py(`import zipfile,sys\nz=zipfile.ZipFile(sys.argv[1],'w')\nz.writestr('ok.txt','1')\nz.writestr('../evil.txt','x')\nz.close()`, evil);
  assert.throws(() => extractZip(evil, path.join(tmp, 'o3', 'in')), /небезопасный путь/); assert(!fs.existsSync(path.join(tmp, 'o3', 'evil.txt')) && !fs.existsSync(path.join(tmp, 'o3', 'in', 'ok.txt'))); ok('zip-slip «../evil.txt» остановлен, ничего не записано');
  py(`import zipfile,sys\nz=zipfile.ZipFile(sys.argv[1],'w')\nz.writestr('/abs.txt','x')\nz.close()`, evil + '2');
  assert.throws(() => extractZip(evil + '2', path.join(tmp, 'o4')), /небезопасный/); ok('абсолютный путь остановлен');
  py(`import zipfile,sys\nz=zipfile.ZipFile(sys.argv[1],'w')\nz.writestr('a\\\\..\\\\..\\\\evil.txt','x')\nz.close()`, evil + '3');
  assert.throws(() => extractZip(evil + '3', path.join(tmp, 'o5')), /небезопасный/); ok('обратные слэши с «..» остановлены');
  const bad = fs.readFileSync(pz); const idx = bad.indexOf(Buffer.from('stored data')); bad[idx + 2] ^= 0xff; fs.writeFileSync(path.join(tmp, 'bad.zip'), bad);
  assert.throws(() => extractZip(path.join(tmp, 'bad.zip'), path.join(tmp, 'o6')), /контрольная сумма/); ok('повреждённые данные: ошибка CRC');
  fs.writeFileSync(path.join(tmp, 'junk.zip'), crypto.randomBytes(500)); assert.throws(() => extractZip(path.join(tmp, 'junk.zip'), path.join(tmp, 'o7')), /не zip/); ok('не-zip файл отклонён');
  // выборочная распаковка как у .mrpack
  const mp = path.join(tmp, 'p.mrpack');
  py(`import zipfile,sys\nz=zipfile.ZipFile(sys.argv[1],'w',zipfile.ZIP_DEFLATED)\nz.writestr('modrinth.index.json','{"name":"t"}')\nz.writestr('overrides/config/a.toml','A')\nz.writestr('overrides/b.txt','B')\nz.writestr('client-overrides/config/a.toml','CLIENT')\nz.writestr('other/x','X')\nz.close()`, mp);
  assert.strictEqual(readZipFile(mp, 'modrinth.index.json').toString(), '{"name":"t"}'); assert.strictEqual(readZipFile(mp, 'нет'), null);
  out = path.join(tmp, 'inst'); extractZip(mp, out, { map: nm => nm.startsWith('overrides/') ? nm.slice(10) : null }); extractZip(mp, out, { map: nm => nm.startsWith('client-overrides/') ? nm.slice(17) : null });
  assert.strictEqual(fs.readFileSync(path.join(out, 'config', 'a.toml'), 'utf8'), 'CLIENT'); assert.strictEqual(fs.readFileSync(path.join(out, 'b.txt'), 'utf8'), 'B'); assert(!fs.existsSync(path.join(out, 'other'))); ok('overrides → client-overrides с перезаписью, остальное не трогается');
  // упаковка (бэкап мира)
  const wz = path.join(tmp, 'world.zip'); const c = writeZip(wz, src, 'Мой мир');
  if (HAS_UNZIP) execFileSync('unzip', ['-tq', wz]); py(`import zipfile,sys\nz=zipfile.ZipFile(sys.argv[1]); assert z.testzip() is None; assert 'Мой мир/sub/deep/a.json' in z.namelist()`, wz);
  out = path.join(tmp, 'o8'); extractZip(wz, out); same(src, path.join(out, 'Мой мир')); ok(`writeZip: ${c} записей, unzip -t и Python довольны, обратная распаковка совпала`);
  console.log(`\nГотово: ${n} проверок прошли`); fs.rmSync(tmp, { recursive: true, force: true });
})().catch(e => { console.error('\n✖ ОШИБКА:', e.stack || e); process.exit(1); });
