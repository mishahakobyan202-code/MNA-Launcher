(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(); else root.MNATiers = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  // Уровни: чем выше номер, тем больше возможностей. Каждый следующий включает всё предыдущее.
  const TIERS = [
    { id: 'free', name: 'Обычный', rank: 0 }, { id: 'plus', name: 'Plus', rank: 1 }, { id: 'plusplus', name: 'Plus+', rank: 2 },
    { id: 'pro', name: 'Pro', rank: 3 }, { id: 'admin', name: 'Admin', rank: 4 }
  ];
  const RANK = Object.fromEntries(TIERS.map(t => [t.id, t.rank]));
  // С какого уровня доступна каждая возможность (чтобы изменить условия, правь только эту таблицу).
  const MIN = { preset: 'free', accent: 'free', palette: 'plus', radius: 'plus', uiFont: 'plus', logo: 'plus', bgImage: 'plusplus', bgUrl: 'pro', nickStyle: 'pro' };
  const DEFAULT_PRICES = { plus: 0.99, plusplus: 2.99, pro: 4.99 };
  const BADGES = { plus: 'PLUS', plusplus: 'PLUS+', pro: 'PRO', admin: 'ADMIN' };
  const own = (o, k) => typeof k === 'string' && Object.prototype.hasOwnProperty.call(o, k);
  const rank = t => (own(RANK, t) ? RANK[t] : 0);
  const can = (tier, feature) => rank(tier) >= rank(MIN[feature]);
  const tierName = t => (TIERS.find(x => x.id === t) || TIERS[0]).name;

  const PRESETS = {
    classic: { name: 'Классика', accent: '#1e8cff', bg: '#050b1a', panel: '#0a1730', text: '#e6f0ff' },
    emerald: { name: 'Изумруд', accent: '#22c55e', bg: '#04120a', panel: '#0a2216', text: '#e6fff0' },
    sunset: { name: 'Закат', accent: '#ff7a2f', bg: '#160a05', panel: '#2a140a', text: '#fff0e6' },
    violet: { name: 'Фиолет', accent: '#a05bff', bg: '#0b0616', panel: '#1a0f30', text: '#f0e8ff' },
    rose: { name: 'Роза', accent: '#ff4f8b', bg: '#170811', panel: '#2a1020', text: '#ffe8f1' }
  };
  const UIFONTS = {
    segoe: 'Segoe UI,sans-serif', arial: 'Arial,sans-serif', verdana: 'Verdana,sans-serif', trebuchet: "'Trebuchet MS',sans-serif",
    georgia: 'Georgia,serif', consolas: "Consolas,'Courier New',monospace", comic: "'Comic Sans MS',cursive"
  };
  const UIFONT_NAMES = { segoe: 'Segoe UI (по умолчанию)', arial: 'Arial', verdana: 'Verdana', trebuchet: 'Trebuchet', georgia: 'Georgia (с засечками)', consolas: 'Consolas (моно)', comic: 'Comic Sans' };
  const NICK_FONTS = { sans: 'Segoe UI,sans-serif', serif: 'Georgia,serif', mono: "Consolas,'Courier New',monospace", script: "'Segoe Script','Brush Script MT',cursive", impact: "Impact,'Arial Black',sans-serif", comic: "'Comic Sans MS',cursive", rounded: "'Trebuchet MS',sans-serif", wide: 'Verdana,sans-serif' };
  const NICK_FONT_NAMES = { sans: 'Обычный', serif: 'С засечками', mono: 'Моно', script: 'Рукописный', impact: 'Жирный (Impact)', comic: 'Comic', rounded: 'Мягкий', wide: 'Широкий' };
  const EFFECTS = { none: 'Без эффекта', gradient: 'Градиент', shimmer: 'Блеск', rainbow: 'Радуга', glow: 'Свечение' };

  const DEFAULT_THEME = { preset: 'classic', ...pick(PRESETS.classic), radius: 12, uiFont: 'segoe', logo: false, bgMode: 'none', bgFile: false, bgUrl: '', bgDim: 55, bgBlur: 0, scene: true };
  function pick(p) { return { accent: p.accent, bg: p.bg, panel: p.panel, text: p.text }; }
  const isHex = v => typeof v === 'string' && /^#[0-9a-fA-F]{6}$/.test(v);
  const hex = (v, d) => (isHex(v) ? v.toLowerCase() : d);
  const num = (v, lo, hi, d) => { v = Math.round(Number(v)); return Number.isFinite(v) ? Math.min(hi, Math.max(lo, v)) : d; };
  const bgUrlOk = u => typeof u === 'string' && u.length <= 500 && /^https:\/\/[^\s"'()<>\\]+$/.test(u);
  const isVideo = u => /\.(mp4|webm)(\?|#|$)/i.test(u || '');

  // Приводит тему к тому, что разрешено на этом уровне. Лишнее молча сбрасывается.
  function sanitizeTheme(t, tier) {
    t = t && typeof t === 'object' ? t : {};
    const preset = own(PRESETS, t.preset) ? t.preset : 'classic', out = { ...DEFAULT_THEME, preset, ...pick(PRESETS[preset]) };
    if (can(tier, 'accent')) out.accent = hex(t.accent, out.accent);
    if (can(tier, 'palette')) { out.bg = hex(t.bg, out.bg); out.panel = hex(t.panel, out.panel); out.text = hex(t.text, out.text); }
    if (can(tier, 'radius')) out.radius = num(t.radius, 0, 24, 12);
    if (can(tier, 'uiFont') && own(UIFONTS, t.uiFont)) out.uiFont = t.uiFont;
    if (can(tier, 'logo')) out.logo = t.logo === true;
    if (t.bgMode === 'image' && can(tier, 'bgImage') && t.bgFile === true) { out.bgMode = 'image'; out.bgFile = true; }
    else if (t.bgMode === 'url' && can(tier, 'bgUrl') && bgUrlOk(t.bgUrl)) { out.bgMode = 'url'; out.bgUrl = t.bgUrl; }
    if (out.bgMode !== 'none') { out.bgDim = num(t.bgDim, 0, 90, 55); out.bgBlur = num(t.bgBlur, 0, 20, 0); out.scene = t.scene === true; }
    return out;
  }

  const rgb = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16));
  const toHex = a => '#' + a.map(v => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('');
  const mix = (a, b, t) => { const x = rgb(a), y = rgb(b); return toHex(x.map((v, i) => v * (1 - t) + y[i] * t)); };
  const rgba = (h, a) => { const c = rgb(h); return `rgba(${c[0]},${c[1]},${c[2]},${a})`; };
  // Из четырёх базовых цветов получаем все оттенки интерфейса.
  function deriveVars(t) {
    const a = t.accent, p = t.panel, bg = t.bg, tx = t.text;
    return {
      '--bg': bg, '--bg2': mix(bg, a, 0.2), '--pan': p, '--pan-a': rgba(p, 0.88), '--side': mix(bg, p, 0.55), '--field': mix(p, a, 0.14), '--hover': mix(p, a, 0.32),
      '--line': mix(p, a, 0.3), '--blue': a, '--acc1': mix(a, '#ffffff', 0.25), '--acc2': mix(a, '#000000', 0.22), '--acc3': mix(a, '#000000', 0.55), '--glow': rgba(a, 0.4),
      '--text': tx, '--dim': mix(mix(tx, a, 0.3), bg, 0.4), '--r': t.radius + 'px', '--font': own(UIFONTS, t.uiFont) ? UIFONTS[t.uiFont] : UIFONTS.segoe
    };
  }

  // Оформление ника для чатов. Всё проверяется по белым спискам, чужой код попасть сюда не может.
  function normalizeStyle(s) {
    if (!s || typeof s !== 'object') return null;
    const font = own(NICK_FONTS, s.font) ? s.font : 'sans', effect = own(EFFECTS, s.effect) ? s.effect : 'none';
    const color = hex(s.color, '#ffffff'), color2 = hex(s.color2, color);
    return { font, color, color2, effect, bold: s.bold === true, italic: s.italic === true };
  }
  const sanitizeStyle = (s, tier) => (can(tier, 'nickStyle') ? normalizeStyle(s) : null);
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  function nickHtml(nick, style, tier) {
    const s = normalizeStyle(style), badge = own(BADGES, tier) ? `<span class="tb tb-${tier}">${BADGES[tier]}</span>` : '';
    if (!s) return `<span class="nk">${esc(nick)}</span>${badge}`;
    return `<span class="nk e-${s.effect} f-${s.font}${s.bold ? ' nb' : ''}${s.italic ? ' ni' : ''}" style="--c1:${s.color};--c2:${s.color2}">${esc(nick)}</span>${badge}`;
  }

  return { TIERS, RANK, MIN, DEFAULT_PRICES, BADGES, PRESETS, UIFONTS, UIFONT_NAMES, NICK_FONTS, NICK_FONT_NAMES, EFFECTS, DEFAULT_THEME, rank, can, tierName, sanitizeTheme, deriveVars, mix, normalizeStyle, sanitizeStyle, nickHtml, bgUrlOk, isVideo, esc };
});
