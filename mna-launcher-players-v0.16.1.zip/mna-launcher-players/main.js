const { app, BrowserWindow, ipcMain, shell, safeStorage, Tray, Menu, nativeImage, Notification, dialog } = require('electron');
const os = require('os'), zlib = require('zlib');
const path = require('path'), fs = require('fs'), { execFile, spawn } = require('child_process');
const { Client, Authenticator } = require('minecraft-launcher-core');
const { Auth } = require('msmc');
const { createNet, hasHashes, allowedPackUrl, inside } = require('./net');
const { extractZip, readZipFile, writeZip } = require('./zip');
const { Hub } = require('./hub');
const Tiers = require('./tiers');

const root = path.join(app.getPath('appData'), '.mna'), game = path.join(root, 'game');
const cfgFile = path.join(root, 'config.json');
const defaults = { nick: 'Player', ram: Math.min(8, Math.max(2, Math.floor(os.totalmem() / 2 ** 31))), fast: true, anim: true, onlaunch: 'hide', repo: 'both', autover: true, cfkey: '', featured: true, fullscreen: false, hubUrl: '', java: 'auto', server: 'play.example.com', mc: '1.21.1', loader: 'neoforge' };
const UA = { 'User-Agent': 'MNA-Launcher/' + app.getVersion(), 'Accept': 'application/json' };
const { getJson, getText, download, fileOk } = createNet(UA);
const WIN = process.platform === 'win32', MAC = process.platform === 'darwin', JEXE = WIN ? 'java.exe' : 'java';
const ADDR_RE = /^(?!-)[A-Za-z0-9._:\[\]-]{1,80}$/;
const ICON = path.join(__dirname, 'assets', WIN ? 'icon.ico' : 'logo.png');
app.setAppUserModelId('net.mna.launcher');
let win, session = null;

const safeName = s => path.basename(String(s || '')).replace(/[<>:"|?*\x00-\x1f]/g, '_');
const safeId = id => {
  const b = path.basename(String(id || ''));
  if (!b || b === '.' || b === '..' || !/^[\w.-]+$/.test(b)) throw new Error('Неверный id экземпляра');
  return b;
};

const getCfg = () => {
  try {
    const p = JSON.parse(fs.readFileSync(cfgFile, 'utf8'));
    let changed = false;
    if (p.cfgv !== 4) {
      if (p.onlaunch !== 'close') p.onlaunch = 'hide';
      if (!p.repo || p.repo === 'modrinth') p.repo = 'both';
      p.cfgv = 4; changed = true;
    }
    if (p.onlaunch === 'reopen') { p.onlaunch = 'hide'; changed = true; }
    if (changed) { try { fs.mkdirSync(root, { recursive: true }); fs.writeFileSync(cfgFile, JSON.stringify(p, null, 2)); } catch {} }
    return { ...defaults, ...p };
  } catch { return { ...defaults }; }
};
const send = (ch, d) => { if (win && !win.isDestroyed()) win.webContents.send(ch, d); };
let hidden = false, tray = null, gameRunning = false;
const inst = c => path.join(root, 'instances', safeId(c.pack || `${c.mc}-${c.loader}`));
const sleep = ms => new Promise(r => setTimeout(r, ms));

async function ensureLoader(c) {
  const key = `${c.mc}-${c.loader}-${c.lv || ''}`, cf = path.join(root, 'loader-cache.json');
  let cache = {}; try { cache = JSON.parse(fs.readFileSync(cf, 'utf8')); } catch {}
  const cid = cache[key];
  if (cid && fs.existsSync(path.join(game, 'versions', cid, cid + '.json'))) return cid;
  const id = await resolveLoader(c); cache[key] = id;
  fs.mkdirSync(root, { recursive: true }); fs.writeFileSync(cf, JSON.stringify(cache)); return id;
}
const loaderLog = path.join(root, 'loader-install.log');
// Контрольная сумма из Maven (файл «.sha1» рядом с артефактом). Если её нет, скачиваем без проверки и пишем об этом в лог.
async function mavenSum(url) {
  try { const t = (await getText(url + '.sha1')).trim().split(/\s+/)[0].toLowerCase(); return /^[a-f0-9]{40}$/.test(t) ? { sha1: t } : null; } catch { return null; }
}
async function runInstaller(c, url, jar, label, find, cleanup) {
  send('status', 'Установка ' + label + '...');
  const sum = await mavenSum(url); if (!sum) send('log', 'Контрольная сумма установщика ' + label + ' недоступна: файл скачан без проверки');
  await download(url, jar, sum || undefined);
  fs.mkdirSync(game, { recursive: true });
  const prof = path.join(game, 'launcher_profiles.json');
  if (!fs.existsSync(prof)) fs.writeFileSync(prof, JSON.stringify({ profiles: {} }));
  await new Promise((res, rej) => execFile(c.java, ['-jar', jar, '--installClient', game], { maxBuffer: 64 * 1024 * 1024 }, (e, so, se) => {
    fs.writeFileSync(loaderLog, (so || '') + '\n' + (se || ''));
    if (e) { try { cleanup(); } catch {} return rej(new Error('Установщик ' + label + ' завершился с ошибкой. Открой «Лог установки» в настройках.')); }
    res();
  }));
  const id = find(); if (!id) throw new Error(label + ' установился не полностью. Открой «Лог установки» в настройках.');
  return id;
}
const verJson = id => path.join(game, 'versions', id, id + '.json');
const forgePick = (promos, mc) => (promos || {})[mc + '-recommended'] || (promos || {})[mc + '-latest'] || '';
const forgeInstalled = (mc, fv) => { try { return fs.readdirSync(path.join(game, 'versions')).find(d => d.startsWith(mc + '-forge') && d.includes(fv) && fs.existsSync(verJson(d))) || ''; } catch { return ''; } };
async function resolveLoader(c) {
  if (c.loader === 'fabric') {
    const list = await getJson(`https://meta.fabricmc.net/v2/versions/loader/${c.mc}`);
    if (!list.length) throw new Error('Fabric недоступен для ' + c.mc);
    const lv = c.lv || list[0].loader.version, id = `fabric-loader-${lv}-${c.mc}`;
    if (!fs.existsSync(verJson(id))) await download(`https://meta.fabricmc.net/v2/versions/loader/${c.mc}/${lv}/profile/json`, verJson(id));
    return id;
  }
  if (c.loader === 'forge') {
    const fv = c.lv || forgePick((await getJson('https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json')).promos, c.mc);
    if (!fv) throw new Error('Forge недоступен для ' + c.mc);
    const have = forgeInstalled(c.mc, fv); if (have) return have;
    const full = `${c.mc}-${fv}`;
    return runInstaller(c, `https://maven.minecraftforge.net/net/minecraftforge/forge/${full}/forge-${full}-installer.jar`, path.join(root, 'forge-installer.jar'), 'Forge ' + fv, () => forgeInstalled(c.mc, fv), () => {});
  }
  if (c.loader === 'neoforge') {
    const p = c.mc.split('.');
    const prefix = p[0] === '1' ? `${p[1]}.${p[2] || 0}.` : `${p[0]}.${p[1] || 0}.${p[2] || 0}.`;
    const all = (await getJson('https://maven.neoforged.net/api/maven/versions/releases/net/neoforged/neoforge')).versions;
    const mm = all.filter(v => v.startsWith(prefix));
    let m = mm.filter(v => !v.includes('beta'));
    if (!m.length) m = mm;
    m.sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
    if (!m.length) throw new Error('NeoForge недоступен для ' + c.mc);
    const nv = c.lv || m[m.length - 1], id = 'neoforge-' + nv;
    if (fs.existsSync(verJson(id))) return id;
    return runInstaller(c, `https://maven.neoforged.net/releases/net/neoforged/neoforge/${nv}/neoforge-${nv}-installer.jar`, path.join(root, 'neoforge-installer.jar'), 'NeoForge ' + nv, () => fs.existsSync(verJson(id)) ? id : '', () => fs.rmSync(path.join(game, 'versions', id), { recursive: true, force: true }));
  }
}

function loaderJvm(id) {
  const j = JSON.parse(fs.readFileSync(path.join(game, 'versions', id, id + '.json'), 'utf8'));
  const sep = process.platform === 'win32' ? ';' : ':', lib = path.join(game, 'libraries');
  const sub = s => s.replace(/\$\{library_directory\}/g, lib).replace(/\$\{classpath_separator\}/g, sep).replace(/\$\{version_name\}/g, id);
  const raw = ((j.arguments && j.arguments.jvm) || []).filter(a => typeof a === 'string'), out = [];
  for (let i = 0; i < raw.length; i++) {
    if (raw[i] === '-cp' || raw[i] === '-classpath') { i++; continue; }
    const a = sub(raw[i]);
    if (!a.includes('${')) out.push(a);
  }
  return out;
}
const FAST = ['-XX:+UseG1GC', '-XX:+ParallelRefProcEnabled', '-XX:MaxGCPauseMillis=200', '-XX:+UnlockExperimentalVMOptions', '-XX:+DisableExplicitGC', '-XX:G1NewSizePercent=30', '-XX:G1MaxNewSizePercent=40', '-XX:G1HeapRegionSize=8M', '-XX:G1ReservePercent=20', '-XX:G1HeapWastePercent=5', '-XX:G1MixedGCCountTarget=4', '-XX:InitiatingHeapOccupancyPercent=15', '-XX:G1MixedGCLiveThresholdPercent=90', '-XX:G1RSetUpdatingPauseTimePercent=5', '-XX:SurvivorRatio=32', '-XX:+PerfDisableSharedMem', '-XX:MaxTenuringThreshold=1'];
const PACKS = {
  fps: ['sodium', 'lithium', 'ferrite-core', 'immediatelyfast', 'entityculling', 'modernfix', 'fabric-api', 'iris', 'dynamic-fps'],
  qol: ['jei', 'xaeros-minimap', 'xaeros-world-map', 'appleskin', 'jade', 'mouse-tweaks', 'inventory-profiles-next', 'modmenu', 'fabric-api']
};
const jmajor = mc => { const p = mc.split('.').map(Number); if (p[0] !== 1) return 25; const n = p[1], x = p[2] || 0; return n >= 21 || (n === 20 && x >= 5) ? 21 : n >= 17 ? 17 : 8; };
function scanJava() {
  const out = [], bases = [];
  if (WIN) { for (const b of [process.env.ProgramFiles, process.env['ProgramFiles(x86)']].filter(Boolean)) for (const d of ['Java', 'Eclipse Adoptium', 'Microsoft', 'Zulu', 'BellSoft', 'Amazon Corretto', 'Semeru']) bases.push(path.join(b, d)); }
  else bases.push(MAC ? '/Library/Java/JavaVirtualMachines' : '/usr/lib/jvm');
  bases.push(path.join(root, 'java'));
  for (const b of bases) {
    let ds = []; try { ds = fs.readdirSync(b); } catch { continue; }
    for (const d of ds) {
      for (const home of [path.join(b, d), path.join(b, d, 'Contents', 'Home')]) {
        const exe = path.join(home, 'bin', JEXE); if (!fs.existsSync(exe)) continue;
        let v = ''; try { v = fs.readFileSync(path.join(home, 'release'), 'utf8').match(/JAVA_VERSION="([^"]+)"/)[1]; } catch { const q = d.match(/(\d+)/); v = q ? q[1] : '0'; }
        out.push({ exe, major: v.startsWith('1.') ? +v.split('.')[1] : +v.split('.')[0] }); break;
      }
    }
  }
  return out;
}
function isValidJava(p) {
  if (!p || typeof p !== 'string') return false;
  if (!fs.existsSync(p)) return false;
  if (!/java(\.exe)?$/i.test(p)) return false;
  try { return fs.statSync(p).isFile(); } catch { return false; }
}
async function javaFor(c) {
  if (c.java && !['auto', 'java'].includes(c.java)) {
    if (isValidJava(c.java)) return c.java;
    c.java = 'auto';
  }
  const need = jmajor(c.mc), list = scanJava().filter(j => j.major >= need).sort((a, b) => a.major - b.major);
  const f = list.find(j => j.major === need) || list[0];
  if (f) return f.exe;
  send('status', `Скачивание Java ${need} (один раз)...`);
  const osn = WIN ? 'windows' : MAC ? 'mac' : 'linux', arch = process.arch === 'arm64' ? 'aarch64' : 'x64', ext = WIN ? 'zip' : 'tar.gz';
  let pkg = null;
  try { // ссылка и sha256 берём из каталога Adoptium, чтобы проверить скачанный архив
    const a = await getJson(`https://api.adoptium.net/v3/assets/latest/${need}/hotspot?architecture=${arch}&image_type=jre&os=${osn}&vendor=eclipse`);
    const k = a[0] && a[0].binary && a[0].binary.package;
    if (k && /^https:\/\//.test(k.link || '') && /^[a-f0-9]{64}$/i.test(k.checksum || '')) pkg = k;
  } catch {}
  const file = path.join(root, `java${need}.${ext}`);
  await download(pkg ? pkg.link : `https://api.adoptium.net/v3/binary/latest/${need}/ga/${osn}/${arch}/jre/hotspot/normal/eclipse`, file, pkg ? { sha256: pkg.checksum } : undefined);
  if (!pkg) send('log', 'Контрольная сумма Java недоступна: архив скачан без проверки');
  send('status', `Распаковка Java ${need}...`);
  const dest = path.join(root, 'java'); fs.mkdirSync(dest, { recursive: true });
  if (WIN) extractZip(file, dest); else await new Promise((res, rej) => execFile('tar', ['-xzf', file, '-C', dest], e => e ? rej(new Error('Не удалось распаковать Java: ' + e.message)) : res()));
  fs.unlinkSync(file);
  const j = scanJava().find(x => x.major === need); if (!j) throw new Error('Не удалось установить Java ' + need);
  return j.exe;
}

function spawnRelauncher(pid, delay = 2000) {
  const exe = process.env.PORTABLE_EXECUTABLE_FILE || process.env.APPIMAGE || process.execPath, extra = app.isPackaged ? [] : [app.getAppPath()];
  try {
    if (WIN) {
      const e = exe.replace(/'/g, "''"), extraArgs = extra.length ? ` -ArgumentList @('${extra[0].replace(/'/g, "''")}')` : '';
      const ps = `try{$d=(Get-Date).AddHours(24);while((Get-Date)-lt $d){if(-not(Get-Process -Id ${+pid} -ErrorAction SilentlyContinue)){break};Start-Sleep -Milliseconds 1500};Start-Sleep -Milliseconds ${+delay};Start-Process -FilePath '${e}'${extraArgs}}catch{}`;
      spawn('powershell', ['-NoProfile', '-WindowStyle', 'Hidden', '-Command', ps], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
    } else {
      const sh = `while kill -0 ${+pid} 2>/dev/null; do sleep 1.5; done; sleep ${Math.max(0, delay / 1000)}; exec "$0" "$@"`;
      spawn('sh', ['-c', sh, exe, ...extra], { detached: true, stdio: 'ignore' }).unref();
    }
  } catch (e) { send('log', 'Не удалось запустить сторожевой процесс: ' + e.message); }
}

const recF = c => path.join(inst(c), 'mods.json');
const recs = c => { try { return JSON.parse(fs.readFileSync(recF(c), 'utf8')); } catch { return {}; } };
const DIRS = { mod: 'mods', resourcepack: 'resourcepacks', shader: 'shaderpacks' };
const vq = (c, t = 'mod') => 'game_versions=' + encodeURIComponent(JSON.stringify([c.mc])) + (t === 'mod' && c.loader !== 'vanilla' ? '&loaders=' + encodeURIComponent(JSON.stringify([c.loader])) : '');
async function installMod(id, c, seen, t = 'mod') {
  if (seen.has(id)) return; seen.add(id);
  const vs = await getJson(`https://api.modrinth.com/v2/project/${id}/version?${vq(c, t)}`);
  if (!vs.length) throw new Error(id + ': нет версии для ' + c.mc + (t === 'mod' ? ' / ' + c.loader : ''));
  const v = vs[0], f = v.files.find(x => x.primary) || v.files[0], fn = safeName(f.filename), fp = path.join(inst(c), DIRS[t] || 'mods', fn);
  if (!fileOk(fp, f.hashes)) await download(f.url, fp, f.hashes);
  const r = recs(c);
  for (const [n, o] of Object.entries(r)) if (o.p === v.project_id && n !== fn) { try { fs.unlinkSync(path.join(inst(c), DIRS[o.t] || 'mods', safeName(n))); } catch {} delete r[n]; }
  r[fn] = { p: v.project_id, v: v.id, t }; fs.writeFileSync(recF(c), JSON.stringify(r));
  await Promise.all((v.dependencies || []).filter(d => d.dependency_type === 'required' && d.project_id).map(d => installMod(d.project_id, c, seen).catch(() => {})));
}

function nbtParse(buf) {
  let p = 0;
  const str = () => { const n = buf.readUInt16BE(p); p += 2; const s = buf.toString('utf8', p, p + n); p += n; return s; };
  const R = {
    1: () => buf.readInt8(p++), 2: () => { const v = buf.readInt16BE(p); p += 2; return v; }, 3: () => { const v = buf.readInt32BE(p); p += 4; return v; },
    4: () => { const v = Number(buf.readBigInt64BE(p)); p += 8; return v; }, 5: () => { const v = buf.readFloatBE(p); p += 4; return v; }, 6: () => { const v = buf.readDoubleBE(p); p += 8; return v; },
    7: () => { const n = buf.readInt32BE(p); p += 4 + n; return null; }, 8: str,
    9: () => { const t = buf.readInt8(p++), n = buf.readInt32BE(p); p += 4; const a = []; for (let i = 0; i < n; i++) a.push(R[t]()); return a; },
    10: () => { const o = {}; for (;;) { const t = buf.readInt8(p++); if (!t) return o; const k = str(); o[k] = R[t](); } },
    11: () => { const n = buf.readInt32BE(p); p += 4 + 4 * n; return null; }, 12: () => { const n = buf.readInt32BE(p); p += 4 + 8 * n; return null; }
  };
  p++; str(); return R[10]();
}
function nbtServers(list) {
  const S = s => { const b = Buffer.from(s, 'utf8'), h = Buffer.alloc(2); h.writeUInt16BE(b.length); return Buffer.concat([h, b]); }, I = n => { const b = Buffer.alloc(4); b.writeInt32BE(n); return b; };
  const parts = [Buffer.from([10]), S(''), Buffer.from([9]), S('servers'), Buffer.from([10]), I(list.length)];
  for (const s of list) parts.push(Buffer.from([8]), S('name'), S(s.name), Buffer.from([8]), S('ip'), S(s.ip), Buffer.from([0]));
  parts.push(Buffer.from([0])); return Buffer.concat(parts);
}
function syncServers(dir, add) {
  const f = path.join(dir, 'servers.dat'); let cur = [];
  try { cur = (nbtParse(fs.readFileSync(f)).servers || []).map(s => ({ name: s.name, ip: s.ip })); } catch {}
  const have = new Set(cur.map(s => String(s.ip).toLowerCase())); let ch = false;
  for (const s of add) if (s.ip && !have.has(s.ip.toLowerCase())) { cur.push(s); have.add(s.ip.toLowerCase()); ch = true; }
  if (ch) { fs.mkdirSync(dir, { recursive: true }); fs.writeFileSync(f, nbtServers(cur)); }
}
const featured = () => {
  for (const f of [path.join(root, 'featured.json'), path.join(__dirname, 'assets', 'featured.json')]) {
    try { return JSON.parse(fs.readFileSync(f, 'utf8')).filter(s => s.name && s.addr); } catch {}
  }
  return [];
};

const PAGE = 30;
const edition = () => { try { return JSON.parse(fs.readFileSync(path.join(__dirname, 'assets', 'edition.json'), 'utf8')); } catch { return { edition: 'owner' }; } };
const POOL = [['Hypixel', 'mc.hypixel.net', 'Крупнейшая сеть мини-игр'], ['ReallyWorld', 'play.reallyworld.ru', 'Популярный русскоязычный сервер'], ['CubeCraft', 'play.cubecraft.net', 'Мини-игры'], ['The Hive', 'play.hivemc.com', 'Мини-игры'],
  ['Wynncraft', 'play.wynncraft.com', 'MMORPG'], ['2b2t', '2b2t.org', 'Анархия'], ['Minemen Club', 'minemen.club', 'PvP'], ['PikaNetwork', 'play.pika-network.net', 'Мини-игры и выживание'],
  ['Manacube', 'play.manacube.com', 'Prison, Skyblock'], ['Complex Gaming', 'hub.mc-complex.com', 'Мини-игры']].map(([name, addr, desc]) => ({ name, addr, desc }));
let featCache = { t: 0, list: [] };

const pingCache = new Map();
const PING_TTL = 60000;
const PING_ERR_TTL = 20000;
async function pingSrv(addr) {
  const key = String(addr || '').toLowerCase();
  const now = Date.now();
  const c = pingCache.get(key);
  if (c && now - c.t < (c.err ? PING_ERR_TTL : PING_TTL)) return c.v;
  try {
    const j = await getJson('https://api.mcsrvstat.us/3/' + encodeURIComponent(addr));
    const v = { online: !!j.online, players: j.players ? j.players.online : 0, max: j.players ? j.players.max : 0, ver: j.version || '', proto: (j.protocol && j.protocol.name) || '', modded: !!(j.mods && j.mods.length) };
    pingCache.set(key, { t: now, v }); return v;
  } catch (e) {
    const v = { online: false, players: 0, max: 0, ver: '', proto: '', err: true };
    pingCache.set(key, { t: now, v, err: true }); return v;
  }
}
async function featuredList() {
  if (getCfg().featured === false) return [];
  if (Date.now() - featCache.t < 300000 && featCache.list.length) return featCache.list;
  let base = featured(); const ed = edition();
  if (ed.edition === 'friends' && ed.featuredUrl) { try { const r = await getJson(ed.featuredUrl); if (Array.isArray(r)) { const v = r.filter(s => s && s.name && s.addr); if (v.length) base = v; } } catch {} }
  const curated = base.length > 0, list = curated ? base : POOL;
  const res = await Promise.all(list.map(async s => ({ ...s, ...(await pingSrv(s.addr)) })));
  let out = res.filter(s => s.online); if (!curated) out.sort((a, b) => b.players - a.players);
  out = (out.length ? out : res).slice(0, curated ? 12 : 8); featCache = { t: Date.now(), list: out }; return out;
}
const vcmp = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d; } return 0; };
function pickVersion(i, all, cur) {
  const ver = String(i.ver || '').replace(/\.x\b/gi, ''), vs = ver.match(/\d+\.\d+(?:\.\d+)?/g) || [], range = ver.match(/(\d+\.\d+(?:\.\d+)?)\s*[-–—]\s*(\d+\.\d+(?:\.\d+)?)/);
  let pick = /^\d+\.\d+(\.\d+)?$/.test(i.proto || '') && all.includes(i.proto) ? i.proto : null;
  if (range) {
    const lo = range[1], hi = range[2];
    if (cur && vcmp(cur, lo) >= 0 && vcmp(cur, hi) <= 0) return cur;
    if (!pick || vcmp(pick, lo) < 0 || vcmp(pick, hi) > 0) pick = all.filter(v => vcmp(v, lo) >= 0 && vcmp(v, hi) <= 0).sort(vcmp).pop() || pick;
  }
  return pick || vs.find(v => all.includes(v)) || null;
}
let relVers = null;
async function resolveServerVersion(addr, cur) {
  const info = await pingSrv(addr); if (!info.online) return { info };
  if (!relVers) relVers = (await getJson('https://launchermeta.mojang.com/mc/game/version_manifest_v2.json')).versions.filter(v => v.type === 'release').map(v => v.id);
  return { version: pickVersion(info, relVers, cur), info };
}
const CFB = 'https://api.curseforge.com/v1', CFCLASS = { mod: 6, resourcepack: 12, shader: 6552 }, CFLOAD = { forge: 1, fabric: 4, quilt: 5, neoforge: 6 };
async function cfGet(p) {
  const k = getCfg().cfkey || edition().cfkey;
  if (!k) {
    if (hub.configured && hub.token) return hub.call('GET', '/cf/v1' + p, undefined, { timeout: 20000 });
    throw new Error(hub.configured ? 'для CurseForge войди в аккаунт MNA (вкладка «Друзья») или введи свой API-ключ в настройках' : 'нужен API-ключ CurseForge (Настройки)');
  }
  let err;
  for (let i = 0; i < 3; i++) {
    try {
      const r = await fetch(CFB + p, { headers: { 'x-api-key': k, Accept: 'application/json', ...UA }, signal: AbortSignal.timeout(20000) });
      if (r.status === 401 || r.status === 403) throw new Error('HTTP 403: неверный API-ключ CurseForge');
      if (!r.ok) throw new Error('HTTP ' + r.status); return await r.json();
    } catch (e) { err = e; if (/HTTP 4/.test(e.message)) break; await sleep(700 * (i + 1)); }
  }
  throw new Error(/HTTP/.test(err.message) ? err.message : 'нет соединения с CurseForge');
}
async function cfSearch(c, t, o) {
  const sort = { relevance: 2, downloads: 6, updated: 3, newest: 11 }[o.sort || 'relevance'] || 2;
  let q = `/mods/search?gameId=432&classId=${CFCLASS[t]}&gameVersion=${encodeURIComponent(c.mc)}&searchFilter=${encodeURIComponent(o.q || '')}&sortField=${sort}&sortOrder=desc&pageSize=${PAGE}&index=${o.offset || 0}`;
  if (t === 'mod' && CFLOAD[c.loader]) q += `&modLoaderType=${CFLOAD[c.loader]}`;
  const j = await cfGet(q);
  return { total: j.pagination.totalCount, hits: j.data.map(h => ({ id: String(h.id), src: 'cf', title: h.name, desc: h.summary, dl: h.downloadCount, icon: h.logo && h.logo.thumbnailUrl })) };
}
async function cfFiles(id, c, t) {
  let q = `/mods/${id}/files?gameVersion=${encodeURIComponent(c.mc)}&pageSize=20`;
  if (t === 'mod' && CFLOAD[c.loader]) q += `&modLoaderType=${CFLOAD[c.loader]}`;
  return (await cfGet(q)).data.filter(f => f.isAvailable !== false).sort((a, b) => new Date(b.fileDate) - new Date(a.fileDate));
}
const cfHashes = f => { const h = {}; for (const x of f.hashes || []) { if (x.algo === 1) h.sha1 = x.value; else if (x.algo === 2) h.md5 = x.value; } return h; };
async function cfInstall(id, c, seen, t = 'mod') {
  const key = 'cf:' + id; if (seen.has(key)) return; seen.add(key);
  const fl = await cfFiles(id, c, t);
  if (!fl.length) throw new Error('CurseForge ' + id + ': нет версии для ' + c.mc + (t === 'mod' ? ' / ' + c.loader : ''));
  const f = fl[0], url = f.downloadUrl || `https://edge.forgecdn.net/files/${Math.floor(f.id / 1000)}/${f.id % 1000}/${f.fileName}`, fn = safeName(f.fileName), fp = path.join(inst(c), DIRS[t] || 'mods', fn);
  const hs = cfHashes(f);
  if (!fileOk(fp, hs)) await download(url, fp, hs);
  const r = recs(c);
  for (const [n, o] of Object.entries(r)) if (o.p === key && n !== fn) { try { fs.unlinkSync(path.join(inst(c), DIRS[o.t] || 'mods', safeName(n))); } catch {} delete r[n]; }
  r[fn] = { p: key, v: String(f.id), t, s: 'cf' }; fs.writeFileSync(recF(c), JSON.stringify(r));
  for (const d of f.dependencies || []) if (d.relationType === 3) await cfInstall(String(d.modId), c, seen).catch(() => {});
}
async function installMrpack(file, name) {
  try {
    send('status', 'Чтение сборки...');
    const raw = readZipFile(file, 'modrinth.index.json'); if (!raw) throw new Error('Это не сборка .mrpack: нет файла modrinth.index.json');
    const idx = JSON.parse(raw.toString('utf8')), d = idx.dependencies || {};
    const loader = d['neoforge'] ? 'neoforge' : d['forge'] ? 'forge' : d['fabric-loader'] ? 'fabric' : null;
    if (!loader) throw new Error(d['quilt-loader'] ? 'Сборки на Quilt пока не поддерживаются' : 'Поддерживаются сборки на NeoForge, Forge и Fabric');
    if (!d.minecraft) throw new Error('В сборке не указана версия Minecraft');
    const pack = safeId((name || idx.name || 'pack').replace(/[^\w.-]/g, '_')), c = { ...getCfg(), mc: d.minecraft, loader, pack }, dir = inst(c);
    // всё проверяем до скачивания: пути внутри папки сборки, ссылки только с разрешённых хостов, контрольные суммы обязательны
    const files = (idx.files || []).filter(f => !f.env || f.env.client !== 'unsupported').map(f => {
      const dest = path.join(dir, String(f.path || ''));
      if (!f.path || !inside(dir, dest)) throw new Error('В сборке небезопасный путь: ' + f.path);
      const url = (f.downloads || []).find(allowedPackUrl);
      if (!url) throw new Error('В сборке нет разрешённой ссылки для ' + f.path + ' (допустимы Modrinth, GitHub и GitLab)');
      if (!hasHashes(f.hashes)) throw new Error('В сборке нет контрольных сумм для ' + f.path);
      return { dest, url, hashes: f.hashes };
    }), q = [...files]; let n = 0;
    await Promise.all(Array.from({ length: 8 }, async () => { for (let f; (f = q.shift());) {
      if (!fileOk(f.dest, f.hashes)) await download(f.url, f.dest, f.hashes);
      send('progress', { type: 'моды', task: ++n, total: files.length }); } }));
    for (const o of ['overrides/', 'client-overrides/']) extractZip(file, dir, { map: nm => nm.startsWith(o) ? nm.slice(o.length) : null });
    fs.mkdirSync(root, { recursive: true });
    const g = getCfg(), lv = d['neoforge'] || d['forge'] || d['fabric-loader'];
    const instances = (g.instances || []).filter(i => i.id !== pack).concat({ id: pack, name: idx.name || pack, icon: '🎁', mc: c.mc, loader, lv });
    fs.writeFileSync(cfgFile, JSON.stringify({ ...g, mc: c.mc, loader, pack, lv, instances }, null, 2));
    return { mc: c.mc, loader, mods: files.length };
  } finally { try { fs.rmSync(file, { force: true }); } catch {} }
}
ipcMain.handle('packs:search', async (_, o) => {
  const j = await getJson(`https://api.modrinth.com/v2/search?limit=20&offset=${o.offset || 0}&index=downloads&query=${encodeURIComponent(o.q || '')}&facets=${encodeURIComponent(JSON.stringify([['project_type:modpack']]))}`);
  return { total: j.total_hits, hits: j.hits.map(h => ({ id: h.project_id, slug: h.slug, title: h.title, desc: h.description, dl: h.downloads, icon: h.icon_url })) };
});
ipcMain.handle('packs:install', async (_, p) => {
  const vs = await getJson(`https://api.modrinth.com/v2/project/${p.id}/version`), has = x => x.files.some(f => f.filename.endsWith('.mrpack'));
  const v = vs.find(x => x.version_type === 'release' && has(x)) || vs.find(has);
  if (!v) throw new Error('У сборки нет файла .mrpack');
  const f = v.files.find(x => x.filename.endsWith('.mrpack')), file = path.join(root, 'pack.mrpack');
  send('status', 'Скачивание сборки...'); await download(f.url, file); return installMrpack(file, p.slug);
});
ipcMain.handle('packs:url', async (_, url) => { const file = path.join(root, 'pack.mrpack'); await download(url, file); return installMrpack(file, ''); });
ipcMain.handle('repair', () => {
  try { fs.unlinkSync(path.join(root, 'loader-cache.json')); } catch {}
  for (const p of [['versions'], ['libraries', 'net', 'neoforged'], ['libraries', 'net', 'minecraftforge'], ['libraries', 'net', 'fabricmc']]) fs.rmSync(path.join(game, ...p), { recursive: true, force: true });
  return true;
});
ipcMain.handle('openlog', (_, w) => { const f = w === 'install' ? loaderLog : w === 'launch' ? path.join(root, 'last-launch.txt') : path.join(inst(getCfg()), 'logs', 'latest.log'); return fs.existsSync(f) ? shell.openPath(f) : ''; });
const idir = id => path.join(root, 'instances', safeId(id));
ipcMain.handle('inst:open', (_, id) => { if (!id) return false; const p = idir(id); fs.mkdirSync(p, { recursive: true }); shell.openPath(p); return true; });
ipcMain.handle('inst:delete', (_, id) => { if (!id) return false; fs.rmSync(idir(id), { recursive: true, force: true }); return true; });
ipcMain.handle('inst:copy', (_, o) => { if (!o || !o.from || !o.to) return false; const from = idir(o.from), to = idir(o.to); if (fs.existsSync(from)) fs.cpSync(from, to, { recursive: true }); return true; });
ipcMain.handle('featured:list', () => featuredList());
ipcMain.handle('edition:get', () => edition());
ipcMain.handle('featured:curated', () => featured());
ipcMain.handle('featured:save', (_, list) => { if (edition().edition !== 'owner') return false; fs.mkdirSync(root, { recursive: true }); fs.writeFileSync(path.join(root, 'featured.json'), JSON.stringify((list || []).filter(s => s.name && s.addr), null, 2)); featCache = { t: 0, list: [] }; return true; });
ipcMain.handle('featured:export', () => { if (edition().edition !== 'owner') return ''; const f = path.join(app.getPath('desktop'), 'featured-for-friends.json'); fs.writeFileSync(f, JSON.stringify(featured(), null, 2)); shell.showItemInFolder(f); return f; });
ipcMain.handle('worlds:list', () => {
  const d = path.join(inst(getCfg()), 'saves'); if (!fs.existsSync(d)) return [];
  return fs.readdirSync(d).map(n => {
    const f = path.join(d, n, 'level.dat'); if (!fs.existsSync(f)) return null;
    try { const t = nbtParse(zlib.gunzipSync(fs.readFileSync(f))).Data || {}; return { dir: n, name: t.LevelName || n, last: t.LastPlayed || 0, mode: t.GameType, ver: (t.Version || {}).Name || '' }; } catch { return { dir: n, name: n, last: 0 }; }
  }).filter(Boolean).sort((a, b) => b.last - a.last);
});
ipcMain.handle('worlds:open', () => { const d = path.join(inst(getCfg()), 'saves'); fs.mkdirSync(d, { recursive: true }); shell.openPath(d); return true; });
ipcMain.handle('worlds:delete', (_, n) => { if (!n) return false; fs.rmSync(path.join(inst(getCfg()), 'saves', safeName(n)), { recursive: true, force: true }); return true; });
ipcMain.handle('worlds:backup', async (_, n) => {
  if (!n) return false; const src = path.join(inst(getCfg()), 'saves', safeName(n)), out = path.join(root, 'backups'); fs.mkdirSync(out, { recursive: true });
  const zip = path.join(out, `${safeName(n)}-${Date.now()}.zip`); writeZip(zip, src, safeName(n)); shell.showItemInFolder(zip); return true;
});
ipcMain.handle('refocus', () => { if (win && !win.isDestroyed() && !win.webContents.isFocused()) win.webContents.focus(); return true; });
ipcMain.handle('cfg:get', () => getCfg());
ipcMain.handle('cfg:set', (_, c) => { fs.mkdirSync(root, { recursive: true }); fs.writeFileSync(cfgFile, JSON.stringify({ ...getCfg(), ...c }, null, 2)); return true; });
ipcMain.handle('folder', () => { const d = inst(getCfg()); fs.mkdirSync(d, { recursive: true }); shell.openPath(d); });
ipcMain.handle('versions', async () => (await getJson('https://launchermeta.mojang.com/mc/game/version_manifest_v2.json')).versions.map(v => ({ id: v.id, type: v.type, date: v.releaseTime.slice(0, 10) })));
const mrCache = new Map();
async function mrSearch(c, t, o) {
  const q = (o.q || '').trim(), enc = encodeURIComponent, off = o.offset || 0;
  const sort = !o.sort || o.sort === 'relevance' ? (q ? 'relevance' : 'downloads') : o.sort;
  const mk = withVer => { const f = [['project_type:' + t]]; if (withVer) f.push(['versions:' + c.mc]); if (t === 'mod' && c.loader !== 'vanilla') f.push(['categories:' + c.loader]); if (o.cat) f.push(['categories:' + o.cat]); return f; };
  const run = async (f, limit, offset) => getJson(`https://api.modrinth.com/v2/search?limit=${limit}&offset=${offset}&index=${sort}&query=${enc(q)}&facets=${enc(JSON.stringify(f))}`);
  let f = mk(true), ov = false, list, total;
  if (q && sort === 'relevance') {
    const key = JSON.stringify([q, f]); let h = mrCache.get(key);
    if (!h || Date.now() - h.t > 60000) { let j = await run(f, 100, 0); if (!j.total_hits) { f = mk(false); ov = true; j = await run(f, 100, 0); } h = { t: Date.now(), ov, total: j.total_hits, list: j.hits }; mrCache.set(key, h); }
    const ql = q.toLowerCase(), score = x => { const n = x.title.toLowerCase(); return (n === ql ? 5 : n.startsWith(ql) ? 3.5 : n.includes(ql) ? 2.2 : 1) * Math.log10((x.downloads || 0) + 10); };
    ov = h.ov; total = Math.min(h.total, 100);
    list = off >= 100 ? [] : [...h.list].sort((a, b) => score(b) - score(a)).slice(off, off + PAGE);
  } else {
    let j = await run(f, PAGE, off); if (!j.total_hits && q) { f = mk(false); ov = true; j = await run(f, PAGE, off); }
    total = j.total_hits; list = j.hits;
  }
  return { total, hits: list.map(h => ({ id: h.project_id, src: 'mr', title: h.title, desc: h.description, dl: h.downloads, icon: h.icon_url, ov })) };
}
ipcMain.handle('mods:search', async (_, o) => {
  const c = getCfg(), t = o.type || 'mod', repo = c.repo || 'modrinth', off = o.offset || 0, jobs = [];
  if (repo !== 'curseforge') jobs.push(mrSearch(c, t, o)); if (repo !== 'modrinth') jobs.push(cfSearch(c, t, o));
  const res = await Promise.allSettled(jobs), ok = res.filter(r => r.status === 'fulfilled').map(r => r.value), bad = res.find(r => r.status === 'rejected');
  if (!ok.length) throw bad.reason;
  const have = new Set(Object.values(recs(c)).map(x => x.p)); let hits = [];
  if (ok.length === 1) hits = ok[0].hits;
  else { const names = new Set(ok[0].hits.map(h => h.title.toLowerCase())), b2 = ok[1].hits.filter(h => !names.has(h.title.toLowerCase()));
    for (let i = 0; i < Math.max(ok[0].hits.length, b2.length); i++) { if (ok[0].hits[i]) hits.push(ok[0].hits[i]); if (b2[i]) hits.push(b2[i]); } }
  return { total: ok.reduce((a2, r) => a2 + r.total, 0), more: ok.some(r => r.total > off + PAGE), warn: bad ? String(bad.reason.message) : '', hits: hits.map(h => ({ ...h, have: have.has(h.src === 'cf' ? 'cf:' + h.id : h.id) })) };
});
ipcMain.handle('mods:install', async (_, o) => { const c = getCfg(), t = o.type || 'mod'; if (o.src === 'cf') await cfInstall(o.id, c, new Set(), t); else await installMod(o.id, c, new Set(), t); return true; });
ipcMain.handle('mods:pack', async (_, name) => {
  const c = getCfg(); if (c.loader === 'vanilla') throw new Error('Выбери загрузчик');
  const seen = new Set(), list = PACKS[name].filter(s => c.loader === 'fabric' || !['fabric-api', 'modmenu'].includes(s));
  const res = await Promise.allSettled(list.map(s => installMod(s, c, seen)));
  const ok = res.filter(r => r.status === 'fulfilled').length; return { ok, fail: res.length - ok };
});
ipcMain.handle('mods:update', async () => {
  const c = getCfg(); let n = 0; const rs = Object.values(recs(c)), isCf = o => String(o.p).startsWith('cf:');
  const mr = [...new Map(rs.filter(o => !isCf(o)).map(o => [o.p, o.t || 'mod'])).entries()];
  await Promise.all(mr.map(async ([p, t]) => {
    const vs = await getJson(`https://api.modrinth.com/v2/project/${p}/version?${vq(c, t)}`).catch(() => []);
    const cur = Object.values(recs(c)).find(o => o.p === p);
    if (vs[0] && cur && vs[0].id !== cur.v) { await installMod(p, c, new Set(), t).catch(() => {}); n++; }
  }));
  for (const [p, t] of [...new Map(rs.filter(isCf).map(o => [o.p, o.t || 'mod'])).entries()]) {
    try { const id = p.slice(3), fl = await cfFiles(id, c, t), cur = Object.values(recs(c)).find(o => o.p === p);
      if (fl[0] && cur && String(fl[0].id) !== cur.v) { await cfInstall(id, c, new Set(), t); n++; } } catch {}
  }
  return n;
});
ipcMain.handle('mods:list', (_, t) => {
  const c = getCfg(), type = t || 'mod';
  const d = path.join(inst(c), DIRS[type] || 'mods');
  if (!fs.existsSync(d)) return [];
  return fs.readdirSync(d).filter(f => {
    let st; try { st = fs.statSync(path.join(d, f)); } catch { return false; }
    if (st.isDirectory()) return type !== 'mod';
    return type === 'mod' ? f.endsWith('.jar') : /\.(zip|jar)$/i.test(f);
  });
});
ipcMain.handle('mods:remove', (_, o) => {
  const c = getCfg(), b = safeName(o.n), fp = path.join(inst(c), DIRS[o.t] || 'mods', b);
  fs.rmSync(fp, { recursive: true, force: true });
  const r = recs(c); delete r[b]; fs.writeFileSync(recF(c), JSON.stringify(r)); return true;
});
const tokF = path.join(root, 'auth.bin');
async function mcAuth(interactive) {
  const am = new Auth('select_account'); let xbox;
  try { xbox = await am.refresh(safeStorage.decryptString(fs.readFileSync(tokF))); }
  catch { if (!interactive) return null; xbox = await am.launch('electron'); }
  try { fs.mkdirSync(root, { recursive: true }); fs.writeFileSync(tokF, safeStorage.encryptString(xbox.save())); } catch {}
  const mc = await xbox.getMinecraft(); session = mc.mclc(); return mc.profile.name;
}
ipcMain.handle('login', () => mcAuth(true));
ipcMain.handle('autologin', () => mcAuth(false).catch(() => null));
ipcMain.handle('logout', () => { session = null; try { fs.unlinkSync(tokF); } catch {} return true; });
ipcMain.handle('news', async () => {
  try { const j = await getJson('https://launchercontent.mojang.com/v2/javaPatchNotes.json');
    return j.entries.slice(0, 3).map(e => ({ t: e.title, d: e.shortText, v: e.version, i: e.image && e.image.url ? (e.image.url.startsWith('http') ? e.image.url : 'https://launchercontent.mojang.com' + e.image.url) : '' })); } catch { return []; }
});
ipcMain.handle('mods:add', (_, o) => {
  const c = getCfg();
  const p = typeof o === 'string' ? o : (o && o.path);
  const t = (o && typeof o === 'object' && o.type) || 'mod';
  if (typeof p !== 'string') return false;
  const ext = t === 'mod' ? /\.jar$/i : /\.(zip|jar)$/i;
  if (!ext.test(p)) return false;
  const d = path.join(inst(c), DIRS[t] || 'mods');
  fs.mkdirSync(d, { recursive: true });
  fs.copyFileSync(p, path.join(d, safeName(path.basename(p))));
  return true;
});
ipcMain.handle('server', async () => {
  try { const c0 = getCfg(), a0 = (c0.servers && c0.servers[0] && c0.servers[0].addr) || (c0.server !== 'play.example.com' ? c0.server : ''); if (!a0) return { online: false, none: true }; const p = await pingSrv(a0); return { online: p.online, players: p.online ? `${p.players}/${p.max}` : '' }; } catch { return { online: false }; }
});
ipcMain.handle('srv:ping', async (_, a) => {
  const p = await pingSrv(a);
  return { online: p.online, players: p.online ? `${p.players}/${p.max}` : '', version: p.ver || '', err: !!p.err };
});
ipcMain.handle('play', async (_, arg) => {
  const c = getCfg(), addr = typeof arg === 'string' ? arg : arg && arg.server, world = arg && typeof arg === 'object' && 'world' in arg ? arg.world : null, create = !!(arg && arg.create);
  try {
    if (gameRunning) { send('status', 'Игра уже запущена. Закрой её, чтобы запустить другую'); return false; }
    if (addr && !ADDR_RE.test(addr)) throw new Error('Неверный адрес сервера');
    const gate = session ? '' : hubGate(); if (gate) throw new Error(gate);
    const io = (c.instances || []).find(i => i.id === c.pack); if (io && io.ram) c.ram = io.ram;
    if (addr && c.autover !== false) {
      send('status', 'Определяю версию сервера…');
      try {
        const r = await resolveServerVersion(addr, c.mc);
        if (r.info && r.info.modded) send('status', 'Сервер с модами: использую твою сборку');
        else if (r.version && r.version !== c.mc) { send('status', 'Версия сервера ' + r.version + ': запускаю её'); Object.assign(c, { mc: r.version, loader: 'vanilla', pack: 'srv-' + r.version, lv: '' }); }
      } catch {}
    }
    c.java = await javaFor(c);
    const modern = c.mc.split('.')[0] !== '1' || +c.mc.split('.')[1] >= 20;
    let qp;
    if (addr) qp = { type: modern ? 'multiplayer' : 'legacy', identifier: addr, path: modern ? 'quickPlay/log.json' : undefined };
    else if (world !== null || create) {
      if (!modern) throw new Error('Быстрый вход в мир доступен с Minecraft 1.20');
      const sd = path.join(inst(c), 'saves'), nw = fs.existsSync(sd) ? fs.readdirSync(sd).filter(n => fs.existsSync(path.join(sd, n, 'level.dat'))).length : 0;
      if (create && nw) send('status', 'Создай мир в игре: Одиночная игра → Создать новый мир'); else qp = { type: 'singleplayer', identifier: world || '', path: 'quickPlay/log.json' };
    }
    const custom = c.loader === 'vanilla' ? undefined : await ensureLoader(c);
    fs.mkdirSync(inst(c), { recursive: true });
    try { syncServers(inst(c), [...(c.featured !== false ? (featCache.list.length ? featCache.list : featured()) : []), ...(c.servers || [])].map(s => ({ name: s.name, ip: s.addr }))); } catch {}
    const l = new Client();
    l.on('progress', p => send('progress', p));
    l.on('debug', m => send('log', m)); l.on('data', m => send('log', m));
    l.on('arguments', a => { try { const i = a.indexOf('--accessToken'); fs.writeFileSync(path.join(root, 'last-launch.txt'), [c.java, ...a.map((x, k) => i >= 0 && k === i + 1 ? '***' : x)].join('\n')); } catch {} });
    l.on('close', () => { gameRunning = false; hub.setPresence('online', ''); send('closed'); if (hidden) showLauncher(); else if (win && !win.isDestroyed() && win.isMinimized()) win.restore(); });
    send('status', 'Запуск...');
    const proc = await l.launch({
      authorization: session || Authenticator.getAuth(hub.user ? hub.user.nick : c.nick), root: game, javaPath: c.java,
      version: { number: c.mc, type: 'release', custom }, memory: { max: c.ram + 'G', min: Math.max(1, Math.floor(c.ram / 2)) + 'G' }, customArgs: [...(['neoforge', 'forge'].includes(c.loader) ? loaderJvm(custom) : []), ...(c.fast ? FAST : [])],
      overrides: { gameDirectory: inst(c), maxSockets: 16 },
      quickPlay: qp, window: c.fullscreen ? { fullscreen: true } : undefined
    });
    gameRunning = true; hub.setPresence('ingame', addr || '');
    const mode = c.onlaunch === 'reopen' ? 'hide' : (c.onlaunch || (c.min ? 'min' : 'hide'));
    if (mode === 'hide') { send('status', 'Игра запущена. Лаунчер скроется и вернётся после выхода из игры'); setTimeout(() => { if (gameRunning) hideLauncher(); }, 3000); }
    else if (mode === 'quit') {
      send('status', 'Игра запущена. Лаунчер закроется и вернётся после выхода из игры');
      setTimeout(() => {
        if (!gameRunning) return;
        const pid = proc && proc.pid;
        if (pid) { spawnRelauncher(pid, 2000); setTimeout(() => app.quit(), 150); }
        else send('status', 'Не удалось определить PID игры — лаунчер останется открытым');
      }, 4000);
    }
    else if (mode === 'close') { send('status', 'Игра запущена, лаунчер закроется…'); setTimeout(() => app.quit(), 6000); }
    else if (mode === 'min') { send('status', 'Игра запущена'); setTimeout(() => { if (win && !win.isDestroyed()) win.minimize(); }, 1500); }
    return true;
  } catch (e) { send('status', 'Ошибка: ' + e.message); send('closed'); return false; }
});

// ---------- MNA Hub: уникальные ники, друзья, чат, приглашения ----------
const hub = new Hub(UA), hubFile = path.join(root, 'hub.bin');
const hubUrlCfg = () => String(getCfg().hubUrl || edition().hubUrl || '').trim();
const hubGate = () => edition().requireAccount === true && hub.configured && !hub.token ? 'Войди в аккаунт MNA (вкладка «Друзья») или через Microsoft: в этой версии ники уникальны' : '';
const noFriends = () => ({ friends: [], incoming: [], outgoing: [] });
let HF = noFriends(), viewing = null, pendingOpen = null, incomingSeen = null, savedSig = '', lastTier = '', hubErr = '';
const invites = [], ev = (t, d) => send('hub:ev', { t, d });
const focused = () => !!(win && !win.isDestroyed() && win.isFocused());
function notify(title, body, openId) {
  try {
    if (!Notification.isSupported()) return;
    const n = new Notification({ title, body: String(body || '').slice(0, 140) });
    n.on('click', () => { if (win && !win.isDestroyed()) { showLauncher(); ev('open', { id: openId || null }); } else { pendingOpen = openId || null; showLauncher(); } });
    n.show();
  } catch {}
}
async function refreshFriends() {
  if (!hub.token) { HF = noFriends(); incomingSeen = null; return ev('friends', HF); }
  try {
    HF = await hub.friends();
    const ids = new Set(HF.incoming.map(x => x.id));
    if (incomingSeen) for (const f of HF.incoming) if (!incomingSeen.has(f.id) && !focused()) notify('Заявка в друзья', f.nick + ' хочет добавить тебя в друзья');
    incomingSeen = ids; ev('friends', HF);
  } catch {}
}
function onHubMessage(m) {
  const mine = hub.user && m.from === hub.user.id, fid = mine ? m.to : m.from, f = HF.friends.find(x => x.id === fid);
  ev('message', m);
  if (mine) return;
  if (!f) refreshFriends();
  if (focused() && viewing === fid) { hub.markRead(fid).catch(() => {}); return; }
  const nick = f ? f.nick : 'Друг';
  if (f) { f.unread = (f.unread || 0) + 1; ev('friends', HF); }
  if (m.type === 'invite') {
    const inv = { id: m.id, from: fid, nick, server: m.server, note: m.text || '', ts: m.ts };
    invites.push(inv); if (invites.length > 20) invites.shift(); ev('invite', inv);
    notify(nick + ' приглашает в игру', 'Сервер: ' + m.server + (m.text ? ' · ' + m.text : ''), fid);
  } else notify(nick, m.text, fid);
}
hub.on('state', s => {
  ev('state', s);
  const sig = hub.token ? hub.token + JSON.stringify(hub.user || {}) : '';
  if (sig !== savedSig) {
    savedSig = sig;
    try { if (hub.token) { fs.mkdirSync(root, { recursive: true }); fs.writeFileSync(hubFile, safeStorage.encryptString(JSON.stringify({ url: hub.base, token: hub.token, user: hub.user }))); } else fs.rmSync(hubFile, { force: true }); } catch {}
    if (!hub.token) refreshFriends();
  }
  const tn = tierNow(); if (tn !== lastTier) { lastTier = tn; applyIcons(); ev('tier', themePayload()); }
});
hub.on('auth-lost', () => { ev('lost', {}); });
hub.on('event', ({ type, data }) => {
  if (type === 'hello' || type === 'friends') refreshFriends();
  else if (type === 'presence') {
    const f = HF.friends.find(x => x.id === data.id);
    if (f) { Object.assign(f, { online: data.online, state: data.state, server: data.server }); HF.friends.sort((x, y) => (y.online - x.online) || x.nick.localeCompare(y.nick)); ev('friends', HF); } else refreshFriends();
  } else if (type === 'message') onHubMessage(data);
  else if (type === 'room') ev('room', data);
  else if (type === 'lroom') ev('lroom', data);
});
function hubInit() {
  try { hub.configure(hubUrlCfg()); hubErr = ''; } catch (e) { hubErr = e.message; }
  if (!hub.configured) return;
  try { const j = JSON.parse(safeStorage.decryptString(fs.readFileSync(hubFile))); if (j && j.url === hub.base && j.token) { savedSig = j.token + JSON.stringify(j.user || {}); hub.restore(j.token, j.user); } } catch {}
  if (hub.token) hub.connect();
}
const H = (name, fn) => ipcMain.handle('hub:' + name, async (_, a) => fn(a || {}));
H('snapshot', () => {
  const now = Date.now(); for (let i = invites.length - 1; i >= 0; i--) if (now - invites[i].ts > 30 * 60e3) invites.splice(i, 1);
  const open = pendingOpen; pendingOpen = null;
  return { state: hub.snapshot(), friends: HF, invites, open, err: hubErr, gate: hubGate(), strict: edition().requireAccount === true };
});
H('info', () => hub.info());
H('register', a => hub.register(String(a.nick || '').trim(), String(a.password || ''), a.code ? String(a.code) : undefined));
H('login', a => hub.login(String(a.nick || '').trim(), String(a.password || '')));
H('logout', async () => { await hub.logout(); return true; });
H('nickfree', a => hub.nickFree(String(a.nick || '')));
H('request', a => hub.request(String(a.nick || '').trim()));
H('accept', a => hub.accept(String(a.id || '')));
H('decline', a => hub.decline(String(a.id || '')));
H('remove', a => hub.remove(String(a.id || '')));
H('history', a => hub.history(String(a.id || ''), +a.before || 0));
H('send', a => hub.send(String(a.id || ''), String(a.text || '')));
H('invite', a => { const srv = String(a.server || '').trim(); if (!ADDR_RE.test(srv)) throw new Error('Неверный адрес сервера'); return hub.invite(String(a.id || ''), srv, String(a.note || '')); });
H('read', async a => { const f = HF.friends.find(x => x.id === a.id); if (f && f.unread) { f.unread = 0; ev('friends', HF); } await hub.markRead(String(a.id || '')).catch(() => {}); return true; });
H('view', a => { viewing = a.id || null; return true; });
H('dismiss', a => { const i = invites.findIndex(x => x.id === a.id); if (i >= 0) invites.splice(i, 1); return true; });
H('room', a => hub.room(a.kind === 'local' ? 'local' : 'global', +a.before || 0));
H('roomsend', a => hub.roomSend(a.kind === 'local' ? 'local' : 'global', String(a.text || '')));
H('redeem', a => hub.redeem(String(a.code || '')));
H('style', a => hub.setStyle(a.style === null ? null : Tiers.normalizeStyle(a.style)));
H('password', a => hub.changePassword(String(a.old || ''), String(a.new || '')));
H('seturl', a => {
  const u = Hub.normalize(a.url || ''); fs.mkdirSync(root, { recursive: true });
  fs.writeFileSync(cfgFile, JSON.stringify({ ...getCfg(), hubUrl: u }, null, 2)); hubInit(); refreshFriends(); return hub.snapshot();
});

// ---------- Внешний вид и уровни ----------
const customDir = path.join(root, 'custom'), logoF = path.join(customDir, 'logo.png'), bgF = path.join(customDir, 'bg.jpg');
const tierNow = () => (edition().edition === 'owner' ? 'admin' : (hub.token && hub.user && hub.user.tier) || 'free');
const themeNow = () => Tiers.sanitizeTheme(getCfg().theme, tierNow());
function iconImg() {
  try { if (themeNow().logo && fs.existsSync(logoF)) { const i = nativeImage.createFromPath(logoF); if (!i.isEmpty()) return i; } } catch {}
  return nativeImage.createFromPath(ICON);
}
function applyIcons() {
  try { if (win && !win.isDestroyed() && win.setIcon) win.setIcon(iconImg()); if (tray && tray.setImage) tray.setImage(iconImg().resize({ width: 16, height: 16 })); } catch {}
}
const dataUrl = (f, mime) => { try { return fs.existsSync(f) ? `data:${mime};base64,` + fs.readFileSync(f).toString('base64') : ''; } catch { return ''; } };
function themePayload() {
  const th = themeNow(), tier = tierNow();
  return { theme: th, tier, tierName: Tiers.tierName(tier), can: Object.fromEntries(Object.keys(Tiers.MIN).map(k => [k, Tiers.can(tier, k)])),
    logo: th.logo ? dataUrl(logoF, 'image/png') : '', bg: th.bgMode === 'image' ? dataUrl(bgF, 'image/jpeg') : '', hasBg: fs.existsSync(bgF), hasLogo: fs.existsSync(logoF) };
}
function setTheme(patch) {
  const prev = getCfg().theme || {}, tier = tierNow();
  let th = Tiers.sanitizeTheme({ ...prev, ...patch }, tier);
  // Запрос на недоступный или некорректный фон не должен стирать прежний: оставляем то, что было
  if (patch.bgMode && patch.bgMode !== 'none' && th.bgMode !== patch.bgMode) th = Tiers.sanitizeTheme({ ...prev, ...patch, bgMode: prev.bgMode, bgUrl: prev.bgUrl, bgFile: prev.bgFile }, tier);
  fs.mkdirSync(root, { recursive: true }); fs.writeFileSync(cfgFile, JSON.stringify({ ...getCfg(), theme: th }, null, 2)); applyIcons(); return th;
}
function readImage(p, maxMB) {
  const st = fs.statSync(p); if (!st.isFile()) throw new Error('Это не файл');
  if (st.size > maxMB * 1048576) throw new Error('Файл слишком большой (максимум ' + maxMB + ' МБ)');
  const img = nativeImage.createFromPath(p);
  if (img.isEmpty()) throw new Error('Не удалось прочитать картинку. Подойдут PNG и JPG.');
  return img;
}
const need = (f, lvl) => { if (!Tiers.can(tierNow(), f)) throw new Error(lvl + ' и выше: эта возможность закрыта на твоём уровне'); };
ipcMain.handle('theme:get', () => themePayload());
ipcMain.handle('theme:set', (_, patch) => { setTheme(patch && typeof patch === 'object' ? patch : {}); return themePayload(); });
ipcMain.handle('theme:pickLogo', async () => {
  need('logo', 'Plus');
  const r = await dialog.showOpenDialog(win, { title: 'Логотип лаунчера', properties: ['openFile'], filters: [{ name: 'Изображения', extensions: ['png', 'jpg', 'jpeg'] }] });
  if (r.canceled || !r.filePaths[0]) return null;
  let img = readImage(r.filePaths[0], 12); const z = img.getSize();
  if (Math.max(z.width, z.height) > 256) img = img.resize(z.width >= z.height ? { width: 256 } : { height: 256 });
  fs.mkdirSync(customDir, { recursive: true }); fs.writeFileSync(logoF, img.toPNG()); setTheme({ logo: true }); return themePayload();
});
ipcMain.handle('theme:pickBg', async () => {
  need('bgImage', 'Plus+');
  const r = await dialog.showOpenDialog(win, { title: 'Фон лаунчера', properties: ['openFile'], filters: [{ name: 'Изображения', extensions: ['png', 'jpg', 'jpeg'] }] });
  if (r.canceled || !r.filePaths[0]) return null;
  let img = readImage(r.filePaths[0], 25); const z = img.getSize(); if (z.width > 1920) img = img.resize({ width: 1920 });
  let buf = img.toJPEG(88); if (buf.length > 8 * 1048576) buf = img.toJPEG(65);
  fs.mkdirSync(customDir, { recursive: true }); fs.writeFileSync(bgF, buf); setTheme({ bgMode: 'image', bgFile: true }); return themePayload();
});
ipcMain.handle('theme:clear', (_, what) => {
  if (what === 'logo') { fs.rmSync(logoF, { force: true }); setTheme({ logo: false }); }
  else if (what === 'bg') { fs.rmSync(bgF, { force: true }); setTheme({ bgMode: 'none', bgFile: false, bgUrl: '' }); }
  else if (what === 'all') { fs.rmSync(customDir, { recursive: true, force: true }); const c = getCfg(); delete c.theme; fs.writeFileSync(cfgFile, JSON.stringify(c, null, 2)); applyIcons(); }
  return themePayload();
});
ipcMain.handle('game:running', () => gameRunning);
ipcMain.handle('buy', (_, a) => {
  const u = String((a && a.url) || ''); if (!/^https:\/\/[^\s"'<>]+$/.test(u)) throw new Error('Ссылка на оплату недоступна');
  shell.openExternal(u); return true;
});

function createWindow() {
  win = new BrowserWindow({ width: 1180, height: 740, minWidth: 980, minHeight: 640, backgroundColor: '#050b1a', autoHideMenuBar: true,
    icon: iconImg(), webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, sandbox: true, nodeIntegration: false, backgroundThrottling: true, spellcheck: false, v8CacheOptions: 'bypassHeatCheck' } });
  win.loadFile('index.html');
  win.on('focus', () => { if (win && !win.isDestroyed()) win.webContents.focus(); });
  win.on('minimize', () => send('power', 'min'));
  win.on('restore', () => send('power', 'on'));
  win.on('closed', () => { win = null; viewing = null; });
}
function hideLauncher() {
  hidden = true; viewing = null;
  if (win && !win.isDestroyed()) win.destroy();
  if (!tray) {
    tray = new Tray(iconImg().resize({ width: 16, height: 16 }));
    tray.setToolTip('MNA Launcher: идёт игра, лаунчер вернётся после выхода');
    tray.setContextMenu(Menu.buildFromTemplate([{ label: 'Открыть лаунчер', click: showLauncher }, { label: 'Выйти', click: () => { hidden = false; app.quit(); } }]));
    tray.on('click', showLauncher);
  }
}
function showLauncher() {
  hidden = false;
  if (tray) { tray.destroy(); tray = null; }
  if (!win || win.isDestroyed()) createWindow(); else { win.show(); win.focus(); }
}
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) app.quit();
app.on('second-instance', () => { if (hidden || !win) showLauncher(); else { if (win.isMinimized()) win.restore(); win.show(); win.focus(); } });
app.whenReady().then(() => { if (gotLock) { hubInit(); createWindow(); } });
app.on('window-all-closed', () => { if (!hidden) app.quit(); });
