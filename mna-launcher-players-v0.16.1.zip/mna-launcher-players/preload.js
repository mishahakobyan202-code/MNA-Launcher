const { contextBridge, ipcRenderer, webUtils } = require('electron');
contextBridge.exposeInMainWorld('mna', {
  invoke: (ch, d) => ipcRenderer.invoke(ch, d),
  on: (ch, fn) => ipcRenderer.on(ch, (_, d) => fn(d)),
  pathFor: f => webUtils.getPathForFile(f)
});
