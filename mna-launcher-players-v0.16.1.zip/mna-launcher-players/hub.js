'use strict';
// Клиент MNA Hub: вход, друзья, чат, приглашения. Не зависит от Electron, поэтому проверяется обычным Node.
const { EventEmitter } = require('events');
const sleep = ms => new Promise(r => setTimeout(r, ms));
const isLocal = h => { h = String(h).toLowerCase(); return h === 'localhost' || h === '[::1]' || /^(127|10)(\.\d{1,3}){3}$/.test(h) || /^192\.168(\.\d{1,3}){2}$/.test(h) || /^172\.(1[6-9]|2\d|3[01])(\.\d{1,3}){2}$/.test(h); };

class Hub extends EventEmitter {
  constructor(headers) {
    super();
    this.h = headers || {};
    this.base = ''; this.token = ''; this.user = null; this.connected = false;
    this.presence = { state: 'online', server: '' };
    this._gen = 0; this._ctl = null;
  }
  // Приводит адрес к виду https://host[:port][/path]; http разрешён только для localhost и домашней сети.
  static normalize(u) {
    u = String(u || '').trim(); if (!u) return '';
    if (!/^https?:\/\//i.test(u)) u = 'https://' + u;
    let x; try { x = new URL(u); } catch { throw new Error('Неверный адрес Hub'); }
    if (x.protocol === 'http:' && !isLocal(x.hostname)) throw new Error('Адрес Hub должен начинаться с https://, иначе пароль уйдёт открытым текстом');
    return x.origin + x.pathname.replace(/\/+$/, '');
  }
  configure(url) { const b = Hub.normalize(url); if (b !== this.base) { this.disconnect(); this.base = b; this._clearAuth(); } this._state(); return b; }
  get configured() { return !!this.base; }
  snapshot() { return { configured: !!this.base, url: this.base, loggedIn: !!this.token, user: this.user, connected: this.connected }; }
  _state() { this.emit('state', this.snapshot()); }
  _clearAuth() { this.token = ''; this.user = null; }

  async call(method, path, body, opts = {}) {
    if (!this.base) throw new Error('Hub не настроен');
    let r;
    try {
      r = await fetch(this.base + path, {
        method, headers: { ...this.h, 'Content-Type': 'application/json', ...(this.token && !opts.anon ? { Authorization: 'Bearer ' + this.token } : {}) },
        body: body === undefined || body === null ? undefined : JSON.stringify(body), signal: AbortSignal.timeout(opts.timeout || 15000)
      });
    } catch { const e = new Error('Hub недоступен, проверь адрес и интернет'); e.status = 0; throw e; }
    let j = {}; try { j = await r.json(); } catch {}
    if (!r.ok) {
      const e = new Error(j.error || 'Ошибка Hub (HTTP ' + r.status + ')'); e.status = r.status;
      if (r.status === 401 && this.token && !opts.anon) this._lost();
      throw e;
    }
    return j;
  }
  info() { return this.call('GET', '/api/info', undefined, { anon: true, timeout: 8000 }); }
  async register(nick, password, code) { return this._auth(await this.call('POST', '/api/register', { nick, password, code }, { anon: true })); }
  async login(nick, password) { return this._auth(await this.call('POST', '/api/login', { nick, password }, { anon: true })); }
  _auth(j) { this.token = j.token; this.user = j.user; this._state(); this.connect(); return j.user; }
  restore(token, user) { if (token && user) { this.token = token; this.user = user; this._state(); } }
  async logout() { try { if (this.token) await this.call('POST', '/api/logout', {}, { timeout: 5000 }); } catch {} this.disconnect(); this._clearAuth(); this._state(); }
  _lost() { this.disconnect(); this._clearAuth(); this._state(); this.emit('auth-lost'); }

  setPresence(state, server) {
    this.presence = { state: state === 'ingame' ? 'ingame' : 'online', server: server || '' };
    if (this.connected) this._sendPresence();
  }
  _sendPresence() { this.call('POST', '/api/presence', this.presence).catch(() => {}); }

  connect() {
    if (!this.token || !this.base || this._ctl) return;
    const gen = ++this._gen; this._loop(gen);
  }
  disconnect() {
    this._gen++;
    if (this._ctl) { try { this._ctl.abort(); } catch {} this._ctl = null; }
    if (this.connected) { this.connected = false; this._state(); }
  }
  async _loop(gen) {
    let delay = 1000;
    while (this._gen === gen) {
      try { if (await this._stream(gen)) delay = 1000; }
      catch (e) { if (e.status === 401) { if (this._gen === gen) this._lost(); return; } }
      if (this._gen !== gen) return;
      this._ctl = null;
      if (this.connected) { this.connected = false; this._state(); }
      await sleep(delay); delay = Math.min(delay * 2, 30000);
      if (this._gen !== gen) return;
    }
  }
  // Возвращает true, если соединение было установлено (hello получен).
  async _stream(gen) {
    const ctl = new AbortController(); this._ctl = ctl;
    let idle; const arm = () => { clearTimeout(idle); idle = setTimeout(() => ctl.abort(), 60000); };
    arm(); let hello = false;
    try {
      const r = await fetch(this.base + '/api/events', { headers: { ...this.h, Authorization: 'Bearer ' + this.token }, signal: ctl.signal });
      if (r.status === 401) { const e = new Error('401'); e.status = 401; throw e; }
      if (!r.ok) throw new Error('HTTP ' + r.status);
      const rd = r.body.getReader(), dec = new TextDecoder(); let buf = '';
      for (;;) {
        const { done, value } = await rd.read(); if (done) break; arm();
        buf += dec.decode(value, { stream: true }).replace(/\r\n/g, '\n');
        let i; while ((i = buf.indexOf('\n\n')) >= 0) {
          const blk = buf.slice(0, i); buf = buf.slice(i + 2);
          const ev = /^event: (.+)$/m.exec(blk), d = /^data: (.+)$/m.exec(blk); if (!ev || !d || this._gen !== gen) continue;
          let data; try { data = JSON.parse(d[1]); } catch { continue; }
          if (ev[1] === 'me' && data.user) { this.user = data.user; this._state(); }
          if (ev[1] === 'hello') { hello = true; if (data.me) this.user = data.me; this.connected = true; if (this.presence.state !== 'online') this._sendPresence(); this._state(); }
          try { this.emit('event', { type: ev[1], data }); } catch (e) { console.error('Hub: ошибка обработчика события:', e); }
        }
      }
    } finally { clearTimeout(idle); }
    return hello;
  }

  friends() { return this.call('GET', '/api/friends'); }
  request(nick) { return this.call('POST', '/api/friends/request', { nick }); }
  accept(id) { return this.call('POST', '/api/friends/accept', { id }); }
  decline(id) { return this.call('POST', '/api/friends/decline', { id }); }
  remove(id) { return this.call('POST', '/api/friends/remove', { id }); }
  history(id, before) { return this.call('GET', `/api/chat/${encodeURIComponent(id)}?limit=50` + (before ? '&before=' + before : '')); }
  send(id, text) { return this.call('POST', `/api/chat/${encodeURIComponent(id)}`, { text }); }
  markRead(id) { return this.call('POST', `/api/chat/${encodeURIComponent(id)}/read`, {}); }
  invite(to, server, note) { return this.call('POST', '/api/invite', { to, server, note }); }
  nickFree(nick) { return this.call('GET', '/api/nick/' + encodeURIComponent(nick), undefined, { anon: true, timeout: 8000 }); }
  room(kind, before) { return this.call('GET', `/api/room/${kind}?limit=50` + (before ? '&before=' + before : '')); }
  roomSend(kind, text) { return this.call('POST', `/api/room/${kind}`, { text }); }
  async redeem(code) { const j = await this.call('POST', '/api/redeem', { code }); if (j.user) { this.user = j.user; this._state(); } return j.user; }
  async setStyle(style) { const j = await this.call('POST', '/api/profile/style', { style }); if (j.user) { this.user = j.user; this._state(); } return j.user; }
  changePassword(oldPw, newPw) { return this.call('POST', '/api/account/password', { old: oldPw, new: newPw }); }
}

module.exports = { Hub };
