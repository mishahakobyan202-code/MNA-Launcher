'use strict';
// Сеть: JSON-запросы с повторами и скачивание файлов с проверкой контрольных сумм.
const fs = require('fs'), path = require('path'), crypto = require('crypto');

const sleep = ms => new Promise(r => setTimeout(r, ms));
const ALGOS = ['sha512', 'sha256', 'sha1', 'md5'];

// hashes: { sha1, sha256, sha512, md5 } в hex. Возвращает название первой несовпавшей суммы или ''.
function badHash(buf, hashes) {
  for (const a of ALGOS) {
    const want = hashes && hashes[a]; if (!want) continue;
    if (crypto.createHash(a).update(buf).digest('hex') !== String(want).toLowerCase()) return a;
  }
  return '';
}
const hasHashes = h => !!h && ALGOS.some(a => h[a]);

function createNet(headers) {
  async function getJson(u, opts = {}) {
    let err;
    for (let i = 0; i < 3; i++) {
      try {
        const r = await fetch(u, { headers: { ...headers, ...(opts.headers || {}) }, signal: AbortSignal.timeout(20000) });
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return await r.json();
      } catch (e) { err = e; if (/HTTP 4/.test(e.message)) break; await sleep(700 * (i + 1)); }
    }
    throw new Error(/HTTP/.test(err.message) ? err.message : 'нет соединения с интернетом или сайт недоступен');
  }
  async function getText(u) {
    const r = await fetch(u, { headers: headers, signal: AbortSignal.timeout(20000) });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.text();
  }
  // Скачивает во временный файл, сверяет суммы и только потом переименовывает: битый файл не окажется на месте настоящего.
  async function download(url, file, hashes) {
    let err;
    for (let i = 0; i < 3; i++) {
      try {
        const r = await fetch(url, { headers: headers, signal: AbortSignal.timeout(120000) });
        if (!r.ok) throw new Error('HTTP ' + r.status);
        const buf = Buffer.from(await r.arrayBuffer());
        const bad = badHash(buf, hashes);
        if (bad) throw new Error('SUM: контрольная сумма ' + bad + ' не совпала');
        fs.mkdirSync(path.dirname(file), { recursive: true });
        const tmp = file + '.part'; fs.writeFileSync(tmp, buf); fs.renameSync(tmp, file); return;
      } catch (e) { err = e; if (/HTTP 4/.test(e.message)) break; await sleep(700 * (i + 1)); }
    }
    if (/^SUM/.test(err.message)) throw new Error('Файл повреждён или подменён: ' + err.message.slice(5) + ' (' + path.basename(file) + ')');
    throw new Error(/HTTP/.test(err.message) ? err.message : 'не удалось скачать файл (нет соединения)');
  }
  // Файл уже на диске и совпадает с суммами? Тогда качать не нужно.
  function fileOk(file, hashes) {
    if (!fs.existsSync(file)) return false;
    if (!hasHashes(hashes)) return true;
    try { return !badHash(fs.readFileSync(file), hashes); } catch { return false; }
  }
  return { getJson, getText, download, fileOk };
}

// Ссылки для скачивания допускаем только с известных хостов (по спецификации .mrpack).
const MRPACK_HOSTS = ['cdn.modrinth.com', 'github.com', 'raw.githubusercontent.com', 'gitlab.com'];
function allowedPackUrl(u) {
  try { const x = new URL(u); return x.protocol === 'https:' && MRPACK_HOSTS.includes(x.hostname); } catch { return false; }
}
// Путь внутри папки: учитывает разделитель, чтобы «pack-evil» не считался внутри «pack».
function inside(dir, target) {
  const d = path.resolve(dir), t = path.resolve(target);
  return t === d || t.startsWith(d + path.sep);
}

module.exports = { createNet, badHash, hasHashes, allowedPackUrl, inside, sleep };
