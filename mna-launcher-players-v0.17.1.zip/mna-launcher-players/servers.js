'use strict';
// Свой сервер Minecraft: чистые функции (имя, порт, server.properties, адреса, выбор файла для скачивания, консоль).
// Без Electron, поэтому проверяются обычным Node (test/servers.js).
const NAME_MAX = 40, PORT_MIN = 1024, PORT_MAX = 65535;
const TYPES = ['vanilla', 'fabric'];
const BAD_CHARS = /[\u0000-\u001f\u007f-\u009f​-‏‪-‮⁦-⁩]/g;

const cleanName = s => String(s == null ? '' : s).replace(BAD_CHARS, ' ').replace(/\s+/g, ' ').trim().slice(0, NAME_MAX);
const slug = name => cleanName(name).toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 24).replace(/-+$/, '') || 'server';
const ID_RE = /^[a-z0-9][a-z0-9-]{0,40}$/;
const isId = id => typeof id === 'string' && ID_RE.test(id);
function makeId(name, exists, rnd) {
  for (let i = 0; i < 50; i++) { const id = slug(name) + '-' + (rnd ? rnd() : Math.random().toString(36).slice(2, 6)); if (isId(id) && !exists(id)) return id; }
  throw new Error('Не удалось подобрать имя папки для сервера');
}
function checkPort(p) {
  const n = typeof p === 'string' && /^\d{1,5}$/.test(p.trim()) ? +p : p;
  if (!Number.isInteger(n) || n < PORT_MIN || n > PORT_MAX) throw new Error(`Порт должен быть числом от ${PORT_MIN} до ${PORT_MAX}`);
  return n;
}
// Память в мегабайтах: от 1 ГБ до трёх четвертей оперативной памяти компьютера (но не больше 32 ГБ).
function clampRam(mb, totalMb) {
  const hi = Math.max(1024, Math.min(32768, Math.floor((totalMb || 4096) * 0.75))), n = Math.floor(Number(mb));
  return Number.isFinite(n) ? Math.min(hi, Math.max(1024, n)) : Math.min(hi, 2048);
}

// ---------- server.properties ----------
// Файл читает Java Properties: не-ASCII символы нужно записывать как \uXXXX, иначе русский текст превратится в «кракозябры».
function escapeProp(v) {
  return String(v).replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\\/g, '\\\\').replace(/^ +/, m => '\\u0020'.repeat(m.length))
    .replace(/[^\x20-\x7e]/g, ch => '\\u' + ch.charCodeAt(0).toString(16).padStart(4, '0'));
}
function unescapeProp(v) { return String(v).replace(/\\(u[0-9a-fA-F]{4}|.)/g, (_, x) => (x.length === 5 ? String.fromCharCode(parseInt(x.slice(1), 16)) : x)); }
const bool = v => { if (v === true || v === 'true') return 'true'; if (v === false || v === 'false') return 'false'; throw new Error('Ожидалось «да» или «нет»'); };
const int = (lo, hi, what) => v => { const n = typeof v === 'string' && /^-?\d+$/.test(v.trim()) ? +v : v; if (!Number.isInteger(n) || n < lo || n > hi) throw new Error(`${what}: число от ${lo} до ${hi}`); return String(n); };
const oneOf = (list, what) => v => { v = String(v).toLowerCase(); if (!list.includes(v)) throw new Error(`${what}: ${list.join(', ')}`); return v; };
// Какие настройки можно менять из лаунчера и как их проверять.
const PROPS = {
  'motd': v => { const t = String(v == null ? '' : v).replace(BAD_CHARS, ' ').trim(); if (t.length > 59) throw new Error('Описание сервера: не длиннее 59 знаков'); return t; },
  'max-players': int(1, 1000, 'Игроков'), 'view-distance': int(3, 32, 'Дальность прорисовки'), 'server-port': v => String(checkPort(v)),
  'gamemode': oneOf(['survival', 'creative', 'adventure', 'spectator'], 'Режим игры'), 'difficulty': oneOf(['peaceful', 'easy', 'normal', 'hard'], 'Сложность'),
  'pvp': bool, 'online-mode': bool
};
function parseProps(text) {
  const out = Object.create(null);
  for (const line of String(text || '').split(/\r?\n/)) { const m = /^([A-Za-z0-9._-]+)\s*[=:]\s*(.*)$/.exec(line); if (m && !line.startsWith('#') && !line.startsWith('!')) out[m[1]] = unescapeProp(m[2]); }
  return out;
}
// Меняет только указанные ключи, остальной файл (комментарии, порядок, переводы строк) остаётся как был.
function setProps(text, changes) {
  const nl = /\r\n/.test(text || '') ? '\r\n' : '\n', lines = String(text || '').split(/\r?\n/), done = new Set(), clean = {};
  for (const [k, v] of Object.entries(changes || {})) { if (!Object.prototype.hasOwnProperty.call(PROPS, k)) throw new Error('Эту настройку менять нельзя: ' + k); clean[k] = escapeProp(PROPS[k](v)); }
  const out = lines.map(line => { const m = /^([A-Za-z0-9._-]+)\s*[=:]/.exec(line); if (m && !/^[#!]/.test(line) && Object.prototype.hasOwnProperty.call(clean, m[1])) { done.add(m[1]); return m[1] + '=' + clean[m[1]]; } return line; });
  while (out.length && out[out.length - 1] === '') out.pop();
  for (const k of Object.keys(clean)) if (!done.has(k)) out.push(k + '=' + clean[k]);
  return out.join(nl) + nl;
}
function newProps(o) {
  const base = '#Minecraft server properties' + '\n';
  return setProps(base, { 'server-port': o.port, 'motd': o.motd || o.name || 'Сервер MNA', 'max-players': o.maxPlayers == null ? 8 : o.maxPlayers, 'online-mode': !!o.onlineMode, 'gamemode': o.gamemode || 'survival', 'difficulty': o.difficulty || 'normal', 'pvp': o.pvp !== false, 'view-distance': o.viewDistance || 10 });
}
const eulaText = () => '# Принято в лаунчере MNA: https://aka.ms/MinecraftEULA\neula=true\n';

// ---------- что и откуда скачивать ----------
const mojangHost = u => { try { const x = new URL(u); return x.protocol === 'https:' && /(^|\.)mojang\.com$/.test(x.hostname); } catch { return false; } };
// Из json версии Mojang: серверный jar с суммой sha1 или null (у очень старых версий серверной сборки нет).
function vanillaServer(vjson) {
  const d = vjson && vjson.downloads && vjson.downloads.server;
  if (!d || !mojangHost(d.url) || !/^[a-f0-9]{40}$/i.test(String(d.sha1 || ''))) return null;
  return { url: d.url, sha1: String(d.sha1).toLowerCase(), size: +d.size || 0 };
}
const stable = list => (Array.isArray(list) ? list : []).find(x => x && x.stable !== false && x.version) || null;
const part = s => { s = String(s || ''); if (!/^[\w.+-]{1,40}$/.test(s)) throw new Error('Недопустимая версия: ' + s.slice(0, 40)); return encodeURIComponent(s); };
const fabricUrl = (mc, loader, installer) => `https://meta.fabricmc.net/v2/versions/loader/${part(mc)}/${part(loader)}/${part(installer)}/server/jar`;

// ---------- запуск и консоль ----------
const javaArgs = (ramMb, jar) => [`-Xms${Math.min(1024, ramMb)}M`, `-Xmx${ramMb}M`, '-jar', jar, 'nogui'];
// Разбивает кусочки вывода на целые строки (кусок может оборваться посреди строки).
function lineBuf() {
  let rest = '';
  return chunk => { rest += String(chunk); const parts = rest.split(/\r?\n|\r/); rest = parts.pop(); if (rest.length > 20000) { parts.push(rest); rest = ''; } return parts.map(l => l.slice(0, 2000)); };
}
const isReady = line => /\bDone \([\d.,]+s\)!/.test(line) || /For help, type "help"/.test(line);
const cleanCommand = t => String(t == null ? '' : t).replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/^\s*\/+/, '').trim().slice(0, 256);
function lanAddresses(ifaces) {
  const out = [];
  for (const list of Object.values(ifaces || {})) for (const i of list || []) if (i && (i.family === 'IPv4' || i.family === 4) && !i.internal && /^\d+\.\d+\.\d+\.\d+$/.test(i.address) && !i.address.startsWith('169.254.')) out.push(i.address);
  return [...new Set(out)];
}

module.exports = { TYPES, NAME_MAX, PORT_MIN, PORT_MAX, cleanName, slug, isId, makeId, checkPort, clampRam, escapeProp, unescapeProp, PROPS, parseProps, setProps, newProps, eulaText, mojangHost, vanillaServer, stable, fabricUrl, javaArgs, lineBuf, isReady, cleanCommand, lanAddresses };
