'use strict';
// Профиль игрока: статистика игры, значки, «о себе». Чистые функции без Electron: проверяются обычным Node (test/profile.js).
const BIO_MAX = 300, KEEP = 40; // сколько серверов и версий помним в статистике

const num = (v, hi) => { v = Math.floor(Number(v)); return Number.isFinite(v) && v >= 0 ? Math.min(v, hi || 1e13) : 0; };
function clean(map, now) {
  const out = Object.create(null);
  if (!map || typeof map !== 'object') return out;
  const keys = Object.keys(map).filter(k => typeof k === 'string' && k.length <= 80 && !['__proto__', 'constructor', 'prototype'].includes(k) && map[k] && typeof map[k] === 'object');
  keys.sort((a, b) => num(map[b].last) - num(map[a].last));
  for (const k of keys.slice(0, KEEP)) out[k] = { n: num(map[k].n, 1e9), ms: num(map[k].ms), last: Math.min(num(map[k].last), now || Date.now()) };
  return out;
}
// Всё, что прочитали из stats.json, приводим к безопасному виду.
function normalizeStats(s, now) {
  now = now || Date.now(); s = s && typeof s === 'object' ? s : {};
  return { since: num(s.since) || now, launches: num(s.launches, 1e9), playMs: num(s.playMs), last: Math.min(num(s.last), now), servers: clean(s.servers, now), versions: clean(s.versions, now) };
}
const bump = (map, key, ms, now, launch) => { if (!key) return; const e = map[key] || (map[key] = { n: 0, ms: 0, last: 0 }); if (launch) e.n++; e.ms += ms; e.last = now; };
function recordLaunch(s, o) { const now = o.now || Date.now(); s.launches++; s.last = now; bump(s.versions, o.mc, 0, now, true); bump(s.servers, o.server, 0, now, true); return s; }
function recordEnd(s, o) {
  const now = o.now || Date.now(), ms = Math.max(0, Math.min(num(o.ms), 7 * 864e5)); s.playMs += ms; s.last = now;
  bump(s.versions, o.mc, ms, now, false); bump(s.servers, o.server, ms, now, false); return s;
}
const top = (map, n) => Object.entries(map).map(([key, v]) => ({ key, n: v.n, ms: v.ms, last: v.last })).sort((a, b) => b.ms - a.ms || b.n - a.n || b.last - a.last).slice(0, n);
function fmtDur(ms) {
  const m = Math.floor(num(ms) / 60000); if (m < 1) return 'меньше минуты';
  const h = Math.floor(m / 60); return h ? h + ' ч' + (m % 60 ? ' ' + (m % 60) + ' мин' : '') : m + ' мин';
}
const hours = ms => Math.floor(num(ms) / 36e5);

// «О себе»: только текст, без управляющих символов, не длиннее лимита.
function sanitizeBio(t) {
  return String(t == null ? '' : t).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f​-‏‪-‮⁦-⁩]/g, '').replace(/\r\n?/g, '\n').replace(/\n{3,}/g, '\n\n').trim().slice(0, BIO_MAX);
}

// Значки считаются из статистики. Файл можно подправить руками, но другие игроки этих значков не увидят.
function badges(o) {
  const s = o.stats || normalizeStats(null), h = hours(s.playMs), out = [];
  const add = (id, name, desc) => out.push({ id, name, desc });
  if (s.launches >= 1) add('first', 'Первый запуск', 'Хоть раз запустил игру через MNA');
  if (s.launches >= 10) add('l10', 'Свой человек', '10 запусков игры');
  if (s.launches >= 100) add('l100', 'Ветеран', '100 запусков игры');
  if (h >= 10) add('h10', '10 часов', 'Десять часов в игре');
  if (h >= 100) add('h100', '100 часов', 'Сто часов в игре');
  if (h >= 500) add('h500', '500 часов', 'Пятьсот часов в игре');
  if (Object.keys(s.servers).length >= 5) add('srv5', 'Путешественник', 'Играл на 5 разных серверах');
  if ((o.friends || 0) >= 5) add('f5', 'Общительный', '5 друзей');
  if ((o.friends || 0) >= 20) add('f20', 'Душа компании', '20 друзей');
  if (o.hasSkin) add('skin', 'Свой образ', 'Поставил свой скин');
  if (o.since && Date.now() - o.since > 182 * 864e5) add('old', 'Старожил', 'С MNA больше полугода');
  return out;
}

module.exports = { BIO_MAX, normalizeStats, recordLaunch, recordEnd, top, fmtDur, hours, sanitizeBio, badges };
