(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(); else root.MNAFuzzy = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  // Нечёткий поиск. Находит нужное, даже если в запросе перепутаны, пропущены или лишние буквы,
  // и даже если текст набран не в той раскладке (ghbdtn найдёт «привет»). Чистые функции, без Electron.
  //
  // Как считается оценка (от 0 до 1):
  //  1. Запрос и текст разбиваются на слова. Каждое слово запроса ищет лучшую пару среди слов текста.
  //  2. Точное совпадение или начало слова: почти 1. Слово внутри слова: 0.85.
  //  3. Иначе считаем число правок (вставка, удаление, замена, перестановка соседних букв).
  //     Допустимо больше правок для длинных слов: 0 для 1–2 букв, 1 для 3–4, 2 для 5–9, 3 для 10 и больше.
  //     Для недописанного слова сравниваем с началом слова той же длины.
  //  4. Если правок слишком много, смотрим долю общих пар соседних букв (если первая буква та же).
  //  5. Оценка запроса = среднее по словам; слова считаются все (нужны все слова запроса).
  const EN = "`qwertyuiop[]asdfghjkl;'zxcvbnm,.", RU = 'ёйцукенгшщзхъфывапролджэячсмитьбю';
  const E2R = new Map(), R2E = new Map();
  for (let i = 0; i < EN.length; i++) { E2R.set(EN[i], RU[i]); R2E.set(RU[i], EN[i]); }
  const swapWith = (s, map) => Array.from(s, ch => map.get(ch) || ch).join('');

  // Приводит к простому виду: нижний регистр, без «ё» и диакритики; всё, кроме букв, цифр и точки, становится пробелом.
  function norm(s) {
    return String(s == null ? '' : s).toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '')
      .replace(/ё/g, 'е').replace(/[^\p{L}\p{N}.]+/gu, ' ').replace(/(^|\s)\.+|\.+(?=\s|$)/g, '$1').replace(/\s+/g, ' ').trim();
  }
  const words = s => (s ? s.split(' ') : []);
  const letters = s => (s.match(/\p{L}/gu) || []).length;
  // Набор запроса в другой раскладке, если в нём есть буквы нужного алфавита.
  function otherLayout(q) {
    const s = String(q || '').toLowerCase(), lat = (s.match(/[a-z]/g) || []).length, cyr = (s.match(/[а-яё]/g) || []).length;
    if (cyr && cyr >= lat) return swapWith(s, R2E);
    if (lat) return swapWith(s, E2R);
    return '';
  }

  // Расстояние Дамерау — Левенштейна (с перестановкой соседних букв), с отсечкой по max.
  function dist(a, b, max) {
    const n = a.length, m = b.length;
    if (Math.abs(n - m) > max) return max + 1;
    if (!n || !m) return Math.max(n, m);
    let p2 = null, p1 = Array.from({ length: m + 1 }, (_, j) => j);
    for (let i = 1; i <= n; i++) {
      const cur = [i]; let best = i;
      for (let j = 1; j <= m; j++) {
        const c = a[i - 1] === b[j - 1] ? 0 : 1;
        let v = Math.min(p1[j] + 1, cur[j - 1] + 1, p1[j - 1] + c);
        if (i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) v = Math.min(v, p2[j - 2] + 1);
        cur[j] = v; if (v < best) best = v;
      }
      if (best > max) return max + 1;
      p2 = p1; p1 = cur;
    }
    return p1[m];
  }
  const allowed = len => (len <= 2 ? 0 : len <= 4 ? 1 : len <= 9 ? 2 : 3);
  function bigrams(s) { const m = new Map(); for (let i = 0; i < s.length - 1; i++) { const g = s.slice(i, i + 2); m.set(g, (m.get(g) || 0) + 1); } return m; }
  function dice(a, b) {
    if (a.length < 2 || b.length < 2) return 0;
    const A = bigrams(a), B = bigrams(b); let common = 0;
    for (const [g, n] of A) common += Math.min(n, B.get(g) || 0);
    return (2 * common) / (a.length - 1 + b.length - 1);
  }

  function isSubseq(q, t) { let i = 0; for (let j = 0; j < t.length && i < q.length; j++) if (t[j] === q[i]) i++; return i === q.length; }
  // Оценка одного слова запроса против одного слова текста.
  function wordScore(q, t) {
    if (q === t) return 1;
    if (t.startsWith(q)) return 0.9 + 0.08 * (q.length / t.length);
    if (q.length >= 3 && t.includes(q)) return 0.85;
    // слова с цифрами (версии, «24w14a») сравниваем строго: «1.20.1» не должно находить «1.20.2»
    if (/\d/.test(q)) return 0;
    const e = allowed(q.length); let best = 0;
    if (e > 0) {
      const d = dist(q, t, e);
      if (d <= e) best = Math.max(best, (1 - d / Math.max(q.length, t.length)) * 0.96);
      // недописанное слово: сравниваем с началом слова примерно той же длины
      for (let k = Math.max(1, q.length - 1); k <= q.length + 1 && k < t.length; k++) {
        const dp = dist(q, t.slice(0, k), e);
        if (dp <= e) best = Math.max(best, (1 - dp / Math.max(q.length, k)) * 0.9);
      }
    }
    // много ошибок, но буквы те же: доля общих пар соседних букв
    if (best === 0 && q.length >= 4 && t.length >= 4 && q[0] === t[0]) {
      const dc = dice(q, t.length > q.length + 1 ? t.slice(0, q.length + 1) : t);
      if (dc >= 0.62) best = dc * 0.7;
    }
    // сокращение: буквы запроса идут в слове по порядку («mncrft» → «minecraft»)
    if (best === 0 && q.length >= 3 && q[0] === t[0] && q.length / t.length >= 0.5 && isSubseq(q, t)) best = 0.55 + 0.25 * (q.length / t.length);
    return best;
  }

  // Оценка текста по запросу: 0 = не подходит. Оба аргумента можно давать «как есть».
  function scoreNorm(qn, tn) {
    if (!qn || !tn) return 0;
    if (tn === qn) return 1;
    const qw = words(qn), tw = words(tn); let sum = 0, wsum = 0;
    for (const q of qw) {
      let best = 0; for (const t of tw) { const s = wordScore(q, t); if (s > best) best = s; if (best === 1) break; }
      if (!best) { sum = -1; break; }
      sum += best * q.length; wsum += q.length;
    }
    let s = sum >= 0 && wsum ? sum / wsum : 0;
    if (tn.startsWith(qn)) s = Math.max(s, 0.97);
    else if (tn.includes(qn) && qn.length >= 2) s = Math.max(s, 0.9);
    // запрос набран слитно или с лишним пробелом: «minecraftforge» и «mine craft»
    if (s < 0.9 && qn.length >= 4) {
      const qj = qn.replace(/ /g, ''), tj = tn.replace(/ /g, '');
      if (qj !== qn || tj !== tn) s = Math.max(s, wordScore(qj, tj) * 0.95);
    }
    return s;
  }
  function score(query, text) {
    const qn = norm(query), tn = norm(text); let s = scoreNorm(qn, tn);
    const alt = norm(otherLayout(query));
    if (alt && alt !== qn && letters(alt)) s = Math.max(s, scoreNorm(alt, tn) * 0.97);
    return s;
  }

  // items: массив; text(item) возвращает строку или массив строк (лучшая из них и считается).
  // Возвращает подходящие элементы, лучшие первыми. Пустой запрос возвращает всё в исходном порядке.
  function search(items, query, text, opts) {
    const o = opts || {}, min = o.min == null ? 0.55 : o.min, get = typeof text === 'function' ? text : x => x;
    const qn = norm(query);
    if (!qn) return o.limit ? items.slice(0, o.limit) : items.slice();
    const alt = norm(otherLayout(query)), useAlt = alt && alt !== qn && letters(alt);
    const out = [];
    items.forEach((it, i) => {
      const raw = get(it), list = (Array.isArray(raw) ? raw : [raw]).map(norm);
      let s = 0, len = 1e9;
      for (const tn of list) {
        let v = scoreNorm(qn, tn); if (useAlt) v = Math.max(v, scoreNorm(alt, tn) * 0.97);
        if (v > s) { s = v; len = tn.length; }
      }
      if (s >= min) out.push({ it, s, len, i });
    });
    out.sort((a, b) => b.s - a.s || a.len - b.len || a.i - b.i);
    const r = out.map(x => x.it); return o.limit ? r.slice(0, o.limit) : r;
  }
  // «Возможно, ты искал…»: лучший вариант из списка слов или null.
  function suggest(query, candidates, min) {
    const arr = search(candidates, query, x => x, { min: min == null ? 0.6 : min, limit: 1 }); return arr.length ? arr[0] : null;
  }

  return { norm, otherLayout, dist, score, search, suggest };
});
