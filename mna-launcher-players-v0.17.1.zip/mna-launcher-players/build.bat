@echo off
cd /d "%~dp0"
set CSC_IDENTITY_AUTO_DISCOVERY=false

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js was not found. Trying to install it with winget...
  where winget >nul 2>nul && winget install -e --id OpenJS.NodeJS.LTS --accept-package-agreements --accept-source-agreements
  echo.
  echo Close this window and run build.bat again so Windows can see Node.js.
  echo If that did not work, download Node.js LTS from https://nodejs.org
  pause
  exit /b 1
)

echo === Installing (needs internet, 2-5 min) ===
call npm install || goto err
echo === Building: installer and portable ===
call npm run build || goto err
echo.
echo DONE. In the dist folder:
echo   MNA-Launcher-Setup.exe  installer, give this one to friends
echo   MNA-Launcher.exe        portable, runs without installing
explorer dist
pause
exit /b 0
:err
echo.
echo ERROR. If you see "symbolic link" above, run build.bat as Administrator
echo or turn on Windows Developer Mode (Settings - For developers).
pause
exit /b 1
