'use strict';
// Страница скачивания (docs/index.html) в Chromium: ссылки, версия с GitHub, запасные варианты и вид на телефоне.
// Запуск: NODE_PATH=$(npm root -g) node test/download-page.js
const assert = require('assert'), fs = require('fs'), path = require('path'), { chromium } = require('playwright');
const FILE = path.join(__dirname, '..', 'docs', 'index.html'), HTML = fs.readFileSync(FILE, 'utf8'), SHOTS = process.env.SHOTS;
const BASE = 'https://github.com/anna/mna-launcher/releases/latest/download/';
let n = 0; const ok = s => { n++; console.log('  ✔', s); };
const release = { tag_name: 'v0.20.1', published_at: '2026-11-05T10:00:00Z', assets: [{ name: 'MNA-Launcher-Setup.exe', size: 88 * 1048576, browser_download_url: 'https://github.com/anna/mna-launcher/releases/download/v0.20.1/MNA-Launcher-Setup.exe' }, { name: 'MNA-Launcher.exe', size: 90 * 1048576, browser_download_url: 'x' }] };

(async () => {
  const browser = await chromium.launch();
  const open = async (url, api, opts = {}) => {
    const ctx = await browser.newContext({ viewport: opts.viewport || { width: 1000, height: 800 }, colorScheme: opts.dark ? 'dark' : 'light', locale: 'ru-RU' }), page = await ctx.newPage(), calls = [];
    await page.route('https://api.github.com/**', r => { calls.push(r.request().url()); api === 'fail' ? r.abort() : r.fulfill({ status: api, contentType: 'application/json', body: JSON.stringify(api === 200 ? release : { message: 'Not Found' }) }); });
    await page.route('https://anna.github.io/**', r => r.fulfill({ status: 200, contentType: 'text/html', body: opts.html || HTML }));
    await page.route('file://**', r => r.continue());
    await page.goto(url); await page.waitForTimeout(400); page.calls = calls; page.ctx = ctx; return page;
  };
  const href = (page, id) => page.getAttribute('#' + id, 'href'), txt = (page, id) => page.textContent('#' + id);

  console.log('страница скачивания');
  let p = await open('file://' + FILE + '?repo=anna/mna-launcher', 200);
  assert.strictEqual(await href(p, 'dl'), release.assets[0].browser_download_url); assert.strictEqual(await href(p, 'portable'), BASE + 'MNA-Launcher.exe'); assert.strictEqual(await href(p, 'sums'), BASE + 'SHA256SUMS.txt');
  const meta = await txt(p, 'meta'); assert(meta.includes('Версия 0.20.1') && meta.includes('88 МБ') && /5 ноября 2026/.test(meta) && meta.includes('Windows 10 и 11'), meta);
  assert.strictEqual(p.calls.length, 1); assert(p.calls[0].endsWith('/repos/anna/mna-launcher/releases/latest')); assert.strictEqual(await p.isVisible('#warn'), false);
  assert((await href(p, 'foot').catch(() => null)) === null); assert.strictEqual(await p.getAttribute('#foot a', 'href'), 'https://github.com/anna/mna-launcher/releases');
  ok('адрес из ?repo=: кнопка ведёт на установщик, версия, размер и дата подтягиваются, ссылки на portable и суммы верные');
  if (SHOTS) await p.screenshot({ path: path.join(SHOTS, 'dl-light.png'), fullPage: true }); await p.ctx.close();

  p = await open('file://' + FILE + '?repo=anna/mna-launcher', 403);
  assert.strictEqual(await href(p, 'dl'), BASE + 'MNA-Launcher-Setup.exe'); assert.strictEqual(await txt(p, 'meta'), 'Windows 10 и 11, 64 бита'); await p.ctx.close();
  p = await open('file://' + FILE + '?repo=anna/mna-launcher', 'fail'); assert.strictEqual(await href(p, 'dl'), BASE + 'MNA-Launcher-Setup.exe'); await p.ctx.close();
  ok('GitHub не ответил (лимит запросов, нет сети): кнопка всё равно работает по постоянной ссылке «latest»');
  p = await open('file://' + FILE + '?repo=anna/mna-launcher', 404); assert.strictEqual(await txt(p, 'meta'), 'Первая версия ещё не выпущена'); assert.strictEqual(await href(p, 'dl'), BASE + 'MNA-Launcher-Setup.exe'); await p.ctx.close();
  ok('релизов ещё нет (404): так и написано');

  p = await open('https://anna.github.io/mna-launcher/', 200); assert.strictEqual(await href(p, 'portable'), BASE + 'MNA-Launcher.exe'); await p.ctx.close();
  ok('на GitHub Pages (владелец.github.io/репозиторий) репозиторий определяется сам');
  p = await open('https://anna.github.io/x/', 200, { html: HTML.replace('<meta name="repo" content="">', '<meta name="repo" content="boris/other-repo">') }); assert.strictEqual(await href(p, 'sums'), 'https://github.com/boris/other-repo/releases/latest/download/SHA256SUMS.txt'); await p.ctx.close();
  ok('репозиторий можно вписать в meta');

  for (const bad of ['', '?repo=', '?repo=a/b"><script>alert(1)</script>', '?repo=../../etc/passwd', '?repo=../..', '?repo=javascript:alert(1)', '?repo=a/b%22%3E%3Cimg%20src=x%3E', '?repo=a%2Fb%2Fc', '?repo=%E0%A4%A']) {
    p = await open('file://' + FILE + bad, 200); assert.strictEqual(await p.isVisible('#warn'), true, bad); assert.strictEqual(await href(p, 'dl'), '#', bad); assert.strictEqual(p.calls.length, 0, bad); assert.strictEqual(await p.evaluate(() => document.querySelectorAll('script').length), 1, 'лишних скриптов нет: ' + bad); await p.ctx.close();
  }
  ok('репозиторий не задан или подозрительный: предупреждение для владельца, никаких запросов и ссылок наружу');

  p = await open('file://' + FILE + '?repo=anna/mna-launcher', 200, { viewport: { width: 375, height: 700 }, dark: true });
  assert(await p.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), 'нет горизонтальной прокрутки на телефоне');
  const bg = await p.evaluate(() => getComputedStyle(document.body).backgroundColor), r = await p.evaluate(() => { const b = document.getElementById('dl').getBoundingClientRect(); return { w: b.width, h: b.height }; });
  assert.strictEqual(bg, 'rgb(22, 22, 20)'); assert(r.h >= 44 && r.w >= 200, 'кнопка крупная: ' + JSON.stringify(r));
  const emoji = /[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/u; assert(!emoji.test(await p.evaluate(() => document.body.innerText)), 'без эмодзи');
  ok('телефон 375 px и тёмная тема: без горизонтальной прокрутки, крупная кнопка, без эмодзи');
  if (SHOTS) await p.screenshot({ path: path.join(SHOTS, 'dl-dark-mobile.png'), fullPage: true }); await p.ctx.close();

  await browser.close();
  console.log(`\nГотово: ${n} проверок прошли`);
})().catch(e => { console.error(e); process.exit(1); });
