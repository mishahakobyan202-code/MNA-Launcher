'use strict';
// Проверка skins.js, profile.js, getBuffer и клиента профилей Hub: node test/skins.js
// Эталонные PNG делает Python с Pillow (если его нет, эти проверки пропускаются), остальное проверяется без внешних программ.
const assert = require('assert'), fs = require('fs'), os = require('os'), path = require('path'), http = require('http'), zlib = require('zlib');
const { spawnSync, execFileSync } = require('child_process');
const S = require('../skins.js'), P = require('../profile.js'), { crc32, readZipFile } = require('../zip.js'), { createNet } = require('../net.js'), { Hub } = require('../hub.js');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'mna-skins-'));
let n = 0; const ok = s => { n++; console.log('  ✔', s); };
const PY = ['python3', 'python'].find(c => { const r = spawnSync(c, ['-I', '-c', 'import PIL'], { stdio: 'ignore' }); return !r.error && r.status === 0; });

// ---------- вспомогательное: свои кодировщики для редких видов PNG ----------
const SIG = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
const chunk = (t, d) => { const b = Buffer.concat([Buffer.from(t), d]), o = Buffer.alloc(12 + d.length); o.writeUInt32BE(d.length, 0); b.copy(o, 4); o.writeUInt32BE(crc32(b), 8 + d.length); return o; };
const ihdr = (w, h, depth, color, inter) => { const b = Buffer.alloc(13); b.writeUInt32BE(w, 0); b.writeUInt32BE(h, 4); b[8] = depth; b[9] = color; b[12] = inter || 0; return chunk('IHDR', b); };
const mk = (w, h, depth, color, raw, extra, inter) => Buffer.concat([SIG, ihdr(w, h, depth, color, inter), ...(extra || []), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
const paeth = (a, b, c) => { const p = a + b - c, pa = Math.abs(p - a), pb = Math.abs(p - b), pc = Math.abs(p - c); return pa <= pb && pa <= pc ? a : pb <= pc ? b : c; };
// прямой фильтр строки типа f (для проверки обратного в decodePng)
function filt(f, row, prev, bpp) { const o = Buffer.alloc(row.length + 1); o[0] = f; for (let i = 0; i < row.length; i++) { const a = i >= bpp ? row[i - bpp] : 0, b = prev ? prev[i] : 0, c = prev && i >= bpp ? prev[i - bpp] : 0; o[i + 1] = (row[i] - (f === 0 ? 0 : f === 1 ? a : f === 2 ? b : f === 3 ? (a + b) >> 1 : paeth(a, b, c))) & 255; } return o; }
let seed = 7; const rnd = () => (seed = (seed * 1103515245 + 12345) & 0x7fffffff) >> 8;
const randRgba = (w, h) => { const b = Buffer.alloc(w * h * 4); for (let i = 0; i < b.length; i++) b[i] = rnd() & 255; return b; };
const px = (b, x, y, w) => Array.from(b.subarray((y * (w || 64) + x) * 4, (y * (w || 64) + x) * 4 + 4));
const must = (f, re, what) => assert.throws(f, re, what);

console.log('skins.js: PNG');
{
  const a = randRgba(64, 64), png = S.encodePng(64, 64, a), d = S.decodePng(png);
  assert.strictEqual(d.w, 64); assert.strictEqual(d.h, 64); assert(d.rgba.equals(a)); ok('RGBA: кодировщик и разбор возвращают те же пиксели');
  // все пять фильтров строки, 8 бит RGB, цвет-ключ прозрачности
  const w = 64, h = 64, rgb = Buffer.alloc(w * h * 3); for (let i = 0; i < rgb.length; i++) rgb[i] = rnd() & 255; rgb[0] = 1; rgb[1] = 2; rgb[2] = 3;
  const rows = []; for (let y = 0; y < h; y++) rows.push(filt(y % 5, rgb.subarray(y * w * 3, (y + 1) * w * 3), y ? rgb.subarray((y - 1) * w * 3, y * w * 3) : null, 3));
  const d2 = S.decodePng(mk(w, h, 8, 2, Buffer.concat(rows), [chunk('tRNS', Buffer.from([0, 1, 0, 2, 0, 3]))]));
  assert.deepStrictEqual(px(d2.rgba, 0, 0), [1, 2, 3, 0]); assert.deepStrictEqual(px(d2.rgba, 5, 7), [rgb[(7 * w + 5) * 3], rgb[(7 * w + 5) * 3 + 1], rgb[(7 * w + 5) * 3 + 2], 255]);
  for (let y = 0; y < h; y++) for (let x = 1; x < w; x++) { const o = (y * w + x) * 3; assert.deepStrictEqual(px(d2.rgba, x, y), [rgb[o], rgb[o + 1], rgb[o + 2], 255]); } ok('RGB: фильтры Sub/Up/Average/Paeth и прозрачность по цвету');
  // 16 бит: берётся старший байт
  const r16 = Buffer.alloc(64 * (64 * 8 + 1)); for (let y = 0; y < 64; y++) for (let x = 0; x < 64 * 8; x++) r16[y * (64 * 8 + 1) + 1 + x] = x % 2 ? 7 : (x * 3 + y) & 255;
  const d3 = S.decodePng(mk(64, 64, 16, 6, r16)); assert.strictEqual(d3.rgba[0], 0); assert.strictEqual(d3.rgba[1], 6); assert.strictEqual(d3.rgba[2], 12); ok('RGBA 16 бит: берётся старший байт каждого канала');
  // палитра 4 бита + tRNS
  const pal = Buffer.from([255, 0, 0, 0, 255, 0, 0, 0, 255]), r4 = Buffer.alloc(64 * (32 + 1)); for (let y = 0; y < 64; y++) for (let i = 0; i < 32; i++) r4[y * 33 + 1 + i] = i % 3 === 0 ? 0x21 : 0x12;
  const d4 = S.decodePng(mk(64, 64, 4, 3, r4, [chunk('PLTE', pal), chunk('tRNS', Buffer.from([0, 255, 128]))]));
  const first = r4[1]; assert.deepStrictEqual(px(d4.rgba, 0, 0), [...pal.subarray((first >> 4) * 3, (first >> 4) * 3 + 3), [0, 255, 128][first >> 4]]);
  assert.deepStrictEqual(px(d4.rgba, 1, 0), [...pal.subarray((first & 15) * 3, (first & 15) * 3 + 3), [0, 255, 128][first & 15]]); ok('палитра 4 бита и прозрачность палитры');
  // серый с альфой
  const rga = Buffer.alloc(64 * (64 * 2 + 1)); for (let y = 0; y < 64; y++) for (let x = 0; x < 64; x++) { rga[y * 129 + 1 + x * 2] = x * 4; rga[y * 129 + 2 + x * 2] = 255 - y; }
  const d5 = S.decodePng(mk(64, 64, 8, 4, rga)); assert.deepStrictEqual(px(d5.rgba, 10, 3), [40, 40, 40, 252]); ok('серый с альфой');
  // 1 бит серого
  const r1 = Buffer.alloc(64 * 9); for (let y = 0; y < 64; y++) r1[y * 9 + 1] = 0b10110000;
  const d6 = S.decodePng(mk(64, 64, 1, 0, r1)); assert.deepStrictEqual([0, 1, 2, 3].map(x => px(d6.rgba, x, 0)[0]), [255, 0, 255, 255]); ok('серый 1 бит');
}
if (PY) {
  const dir = path.join(tmp, 'pil'); fs.mkdirSync(dir);
  const script = `
import sys, os, numpy as np
from PIL import Image
d = sys.argv[1]; rng = np.random.default_rng(5)
def put(name, im, **kw):
    f = os.path.join(d, name + '.png'); im.save(f, **kw)
    open(os.path.join(d, name + '.rgba'), 'wb').write(Image.open(f).convert('RGBA').tobytes())  # эталон: сама Pillow читает сохранённый файл
rgba = rng.integers(0, 256, (64, 64, 4), dtype=np.uint8)
put('rgba', Image.fromarray(rgba, 'RGBA')); put('rgb', Image.fromarray(rgba[:, :, :3], 'RGB'))
put('rgb_key', Image.fromarray(rgba[:, :, :3], 'RGB'), transparency=tuple(int(v) for v in rgba[3, 3, :3]))
put('gray', Image.fromarray(rgba[:, :, 0], 'L')); put('gray_key', Image.fromarray(rgba[:, :, 0], 'L'), transparency=int(rgba[2, 2, 0]))
put('la', Image.fromarray(rgba[:, :, :2], 'LA'))
p = Image.fromarray(rgba[:, :, :3], 'RGB').quantize(16); put('pal16', p, transparency=0)
p2 = Image.fromarray(rgba[:, :, :3], 'RGB').quantize(4); put('pal4', p2, bits=2)
put('legacy32', Image.fromarray(rgba[:32], 'RGBA'))
put('big128', Image.fromarray(rng.integers(0, 256, (128, 128, 4), dtype=np.uint8), 'RGBA'))
`;
  execFileSync(PY, ['-I', '-c', script, dir]);
  for (const f of fs.readdirSync(dir).filter(x => x.endsWith('.png') && !/big128|legacy32/.test(x))) {
    const name = f.slice(0, -4), d = S.decodePng(fs.readFileSync(path.join(dir, f))), exp = fs.readFileSync(path.join(dir, name + '.rgba'));
    assert(d.rgba.equals(exp), 'Pillow: ' + name);
  }
  ok('PNG от Pillow (RGBA, RGB, серый, серый+альфа, палитры, прозрачность): пиксели совпали');
  must(() => S.decodePng(fs.readFileSync(path.join(dir, 'big128.png'))), /64×64.*128×128/); ok('128×128 отклонён с понятным текстом');
  const lg = S.normalize(fs.readFileSync(path.join(dir, 'legacy32.png'))), src = fs.readFileSync(path.join(dir, 'legacy32.rgba'));
  assert.strictEqual(lg.rgba.length, 64 * 64 * 4); ok('64×32 принимается и превращается в 64×64');
  // вывод нашего кодировщика читает настоящая библиотека
  const mine = path.join(dir, 'mine.png'); fs.writeFileSync(mine, S.encodePng(64, 64, randRgba(64, 64)));
  const chk = execFileSync(PY, ['-I', '-c', 'import sys; from PIL import Image; im=Image.open(sys.argv[1]); im.load(); print(im.size, im.mode)', mine]).toString().trim(); assert.strictEqual(chk, "(64, 64) RGBA"); ok('наш PNG открывается Pillow без ошибок');
} else console.log('  (Python с Pillow не найден: проверки на эталонных PNG пропущены)');

console.log('skins.js: защита');
{
  const good = S.encodePng(64, 64, randRgba(64, 64));
  must(() => S.decodePng(Buffer.from('GIF89a' + 'x'.repeat(100))), /не PNG/); must(() => S.decodePng(Buffer.alloc(0)), /не PNG/); must(() => S.decodePng('abc'), /не PNG/); ok('не PNG: отклонён');
  must(() => S.decodePng(good.subarray(0, good.length - 20)), /обрезан|повреждён/); must(() => S.decodePng(good.subarray(0, 60)), /обрезан|повреждён/); ok('обрезанный файл: понятная ошибка');
  const bad = Buffer.from(good); bad[bad.length - 40] ^= 0xff; must(() => S.decodePng(bad), /контрольная сумма/); ok('испорченный байт: контрольная сумма не сходится');
  const raw = Buffer.alloc(64 * (64 * 4 + 1)); must(() => S.decodePng(mk(64, 64, 8, 6, raw, null, 1)), /Чересстрочный/); ok('чересстрочный PNG: сообщение, что делать');
  must(() => S.decodePng(mk(64, 64, 8, 6, Buffer.alloc(100))), /неверный размер|повреждён/); must(() => S.decodePng(mk(64, 64, 8, 5, raw)), /не поддерживается/); must(() => S.decodePng(mk(64, 64, 3, 6, raw)), /не поддерживается/); ok('неверный размер данных и странные режимы: отклонены');
  const bomb = Buffer.concat([SIG, ihdr(64, 64, 8, 6), chunk('IDAT', zlib.deflateSync(Buffer.alloc(200 * 1048576))), chunk('IEND', Buffer.alloc(0))]);
  assert(bomb.length < 400000); const t0 = Date.now(); must(() => S.decodePng(bomb), /повреждён/); assert(Date.now() - t0 < 3000); ok('«бомба» (200 МБ из 200 КБ) не распаковывается');
  const huge = Buffer.concat([SIG, ihdr(60000, 60000, 8, 6), chunk('IEND', Buffer.alloc(0))]); must(() => S.decodePng(huge), /64×64|обрезан/); ok('огромные размеры в заголовке: отказ до выделения памяти');
  must(() => S.decodePng(Buffer.concat([good, Buffer.alloc(S.MAX_PNG)])), /слишком большой/); ok('файл больше 2 МБ отклонён');
  must(() => S.decodePng(mk(64, 64, 8, 3, Buffer.alloc(64 * 65))), /палитра|обрезан|повреждён/); ok('палитра без PLTE: отклонён');
}

console.log('skins.js: раскладка');
{
  // 64×32 → 64×64: левые части зеркально копируют правые
  const l = Buffer.alloc(64 * 32 * 4); for (let y = 0; y < 32; y++) for (let x = 0; x < 64; x++) { const o = (y * 64 + x) * 4; l[o] = x * 4; l[o + 1] = y * 8; l[o + 2] = (x + y) & 255; l[o + 3] = 200; }
  const f = S.fromLegacy(l);
  assert.deepStrictEqual(px(f, 20 + 3, 48).slice(0, 3), px(l, 4, 16).slice(0, 3)); assert.deepStrictEqual(px(f, 20, 48).slice(0, 3), px(l, 7, 16).slice(0, 3));
  assert.deepStrictEqual(px(f, 24 + 3, 52 + 5).slice(0, 3), px(l, 0, 20 + 5).slice(0, 3)); assert.deepStrictEqual(px(f, 36, 52).slice(0, 3), px(l, 47, 20).slice(0, 3));
  assert.deepStrictEqual(px(f, 44, 63).slice(0, 3), px(l, 55, 31).slice(0, 3)); assert.deepStrictEqual(px(f, 36 + 3, 48).slice(0, 3), px(l, 44, 16).slice(0, 3));
  assert.strictEqual(px(f, 10, 50)[3], 0); ok('старый скин: левая нога и рука зеркалятся из правых');
  assert.strictEqual(px(f, 3, 3)[3], 255); assert.strictEqual(px(f, 20, 20)[3], 255); assert.strictEqual(px(f, 30, 8)[3], 255); assert.strictEqual(px(f, 40, 8)[3], 0); ok('основной слой становится непрозрачным; сплошная «шапка» старого скина убирается');
  const l2 = Buffer.from(l); for (let x = 32; x < 64; x++) l2[(3 * 64 + x) * 4 + 3] = 0; assert.strictEqual(px(S.fromLegacy(l2), 40, 8)[3], 200); ok('настоящая шапка с прозрачностью сохраняется');
  // руки: Steve ↔ Alex
  const s = Buffer.alloc(64 * 64 * 4); const paint = (x, y, c) => { const o = (y * 64 + x) * 4; s[o] = c; s[o + 1] = c; s[o + 2] = c; s[o + 3] = 255; };
  for (const [ox, oy] of [[40, 16], [40, 32], [32, 48], [48, 48]]) { for (let r = 0; r < 12; r++) { for (let c = 0; c < 4; c++) { paint(ox + 4 + c, oy + 4 + r, 10 + c); paint(ox + 12 + c, oy + 4 + r, 50 + c); paint(ox + c, oy + 4 + r, 100 + c); paint(ox + 8 + c, oy + 4 + r, 150 + c); } } for (let r = 0; r < 4; r++) for (let c = 0; c < 4; c++) { paint(ox + 4 + c, oy + r, 200 + c); paint(ox + 8 + c, oy + r, 220 + c); } }
  assert(!S.detectSlim(s)); const sl = S.arms(s, 'classic', 'slim');
  assert(S.detectSlim(sl)); assert.deepStrictEqual([0, 1, 2].map(c => px(sl, 44 + c, 20)[0]), [10, 11, 13]); assert.deepStrictEqual([0, 1, 2].map(c => px(sl, 51 + c, 20)[0]), [50, 51, 53]); assert.deepStrictEqual([0, 1, 2, 3].map(c => px(sl, 40 + c, 20)[0]), [100, 101, 102, 103]); assert.deepStrictEqual([0, 1, 2, 3].map(c => px(sl, 47 + c, 20)[0]), [150, 151, 152, 153]); assert.deepStrictEqual([0, 1, 2].map(c => px(sl, 44 + c, 16)[0]), [200, 201, 203]); assert.deepStrictEqual([0, 1, 2].map(c => px(sl, 47 + c, 16)[0]), [220, 221, 223]);
  assert.deepStrictEqual(px(sl, 54, 25), [0, 0, 0, 0]); assert.deepStrictEqual(px(sl, 32 + 4 + 2, 48 + 4)[0], px(s, 32 + 4 + 3, 48 + 4)[0]); ok('классика → тонкая модель: грани сжаты до 3 пикселей, боковые остались 4, столбцы справа пусты');
  const back = S.arms(sl, 'slim', 'classic'); assert(!S.detectSlim(back)); assert.deepStrictEqual([0, 1, 2, 3].map(c => px(back, 44 + c, 20)[0]), [10, 11, 11, 13]); assert.deepStrictEqual([0, 1, 2, 3].map(c => px(back, 52 + c, 20)[0]), [50, 51, 51, 53]); assert.deepStrictEqual([0, 1, 2, 3].map(c => px(back, 40 + c, 20)[0]), [100, 101, 102, 103]); ok('тонкая → классика: грани растянуты до 4 пикселей');
  assert(S.arms(s, 'classic', 'classic').equals(s) && S.arms(s, 'classic', 'classic') !== s); ok('та же модель: копия без изменений');
  // остальное тело не затронуто
  const body = randRgba(64, 64), conv = S.arms(body, 'classic', 'slim'); for (const [x, y] of [[8, 8], [20, 20], [5, 20], [20, 52], [60, 4], [30, 40], [8, 40]]) assert.deepStrictEqual(px(conv, x, y), px(body, x, y)); ok('голова, тело и ноги при смене модели рук не меняются');
  const lg = S.normalize(S.encodePng(64, 64, s)); assert.strictEqual(lg.model, 'classic'); assert.strictEqual(S.normalize(S.encodePng(64, 64, sl)).model, 'slim'); assert(S.isModel('slim') && S.isModel('classic') && !S.isModel('x') && !S.isModel(undefined)); ok('модель определяется по пустым столбцам руки');
}

console.log('skins.js: ресурспак');
{
  assert.deepStrictEqual(['1.8.9', '1.12.2', '1.13', '1.16.1', '1.16.5', '1.19.2', '1.19.3', '1.19.4', '1.20.1', '1.20.2', '1.20.4', '1.20.6', '1.21.1', '1.21.3', '1.21.4', '1.21.5', '1.21.8', '1.21.9', '1.21.11', '26.1', '26.1.2'].map(S.packFormat), [1, 3, 4, 5, 6, 9, 12, 13, 15, 18, 22, 32, 34, 42, 46, 55, 64, 69, 69, 69, 69]);
  assert.strictEqual(S.packFormat('1.5.2'), 0); assert.strictEqual(S.packFormat('25w31a'), 0); assert.strictEqual(S.packFormat(''), 0); assert.strictEqual(S.packFormat(undefined), 0); assert.strictEqual(S.packFormat('1.6.1'), 1); assert.strictEqual(S.packFormat('1.6'), 0); ok('номер формата ресурспака по версии (в том числе 26.x и неизвестные)');
  assert.strictEqual(S.packId('1.12.2'), 'MNA-Skin.zip'); assert.strictEqual(S.packId('1.13'), 'file/MNA-Skin.zip'); assert.strictEqual(S.packId('1.21.1'), 'file/MNA-Skin.zip'); assert.strictEqual(S.packId('26.1'), 'file/MNA-Skin.zip'); ok('имя пака в options.txt: до 1.12 без «file/», после с ним');
  assert.deepStrictEqual(JSON.parse(S.mcmeta('1.21.1')), { pack: { description: 'MNA Launcher skin', pack_format: 34 } }); assert.deepStrictEqual(JSON.parse(S.mcmeta('1.21.11')).pack.min_format, 69); assert(JSON.parse(S.mcmeta('26.1')).pack.max_format >= 99); assert(!('pack_format' in JSON.parse(S.mcmeta('26.1')).pack)); ok('pack.mcmeta: до 1.21.8 pack_format, с 1.21.9 диапазон min_format/max_format');
  const sk = randRgba(64, 64); for (let y = 0; y < 64; y++) for (let x = 54; x < 56; x++) sk[(y * 64 + x) * 4 + 3] = 255;
  const zip = S.buildPack(sk, 'classic', '1.20.1'), zf = path.join(tmp, 'pack.zip'); fs.writeFileSync(zf, zip);
  const T = 'assets/minecraft/textures/entity/'; const names = ['pack.mcmeta', 'pack.png', T + 'steve.png', T + 'alex.png', ...S.DEFAULTS.flatMap(d => [T + 'player/wide/' + d + '.png', T + 'player/slim/' + d + '.png'])];
  for (const f of names) assert(readZipFile(zf, f), 'нет ' + f); assert.strictEqual(names.length, 22); ok('пак: pack.mcmeta, значок, Стив/Алекс и все девять скинов 1.19.3+ в двух вариантах');
  assert(S.buildPack(sk, 'classic', '1.20.1').equals(zip)); ok('сборка детерминирована: один и тот же скин даёт тот же файл (можно сравнивать, не переписывая)');
  for (const f of names.filter(x => x.endsWith('.png'))) { const d = S.decodePng(readZipFile(zf, f)); assert.strictEqual(d.w, 64); assert.strictEqual(d.h, 64); }
  const wide = S.decodePng(readZipFile(zf, T + 'player/wide/steve.png')).rgba, slim = S.decodePng(readZipFile(zf, T + 'player/slim/alex.png')).rgba;
  assert(!S.detectSlim(wide)); assert(S.detectSlim(slim)); assert.strictEqual(px(wide, 8, 8)[3], 255); assert.deepStrictEqual(px(wide, 8, 8).slice(0, 3), px(sk, 8, 8).slice(0, 3)); assert(S.decodePng(readZipFile(zf, T + 'steve.png')).rgba.equals(wide)); assert(S.decodePng(readZipFile(zf, T + 'alex.png')).rgba.equals(slim)); ok('wide получает широкие руки, slim тонкие, лицо не меняется');
  const slimSrc = S.arms(S.opaqueBase(Buffer.from(sk)), 'classic', 'slim'); const zs = path.join(tmp, 'pack-slim.zip'); fs.writeFileSync(zs, S.buildPack(slimSrc, 'slim', '1.21.1'));
  assert(S.detectSlim(S.decodePng(readZipFile(zs, T + 'player/slim/steve.png')).rgba)); assert(!S.detectSlim(S.decodePng(readZipFile(zs, T + 'player/wide/steve.png')).rgba)); assert.strictEqual(JSON.parse(readZipFile(zs, 'pack.mcmeta')).pack.pack_format, 34); ok('скин с тонкими руками: то же самое в обратную сторону');
  assert.throws(() => S.buildPack(sk, 'classic', '1.4.7'), /не поддерживается/); assert.throws(() => S.buildPack(sk, 'classic', '24w01a'), /не поддерживается/); ok('неизвестная версия: понятная ошибка, а не битый пак');
  if (spawnSync('unzip', ['-v'], { stdio: 'ignore' }).status === 0) { const r = spawnSync('unzip', ['-t', zf]); assert.strictEqual(r.status, 0, String(r.stdout)); ok('unzip -t: архив целый'); }
  if (PY) { const r = spawnSync(PY, ['-I', '-c', 'import sys,zipfile; z=zipfile.ZipFile(sys.argv[1]); assert z.testzip() is None; print(len(z.namelist()), z.namelist()[0])', zf]); assert.strictEqual(String(r.stdout).trim(), '22 pack.mcmeta', String(r.stderr)); ok('Python zipfile: архив целый, pack.mcmeta первым'); }
}

console.log('skins.js: options.txt');
{
  const w = (t, mc, on, inc) => S.withPack(t, mc || '1.21.1', on, inc);
  assert.strictEqual(w('', '1.21.1', true).text, 'resourcePacks:["vanilla","file/MNA-Skin.zip"]\n'); assert.strictEqual(S.optionsFor('', '1.21.1', true).text, 'resourcePacks:["vanilla","file/MNA-Skin.zip"]\n'); ok('нет options.txt: создаётся строка с ресурспаками');
  assert.strictEqual(S.optionsFor('', '1.21.1', false).changed, false); assert.strictEqual(S.optionsFor('', '1.21.1', false).text, ''); ok('скин выключен и файла нет: ничего не пишем');
  let t = 'version:3955\nlang:ru_ru\nresourcePacks:["vanilla","file/a.zip"]\nincompatibleResourcePacks:[]\nfov:0.5\n';
  let r = w(t, '1.21.1', true); assert.strictEqual(r.text, 'version:3955\nlang:ru_ru\nresourcePacks:["vanilla","file/a.zip","file/MNA-Skin.zip"]\nincompatibleResourcePacks:[]\nfov:0.5\n'); assert(r.changed); ok('наш пак добавляется последним, чужие строки не тронуты');
  assert.strictEqual(w(r.text, '1.21.1', true).changed, false); ok('повторно: файл не меняется');
  r = w('resourcePacks:["vanilla","file/MNA-Skin.zip","file/b.zip"]\n', '1.21.1', true); assert.strictEqual(r.text, 'resourcePacks:["vanilla","file/b.zip","file/MNA-Skin.zip"]\n'); ok('если пак уже был в середине, он переезжает в конец (высший приоритет)');
  r = w(r.text, '1.21.1', false); assert.strictEqual(r.text, 'resourcePacks:["vanilla","file/b.zip"]\n'); ok('выключение убирает только наш пак');
  assert.strictEqual(w('a:1\r\nresourcePacks:["vanilla"]\r\nb:2\r\n', '1.21.1', true).text, 'a:1\r\nresourcePacks:["vanilla","file/MNA-Skin.zip"]\r\nb:2\r\n'); ok('переводы строк Windows сохраняются');
  assert.strictEqual(w('resourcePacks:[bad json\nx:1\n', '1.21.1', true).text, 'resourcePacks:["file/MNA-Skin.zip"]\nx:1\n'); assert.strictEqual(w('x:1\n', '1.21.1', true).text, 'x:1\nresourcePacks:["vanilla","file/MNA-Skin.zip"]\n'); ok('испорченная или отсутствующая строка не ломает файл');
  assert.strictEqual(w('resourcePacks:["a.zip"]\n', '1.12.2', true).text, 'resourcePacks:["a.zip","MNA-Skin.zip"]\n'); assert.strictEqual(w('resourcePacks:["MNA-Skin.zip","a.zip"]\n', '1.12.2', true).text, 'resourcePacks:["a.zip","MNA-Skin.zip"]\n'); assert.strictEqual(w('x:1\n', '1.12.2', true).text, 'x:1\nresourcePacks:["MNA-Skin.zip"]\n'); ok('1.12 и старше: имя без «file/»');
  assert.strictEqual(w('resourcePacks:["vanilla","file/MNA-Skin.zip"]\n', '1.12.2', true).text, 'resourcePacks:["vanilla","MNA-Skin.zip"]\n'); ok('имя пака другого вида (после смены версии) заменяется на нужное');
  r = w('resourcePacks:["vanilla"]\nincompatibleResourcePacks:["file/x.zip"]\n', '26.1', true, true); assert.strictEqual(r.text, 'resourcePacks:["vanilla","file/MNA-Skin.zip"]\nincompatibleResourcePacks:["file/x.zip","file/MNA-Skin.zip"]\n'); assert.strictEqual(w(r.text, '26.1', false, true).text, 'resourcePacks:["vanilla"]\nincompatibleResourcePacks:["file/x.zip"]\n'); ok('список несовместимых: наш пак добавляется и убирается вместе с основным');
  assert.strictEqual(w('resourcePacks:{"a":1}\n', '1.21.1', true).text, 'resourcePacks:["file/MNA-Skin.zip"]\n'); assert.strictEqual(w('resourcePacks:[1,"a",null]\n', '1.21.1', true).text, 'resourcePacks:["a","file/MNA-Skin.zip"]\n'); ok('не-строки в списке отбрасываются');
}

console.log('Mojang и сеть');
(async () => {
  const srv = http.createServer((q, r) => {
    const chunks = []; q.on('data', c => chunks.push(c)); q.on('end', () => {
      const body = Buffer.concat(chunks), u = q.url;
      if (u === '/minecraft/profile/skins') {
        srv.last = { auth: q.headers.authorization, ct: q.headers['content-type'], body };
        const code = srv.mode || 200; r.writeHead(code, { 'Content-Type': 'application/json' }); return r.end('{}');
      }
      if (u === '/lookup/Notch') { r.writeHead(200); return r.end(JSON.stringify({ id: 'ab'.repeat(16), name: 'Notch' })); }
      if (u === '/lookup/Nobody') { r.writeHead(404); return r.end('{}'); }
      if (u === '/lookup/Rate') { r.writeHead(429); return r.end('{}'); }
      if (u === '/lookup/Plain') { r.writeHead(200); return r.end(JSON.stringify({ id: 'cd'.repeat(16), name: 'Plain' })); }
      if (u === '/session/' + 'ab'.repeat(16)) { const t = { textures: { SKIN: { url: 'https://textures.minecraft.net/texture/abc123', metadata: { model: 'slim' } } } }; r.writeHead(200); return r.end(JSON.stringify({ id: 'ab'.repeat(16), name: 'Notch', properties: [{ name: 'textures', value: Buffer.from(JSON.stringify(t)).toString('base64') }] })); }
      if (u === '/session/' + 'cd'.repeat(16)) { r.writeHead(200); return r.end(JSON.stringify({ id: 'cd'.repeat(16), name: 'Plain', properties: [] })); }
      if (u === '/texture/abc123') { r.writeHead(200, { 'Content-Type': 'image/png' }); return r.end(srv.png); }
      if (u === '/big') { r.writeHead(200); return r.end(Buffer.alloc(3 * 1048576)); }
      if (u === '/api/profile/p1') { r.writeHead(200); return r.end(JSON.stringify({ bio: 'привет', since: 1700000000000 })); }
      if (u === '/api/profile/old') { r.writeHead(404); return r.end('{"error":"нет"}'); }
      if (u === '/api/profile/boom') { r.writeHead(500); return r.end('{"error":"сбой"}'); }
      if (u === '/api/profile' && q.method === 'POST') { srv.posted = JSON.parse(body.toString()); r.writeHead(srv.setMode || 200); return r.end('{}'); }
      r.writeHead(404); r.end();
    });
  }).listen(0, '127.0.0.1'); await new Promise(r => srv.on('listening', r));
  const U = 'http://127.0.0.1:' + srv.address().port, png = S.encodePng(64, 64, randRgba(64, 64)); srv.png = png;
  assert.strictEqual(await S.uploadSkin(png, 'slim', 'TOK', U), true);
  assert.strictEqual(srv.last.auth, 'Bearer TOK'); assert(/^multipart\/form-data; boundary=/.test(srv.last.ct)); const bs = srv.last.body.toString('latin1'); assert(/name="variant"\r\n\r\nslim/.test(bs)); assert(/name="file"; filename="skin.png"/.test(bs)); assert(srv.last.body.includes(png)); ok('загрузка в Mojang: токен, вариант модели и PNG уходят формой multipart');
  srv.mode = 401; await assert.rejects(S.uploadSkin(png, 'classic', 'T', U), /устарел/); srv.mode = 429; await assert.rejects(S.uploadSkin(png, 'classic', 'T', U), /подождать/); srv.mode = 400; await assert.rejects(S.uploadSkin(png, 'classic', 'T', U), /HTTP 400/); srv.mode = 200;
  await assert.rejects(S.uploadSkin(png, 'classic', '', U), /Microsoft/); await assert.rejects(S.uploadSkin(Buffer.alloc(S.MOJANG_MAX + 1), 'classic', 'T', U), /24 КБ/); await assert.rejects(S.uploadSkin(png, 'classic', 'T', 'http://127.0.0.1:1'), /нет соединения/); ok('ошибки Mojang: понятный текст для 401, 429, отказа, нет токена, большого файла и обрыва');
  const net = createNet({ 'User-Agent': 't' }), hosts = { lookup: U + '/lookup/', session: U + '/session/', tex: U };
  const got = await S.skinByNick('Notch', net, hosts); assert.strictEqual(got.name, 'Notch'); assert.strictEqual(got.model, 'slim'); assert.strictEqual(got.png.subarray(0, 8).toString('hex'), '89504e470d0a1a0a'); assert(S.decodePng(got.png).rgba.equals(S.decodePng(png).rgba)); ok('скин по нику: Mojang → sessionserver → PNG проверен и приведён к 64×64');
  await assert.rejects(S.skinByNick('Nobody', net, hosts), /не найден/); await assert.rejects(S.skinByNick('Rate', net, hosts), /подождать/); await assert.rejects(S.skinByNick('Plain', net, hosts), /нет своего скина/); await assert.rejects(S.skinByNick('a b!', net, hosts), /Ник/); await assert.rejects(S.skinByNick('', net, hosts), /Ник/); await assert.rejects(S.skinByNick('x'.repeat(17), net, hosts), /Ник/); ok('нет игрока, лимит Mojang, нет скина, неверный ник: отдельные понятные ошибки');
  const tx = v => ({ properties: [{ name: 'textures', value: Buffer.from(JSON.stringify(v)).toString('base64') }] });
  assert.strictEqual(S.texturesOf(tx({ textures: { SKIN: { url: 'https://evil.example.com/a.png' } } })), null); assert.strictEqual(S.texturesOf(tx({ textures: { SKIN: { url: 'https://textures.minecraft.net.evil.com/a' } } })), null); assert.strictEqual(S.texturesOf(tx({ textures: { SKIN: { url: 'file:///etc/passwd' } } })), null); assert.strictEqual(S.texturesOf(tx({ textures: {} })), null); assert.strictEqual(S.texturesOf({ properties: [{ name: 'textures', value: '!!!' }] }), null); assert.strictEqual(S.texturesOf(null), null); assert.strictEqual(S.texturesOf({}), null);
  assert.deepStrictEqual(S.texturesOf(tx({ textures: { SKIN: { url: 'http://textures.minecraft.net/texture/a1' } } })), { url: 'https://textures.minecraft.net/texture/a1', model: 'classic' }); ok('ссылка на скин принимается только с textures.minecraft.net');
  await assert.rejects(net.getBuffer(U + '/big', 1048576), /слишком большой/); assert.strictEqual((await net.getBuffer(U + '/texture/abc123', 1048576)).length, png.length); await assert.rejects(net.getBuffer(U + '/nope', 10), /HTTP 404/); ok('getBuffer: лимит размера и ошибки HTTP');

  const hub = new Hub({}); hub.base = U;
  const g = await hub.profile('p1'); assert.deepStrictEqual(g, { supported: true, profile: { bio: 'привет', since: 1700000000000 } }); assert.deepStrictEqual(await hub.profile('old'), { supported: false, profile: null }); await assert.rejects(hub.profile('boom'), /сбой/);
  assert.strictEqual(await hub.setProfile({ bio: 'x' }), true); assert.deepStrictEqual(srv.posted, { bio: 'x' }); srv.setMode = 404; assert.strictEqual(await hub.setProfile({ bio: 'y' }), false); srv.setMode = 500; await assert.rejects(hub.setProfile({ bio: 'z' }), /Hub/); ok('клиент Hub: профиль есть, у старого Hub «не поддерживается», сбой сервера не маскируется');
  srv.close();

  console.log('profile.js');
  const now = 1_800_000_000_000;
  const st = P.normalizeStats({ since: 5, launches: -4, playMs: 'abc', last: now + 1e9, servers: { 'a.com': { n: 2, ms: 1e7, last: 9 }, '__proto__': { n: 1 }, ['x'.repeat(100)]: { n: 1 }, bad: 5 }, versions: null }, now);
  assert.strictEqual(st.launches, 0); assert.strictEqual(st.playMs, 0); assert.strictEqual(st.last, now); assert.deepStrictEqual(Object.keys(st.servers), ['a.com']); assert.strictEqual(Object.keys(st.versions).length, 0); assert.strictEqual(P.normalizeStats(null, now).since, now); ok('статистика: мусор, отрицательные числа, длинные и опасные ключи приводятся в порядок');
  const s2 = P.normalizeStats(null, now); P.recordLaunch(s2, { mc: '1.21.1', server: 'mc.example.com', now }); P.recordEnd(s2, { mc: '1.21.1', server: 'mc.example.com', ms: 90 * 60000, now: now + 1 }); P.recordLaunch(s2, { mc: '1.20.1', server: '', now: now + 2 }); P.recordEnd(s2, { mc: '1.20.1', server: '', ms: 5 * 60000, now: now + 3 });
  assert.strictEqual(s2.launches, 2); assert.strictEqual(s2.playMs, 95 * 60000); assert.strictEqual(s2.servers['mc.example.com'].n, 1); assert.strictEqual(s2.servers['mc.example.com'].ms, 90 * 60000); assert.deepStrictEqual(P.top(s2.versions, 1).map(x => x.key), ['1.21.1']); assert.strictEqual(Object.keys(s2.servers).length, 1); ok('запуск и конец игры считаются по версиям и серверам; одиночная игра не попадает в серверы');
  P.recordEnd(s2, { mc: 'x', ms: -5 }); P.recordEnd(s2, { mc: 'x', ms: 1e15 }); assert(s2.playMs <= 95 * 60000 + 7 * 864e5); ok('отрицательная и абсурдная длительность не портят счётчик');
  const big = {}; for (let i = 0; i < 100; i++) big['s' + i + '.com'] = { n: 1, ms: i, last: i }; assert.strictEqual(Object.keys(P.normalizeStats({ servers: big }, now).servers).length, 40); ok('в статистике помним не больше 40 серверов');
  assert.strictEqual(P.fmtDur(0), 'меньше минуты'); assert.strictEqual(P.fmtDur(59 * 60000), '59 мин'); assert.strictEqual(P.fmtDur(3600000), '1 ч'); assert.strictEqual(P.fmtDur(3725000), '1 ч 2 мин'); assert.strictEqual(P.fmtDur(NaN), 'меньше минуты'); ok('длительность по-русски');
  const ids = o => P.badges(o).map(b => b.id), z = P.normalizeStats(null, now);
  assert.deepStrictEqual(ids({ stats: z }), []); assert.deepStrictEqual(ids({ stats: { ...z, launches: 10, playMs: 100 * 36e5 }, friends: 5, hasSkin: true, since: now - 400 * 864e5 }).sort(), ['f5', 'first', 'h10', 'h100', 'l10', 'old', 'skin'].sort()); assert(!ids({ stats: { ...z, launches: 1 }, since: Date.now() - 864e5 }).includes('old')); assert(ids({ stats: { ...z, launches: 100, playMs: 500 * 36e5 }, friends: 20 }).includes('l100') && ids({ stats: { ...z, launches: 100, playMs: 500 * 36e5 }, friends: 20 }).includes('h500') && ids({ stats: { ...z, launches: 100, playMs: 500 * 36e5 }, friends: 20 }).includes('f20')); ok('значки открываются по порогам');
  assert.strictEqual(P.sanitizeBio('  привет\u0000 мир‮  '), 'привет мир'); assert.strictEqual(P.sanitizeBio('a\n\n\n\n\nb'), 'a\n\nb'); assert.strictEqual(P.sanitizeBio('x'.repeat(500)).length, P.BIO_MAX); assert.strictEqual(P.sanitizeBio(null), ''); assert.strictEqual(P.sanitizeBio({ a: 1 }), '[object Object]'.slice(0, P.BIO_MAX)); ok('«о себе»: управляющие и направляющие символы убраны, длина ограничена');

  console.log(`\nГотово: ${n} проверок прошли`);
})().catch(e => { console.error(e); process.exit(1); });
