'use strict';
// Маленький ненастоящий Hub для тестов. Заодно это «живое описание» протокола 0.20 для настоящего сервера:
// правка и удаление сообщений, события message_edit / message_del / room_edit / room_del и журнал глобального чата.
const http = require('http');

function createMockHub(opts = {}) {
  const st = {
    password: 'secret12', tier: opts.tier || 'pro', features: opts.features, // features: undefined = старый Hub, не знает о правке сообщений
    tokens: new Set(), n: 0, seq: 0, log: [], global: [], dm: { f1: [] }, events: new Set(), down: false, failLogin: 0, failProfile: 0, slowProfile: 0, profiles: [], calls: [],
    friends: opts.friends || [{ id: 'f1', nick: 'Boris', online: true, state: 'ingame', server: 'mc.test.net', unread: 0, style: null, tier: 'plus' }, { id: 'f2', nick: 'Clara', online: false, state: 'online', server: '', unread: 0, style: null, tier: '' }],
    incoming: [], outgoing: []
  };
  const me = () => ({ id: 'u1', nick: 'Anna', tier: st.tier, style: null, created: Date.UTC(2025, 0, 15) });
  const who = req => { const m = /^Bearer (.+)$/.exec(req.headers.authorization || ''); return m && st.tokens.has(m[1]) ? m[1] : null; };
  const sse = (type, data) => { for (const r of st.events) r.write(`event: ${type}\ndata: ${JSON.stringify(data)}\n\n`); };
  const journal = (kind, m, extra) => { st.log.push({ id: ++st.seq, ts: Date.now(), kind, room: 'global', msgId: m.id, uid: m.from, nick: m.nick, text: m.text, ...extra }); };
  const mkMsg = (text, from, to) => ({ id: 'm' + (++st.n), from, to, nick: from === 'u1' ? 'Anna' : 'Boris', text, ts: Date.now(), type: 'text' });

  const server = http.createServer((req, res) => {
    const chunks = []; req.on('data', c => chunks.push(c));
    req.on('end', () => {
      const url = new URL(req.url, 'http://x'), u = url.pathname, json = (o, code) => { res.writeHead(code || 200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); };
      let body = {}; try { body = JSON.parse(Buffer.concat(chunks).toString() || '{}'); } catch {}
      st.calls.push(req.method + ' ' + u);
      if (st.down) return json({ error: 'сервер недоступен' }, 503);
      if (u === '/api/info') return json({ proto: 2, needCode: false, tiers: [], ...(st.features ? { features: st.features } : {}) });
      if (u === '/api/login') {
        if (st.failLogin > 0) { st.failLogin--; return json({ error: 'временная ошибка' }, 503); }
        if (String(body.nick).toLowerCase() !== 'anna' || body.password !== st.password) return json({ error: 'Неверный ник или пароль' }, 401);
        const t = 'T' + (++st.n); st.tokens.add(t); return json({ token: t, user: me() });
      }
      if (u === '/api/logout') { const t = who(req); if (t) st.tokens.delete(t); return json({}); }
      const tok = who(req); if (!tok) return json({ error: 'нужен вход' }, 401);
      if (u === '/api/events') { res.writeHead(200, { 'Content-Type': 'text/event-stream' }); res.write('event: hello\ndata: ' + JSON.stringify({ me: me() }) + '\n\n'); st.events.add(res); res.on('close', () => st.events.delete(res)); return; }
      if (u === '/api/friends') return json({ friends: st.friends, incoming: st.incoming, outgoing: st.outgoing });
      if (u === '/api/profile' && req.method === 'POST' && st.failProfile > 0) { st.failProfile--; return json({ error: 'временная ошибка' }, 503); }
      if (u === '/api/profile' && req.method === 'POST') { if (st.slowProfile > 0) { const d = st.slowProfile; st.slowProfile = 0; setTimeout(() => { st.profiles.push(body); json({}); }, d); return; } st.profiles.push(body); return json({}); } // «медленный» Hub применяет запрос позже
      if (u === '/api/presence' || u === '/api/profile') return json({});
      let m;
      if (/^\/api\/chat\/[^/]+\/read$/.test(u)) return json({});
      if ((m = /^\/api\/chat\/([^/]+)$/.exec(u))) {
        if (req.method === 'GET') return json({ messages: st.dm[m[1]] || [] });
        if (req.method === 'POST') { const msg = mkMsg(String(body.text || ''), 'u1', m[1]); (st.dm[m[1]] = st.dm[m[1]] || []).push(msg); return json({ message: msg }); }
      }
      if (!st.features && (/^\/api\/(chat|room)\/[^/]+\/[^/]+$/.test(u) || u.startsWith('/api/admin/chatlog'))) return json({}, 404); // старый Hub: такого пути нет, ответ без текста ошибки
      if ((m = /^\/api\/chat\/([^/]+)\/([^/]+)$/.exec(u))) {
        const list = st.dm[m[1]] || [], msg = list.find(x => x.id === m[2]); if (!msg) return json({ error: 'Сообщение не найдено' }, 404);
        if (msg.from !== 'u1') return json({ error: 'Чужое сообщение нельзя изменить' }, 403);
        if (req.method === 'PATCH') { msg.text = String(body.text || '').slice(0, 500); msg.edited = Date.now(); sse('message_edit', msg); return json({ message: msg }); }
        if (req.method === 'DELETE') { list.splice(list.indexOf(msg), 1); sse('message_del', { id: msg.id, from: msg.from, to: msg.to }); return json({ ok: true }); }
      }
      if (u === '/api/room/global' || u === '/api/room/local') {
        if (req.method === 'GET') return json({ messages: u.endsWith('global') ? st.global : [], online: 3, room: u.endsWith('global') ? 'global' : '' });
        if (req.method === 'POST') { const msg = mkMsg(String(body.text || '').slice(0, 300), 'u1', ''); if (u.endsWith('global')) { st.global.push(msg); journal('send', msg); } return json({ message: msg }); }
      }
      if ((m = /^\/api\/room\/(global|local)\/([^/]+)$/.exec(u))) {
        const list = m[1] === 'global' ? st.global : [], msg = list.find(x => x.id === m[2]); if (!msg) return json({ error: 'Сообщение не найдено' }, 404);
        const admin = st.tier === 'admin'; if (msg.from !== 'u1' && !(admin && req.method === 'DELETE')) return json({ error: 'Чужое сообщение нельзя изменить' }, 403);
        if (req.method === 'PATCH') { const old = msg.text; msg.text = String(body.text || '').slice(0, 300); msg.edited = Date.now(); if (m[1] === 'global') journal('edit', msg, { old }); sse('room_edit', { kind: m[1], msg }); return json({ message: msg }); }
        if (req.method === 'DELETE') { list.splice(list.indexOf(msg), 1); if (m[1] === 'global') journal('delete', msg, { by: { id: 'u1', nick: 'Anna' } }); sse('room_del', { kind: m[1], id: msg.id }); return json({ ok: true }); }
      }
      if (u === '/api/admin/chatlog') {
        if (st.tier !== 'admin') return json({ error: 'Только для администратора' }, 403);
        const before = +url.searchParams.get('before') || Infinity, kind = url.searchParams.get('kind'), limit = Math.min(200, +url.searchParams.get('limit') || 50);
        const all = st.log.filter(e => e.id < before && (!kind || e.kind === kind)).sort((a, b) => b.id - a.id);
        return json({ entries: all.slice(0, limit), more: all.length > limit });
      }
      json({});
    });
  });
  return {
    st, server, sse, listen: port => new Promise(r => server.listen(port || 0, '127.0.0.1', () => r('http://127.0.0.1:' + server.address().port))),
    // чужое сообщение в глобальном чате (его написал Boris)
    addForeign: text => { const msg = mkMsg(text, 'f1', ''); st.global.push(msg); journal('send', msg); return msg; },
    close: () => { for (const r of st.events) { try { r.end(); } catch {} } return new Promise(r => server.close(() => r())); }
  };
}

module.exports = { createMockHub };
