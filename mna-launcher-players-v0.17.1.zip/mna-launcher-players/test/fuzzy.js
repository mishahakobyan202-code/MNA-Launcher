'use strict';
// Нечёткий поиск: опечатки, раскладка, порядок слов, строгие номера версий, отсутствие ложных совпадений.
const assert = require('assert'), F = require('../fuzzy');
let n = 0; const ok = s => { n++; console.log('  ✔', s); };
const find = (items, q, o) => F.search(items, q, x => x, o);

console.log('fuzzy.js');
assert.strictEqual(F.norm('  ЁлкА—Test_1.20.1. '), 'елка test 1.20.1'); ok('приведение: регистр, ё, знаки, точки на краях');
assert.strictEqual(F.dist('minecraft', 'minecrfat', 5), 1); assert.strictEqual(F.dist('abc', 'xyz', 1), 2); assert.strictEqual(F.dist('привет', 'прифет', 3), 1); ok('расстояние Дамерау — Левенштейна, перестановка = 1 правка');

const mods = ['Sodium', 'Lithium', 'Fabric API', 'Create', 'Iris Shaders', 'Minecraft Forge', 'JourneyMap', 'Xaero\'s Minimap', 'Mod Menu', 'Terralith'];
for (const [q, want] of [['sodiun', 'Sodium'], ['sodum', 'Sodium'], ['lithuim', 'Lithium'], ['fabrik api', 'Fabric API'], ['api fabric', 'Fabric API'], ['fabrci', 'Fabric API'],
  ['irsi', 'Iris Shaders'], ['jorneymap', 'JourneyMap'], ['journeymap', 'JourneyMap'], ['minecrfat forge', 'Minecraft Forge'], ['minecraftforge', 'Minecraft Forge'], ['mine craft forge', 'Minecraft Forge'],
  ['terallith', 'Terralith'], ['xaeros minimp', 'Xaero\'s Minimap'], ['modmenu', 'Mod Menu'], ['mncrft', 'Minecraft Forge']])
  assert.strictEqual(find(mods, q)[0], want, q + ' → ' + want);
ok('опечатки: перестановка, пропуск, лишняя и неверная буква, порядок слов, слитно и раздельно, сокращение');

const ru = ['Привет', 'Прекрасный мир', 'Выживание', 'Креатив', 'Мои сборки'];
for (const [q, want] of [['прифет', 'Привет'], ['превит', 'Привет'], ['выжыванье', 'Выживание'], ['креотив', 'Креатив'], ['сборки мои', 'Мои сборки'], ['ё', null]])
  { const r = find(ru, q)[0]; assert.strictEqual(r === undefined ? null : r, want, q); }
ok('русский: опечатки и другой порядок слов');

assert.strictEqual(find(['Привет', 'Hello', 'Выживание'], 'ghbdtn')[0], 'Привет'); assert.strictEqual(find(['Привет', 'Hello', 'Выживание'], 'руддщ')[0], 'Hello'); assert.strictEqual(find(['Привет', 'Выживание'], 'ds;bdfybt')[0], 'Выживание');
assert.strictEqual(F.otherLayout('ghbdtn'), 'привет'); assert.strictEqual(F.otherLayout('привет'), 'ghbdtn'); assert.strictEqual(F.otherLayout('1.20.1'), ''); ok('неверная раскладка: ghbdtn ↔ привет, цифры без путаницы');

const sorted = find(['Sodium Extra', 'Sodium', 'Reese\'s Sodium Options', 'Odium', 'Soda'], 'sodium');
assert.deepStrictEqual(sorted.slice(0, 3), ['Sodium', 'Sodium Extra', 'Reese\'s Sodium Options']); assert(!sorted.slice(0, 3).includes('Odium') && !sorted.slice(0, 3).includes('Soda')); ok('порядок: точное, потом начало, потом внутри, потом с опечатками');

const vers = ['1.21.1', '1.21', '1.20.1', '1.20.2', '1.2.1', '24w14a', '1.8.9', '1.12.2'];
assert.deepStrictEqual(find(vers, '1.20.1'), ['1.20.1']); assert.deepStrictEqual(find(vers, '1.20'), ['1.20.1', '1.20.2']); assert.deepStrictEqual(find(vers, '24w14a'), ['24w14a']); assert.deepStrictEqual(find(vers, '1.2'), ['1.21', '1.2.1', '1.21.1', '1.20.1', '1.20.2']); ok('номера версий ищутся строго: 1.20.1 не находит 1.20.2');

for (const [q, items] of [['minecraft', ['Terraria', 'Mineral', 'Minimap', 'Create']], ['sodium', ['Lithium', 'Iris', 'Create']], ['ab', ['zb', 'cd']], ['привет', ['Прибор', 'Креатив']], ['xyz', ['Sodium', 'Fabric']]])
  assert.deepStrictEqual(find(items, q), [], q + ' не должно ничего находить');
ok('нет ложных совпадений на непохожих словах и очень коротких запросах');

assert.deepStrictEqual(find(['b', 'a', 'c'], ''), ['b', 'a', 'c']); assert.deepStrictEqual(find(['b', 'a', 'c'], '   '), ['b', 'a', 'c']); assert.deepStrictEqual(find(['b', 'a', 'c'], '', { limit: 2 }), ['b', 'a']); assert.deepStrictEqual(find([], 'x'), []); ok('пустой запрос возвращает всё как есть; пустой список ничего не ломает');
assert.deepStrictEqual(F.search([{ n: 'Create', id: 1 }, { n: 'Iris', id: 2 }], 'creat', o => [o.n, 'id' + o.id]).map(o => o.id), [1]); assert.deepStrictEqual(F.search([{ a: 'x', b: 'Sodium' }], 'sodum', o => [o.a, o.b]).length, 1); ok('несколько полей у элемента: берётся лучшее');
assert.strictEqual(F.suggest('sodiun', ['Lithium', 'Sodium', 'Iris']), 'Sodium'); assert.strictEqual(F.suggest('qqqq', ['Lithium', 'Sodium']), null); ok('«возможно, ты искал»');
assert.strictEqual(F.score('sodium', 'Sodium'), 1); assert(F.score('sodiun', 'Sodium') > 0.7 && F.score('sodiun', 'Sodium') < 1); assert.strictEqual(F.score('', 'x'), 0); assert.strictEqual(F.score(null, null), 0); assert.strictEqual(F.score(undefined, 'abc'), 0); ok('оценка в пределах 0…1, мусор на входе не падает');
// скорость: 5000 элементов должны искаться мгновенно
const big = Array.from({ length: 5000 }, (_, i) => 'Mod number ' + i + ' ' + (i % 7 ? 'alpha beta' : 'gamma delta')); const t0 = Date.now(); F.search(big, 'gamna delta'); assert(Date.now() - t0 < 1000, 'медленно: ' + (Date.now() - t0) + ' мс'); ok('5000 элементов ищутся быстро');
const hostile = ['__proto__', 'constructor', 'a'.repeat(5000), '\u0000‮', '😀😀', '']; for (const h of hostile) { F.search(['x', h], h); F.score(h, h); } ok('странные строки не ломают поиск');
console.log(`\nГотово: ${n} проверок прошли`);
