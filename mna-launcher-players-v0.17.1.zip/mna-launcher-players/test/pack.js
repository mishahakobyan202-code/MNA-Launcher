'use strict';
// Все файлы, которые нужны приложению, должны попасть в сборку (build.files в package.json).
// Иначе из исходников всё работает, а в готовом .exe лаунчер не запускается.
const assert = require('assert'), fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..'), pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8')), files = pkg.build.files;
let n = 0; const ok = s => { n++; console.log('  ✔', s); };
const packed = f => files.some(g => g === f || (g.endsWith('/**') && f.startsWith(g.slice(0, -2))));

console.log('сборка');
const need = new Set(['index.html', pkg.main]);
for (const f of ['main.js', 'preload.js', 'hub.js', 'net.js', 'profile.js', 'skins.js', 'tiers.js', 'zip.js', 'fuzzy.js', 'servers.js']) for (const m of fs.readFileSync(path.join(root, f), 'utf8').matchAll(/require\('\.\/([\w-]+)(\.js)?'\)/g)) need.add(m[1] + '.js');
for (const m of fs.readFileSync(path.join(root, 'index.html'), 'utf8').matchAll(/<script src="([^":]+)"/g)) need.add(m[1]);
for (const f of need) { assert(fs.existsSync(path.join(root, f)), 'нет файла ' + f); assert(packed(f), f + ' не попадёт в сборку: добавь в build.files'); }
ok('все подключаемые файлы (' + [...need].filter(f => !f.startsWith('assets/')).join(', ') + ') есть в build.files');
assert(!files.some(f => /^test|node_modules/.test(f))); ok('тесты в сборку не попадают');
assert(/^\d+\.\d+\.\d+$/.test(pkg.version)); ok('версия ' + pkg.version);

// Установщик и portable: имена файлов в сборке, в рабочем процессе выпуска и на странице скачивания должны совпадать.
const setup = pkg.build.nsis && pkg.build.nsis.artifactName, portable = pkg.build.portable && pkg.build.portable.artifactName;
assert.strictEqual(setup, 'MNA-Launcher-Setup.exe'); assert.strictEqual(portable, 'MNA-Launcher.exe'); assert.notStrictEqual(setup, portable);
assert.deepStrictEqual(pkg.build.win.target.slice().sort(), ['nsis', 'portable']); assert(/nsis/.test(pkg.scripts.build) && /portable/.test(pkg.scripts.build));
assert.strictEqual(pkg.build.nsis.oneClick, true); assert.strictEqual(pkg.build.nsis.perMachine, false); assert.strictEqual(pkg.build.nsis.deleteAppDataOnUninstall, false);
ok('сборка: установщик без прав администратора, данные игры при удалении не трогаются, рядом portable');
assert(Array.isArray(pkg.build.electronLanguages) && pkg.build.electronLanguages.includes('ru') && pkg.build.electronLanguages.includes('en-US') && pkg.build.electronLanguages.length <= 3); ok('лишние языки Chromium не попадают в сборку');
const wf = fs.readFileSync(path.join(root, '.github/workflows/release.yml'), 'utf8'), page = fs.readFileSync(path.join(root, 'docs/index.html'), 'utf8');
for (const name of [setup, portable, 'SHA256SUMS.txt']) { assert(wf.includes('dist/' + name), 'workflow не публикует ' + name); assert(page.includes(name), 'страница скачивания не знает файл ' + name); }
assert(/npm run build/.test(wf) && /tags:\s*\['v\*'\]/.test(wf)); ok('workflow выпуска и страница скачивания ссылаются на те же файлы, что собирает electron-builder');
const bat = fs.readFileSync(path.join(root, 'build.bat')); assert(!bat.some(b => b > 127), 'build.bat должен быть чистым ASCII (кириллица ломает cmd)'); assert(bat.includes('\r\n')); assert(/npm run build/.test(bat.toString()) && !/MNA-Launcher-v/.test(bat.toString())); ok('build.bat: только ASCII, переводы строк Windows, запускает общую сборку');
console.log(`\nГотово: ${n} проверок прошли`);
