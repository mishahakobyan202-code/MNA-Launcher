'use strict';
// Сквозная проверка скинов и профиля: настоящие main.js + index.html в Chromium, подменены только Electron, Minecraft, Mojang и Hub (маленький ненастоящий сервер ниже).
// Запуск: NODE_PATH=$(npm root -g) node test/profile-ui.js   (нужен playwright с Chromium; SHOTS=папка сохранит скриншоты)
const fs = require('fs'), os = require('os'), path = require('path'), http = require('http'), assert = require('assert');
const EventEmitter = require('events'), Module = require('module');
let chromium; try { ({ chromium } = require('playwright')); } catch { console.log('playwright не найден: проверка интерфейса пропущена'); process.exit(0); }
const S = require('../skins.js'), { readZipFile } = require('../zip.js');

const LAUNCHER = path.join(__dirname, '..'), tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'mna-pui-')), appData = path.join(tmp, 'appdata'), root = path.join(appData, '.mna');
fs.mkdirSync(root, { recursive: true });
let n = 0; const ok = s => { n++; console.log('  ✔', s); };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const until = async (fn, ms = 6000, what = '') => { const t = Date.now(); for (;;) { const v = await fn(); if (v) return v; if (Date.now() - t > ms) throw new Error('не дождались: ' + what); await sleep(30); } };

// ---------- подмена Electron / Minecraft / Microsoft ----------
const handlers = new Map(), sent = [], launches = []; let dialogResult = { canceled: true, filePaths: [] }, theWin = null, pageSend = () => {};
class BW { constructor() { theWin = this; this.destroyed = false; this.webContents = { send: (ch, d) => { sent.push([ch, d]); pageSend(ch, d); }, focus() {}, isFocused: () => true }; } loadFile() {} on() {} isDestroyed() { return this.destroyed; } isFocused() { return true; } isMinimized() { return false; } show() {} setIcon() {} focus() {} restore() {} minimize() {} destroy() { this.destroyed = true; } }
const quits = [];
const electron = {
  app: { getPath: () => appData, getVersion: () => '0.19.0', setAppUserModelId() {}, requestSingleInstanceLock: () => true, whenReady: () => Promise.resolve(), on(ev, f) { if (ev === 'before-quit') quits.push(f); }, quit() {} },
  BrowserWindow: BW, ipcMain: { handle: (ch, fn) => handlers.set(ch, fn) }, shell: { openPath() {}, showItemInFolder() {}, openExternal() {} }, dialog: { showOpenDialog: async () => dialogResult },
  safeStorage: { encryptString: s => Buffer.from('ENC' + s), decryptString: b => { const t = String(b); if (!t.startsWith('ENC')) throw new Error('bad'); return t.slice(3); } },
  Tray: class { setToolTip() {} setContextMenu() {} on() {} destroy() {} }, Menu: { buildFromTemplate: x => x },
  nativeImage: { createFromPath: () => ({ isEmpty: () => true, resize() { return this; } }) }, Notification: class { static isSupported() { return false; } }
};
class MCClient extends EventEmitter { launch(o) { launches.push({ o, client: this }); return Promise.resolve({ pid: 4242 }); } }
const origLoad = Module._load;
Module._load = function (req) {
  if (req === 'electron') return electron;
  if (req === 'minecraft-launcher-core') return { Client: MCClient, Authenticator: { getAuth: nick => ({ name: nick, access_token: 'x', uuid: 'u' }) } };
  if (req === 'msmc') return { Auth: class { async refresh() { throw new Error('нет сохранённого входа'); } async launch() { return { save: () => 'tok', getMinecraft: async () => ({ mclc: () => ({ access_token: 'MSTOKEN', client_token: 'c', uuid: '0'.repeat(32), name: 'MsPlayer', user_properties: '{}' }), profile: { name: 'MsPlayer' } }) }; } } };
  return origLoad.apply(this, arguments);
};

// ---------- картинки для проверок ----------
const rgba = Buffer.alloc(64 * 64 * 4);
const fill = (x0, y0, x1, y1, c) => { for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) rgba.set([c[0], c[1], c[2], 255], (y * 64 + x) * 4); };
const C = { red: [255, 0, 0], dred: [128, 0, 0], blue: [0, 0, 255], dblue: [0, 0, 128], green: [0, 255, 0], dgreen: [0, 128, 0], yellow: [255, 255, 0], dyellow: [128, 128, 0], purple: [255, 0, 255], dpurple: [128, 0, 128], orange: [255, 128, 0], dorange: [128, 64, 0], gray: [90, 90, 90] };
fill(0, 0, 31, 15, C.gray); fill(0, 16, 55, 31, C.gray); fill(16, 48, 47, 63, C.gray);
fill(8, 8, 15, 15, C.red); fill(24, 8, 31, 15, C.dred); fill(20, 20, 27, 31, C.blue); fill(32, 20, 39, 31, C.dblue);
fill(44, 20, 47, 31, C.green); fill(52, 20, 55, 31, C.dgreen); fill(36, 52, 39, 63, C.yellow); fill(44, 52, 47, 63, C.dyellow);
fill(4, 20, 7, 31, C.purple); fill(12, 20, 15, 31, C.dpurple); fill(20, 52, 23, 63, C.orange); fill(28, 52, 31, 63, C.dorange);
const skinPng = S.encodePng(64, 64, rgba), skinFile = path.join(tmp, 'my skin.png'); fs.writeFileSync(skinFile, skinPng);
const friendRgba = Buffer.alloc(64 * 64 * 4); for (let y = 0; y < 64; y++) for (let x = 0; x < 64; x++) friendRgba.set([40 + x * 3, 200 - y * 2, 120, 255], (y * 64 + x) * 4);
const friendPng = S.encodePng(64, 64, friendRgba);

// ---------- подмена сети: Hub и Mojang ----------
const seen = { posts: [], mojang: null }; let profileMode = 'ok';
const sseClients = new Set();
const FR = { friends: [{ id: 'f1', nick: 'Boris', online: true, state: 'ingame', server: 'mc.test.net', unread: 0, style: null, tier: 'plus' }, { id: 'f2', nick: 'Clara', online: false, state: 'online', server: '', unread: 0, style: null, tier: '' }], incoming: [{ id: 'r1', nick: 'Dan', style: null, tier: '' }], outgoing: [] };
const hubSrv = http.createServer((q, r) => {
  const chunks = []; q.on('data', c => chunks.push(c)); q.on('end', () => {
    const body = Buffer.concat(chunks), u = q.url.split('?')[0], json = (o, code) => { r.writeHead(code || 200, { 'Content-Type': 'application/json' }); r.end(JSON.stringify(o)); };
    if (u === '/api/info') return json({ proto: 2, needCode: false, tiers: [] });
    if (u === '/api/login') return json({ token: 'HTOK', user: { id: 'u1', nick: 'Anna', tier: 'pro', style: null, created: Date.UTC(2025, 0, 15) } });
    if (u === '/api/events') { r.writeHead(200, { 'Content-Type': 'text/event-stream' }); r.write('event: hello\ndata: ' + JSON.stringify({ me: { id: 'u1', nick: 'Anna', tier: 'pro', style: null, created: Date.UTC(2025, 0, 15) } }) + '\n\n'); sseClients.add(r); q.on('close', () => sseClients.delete(r)); return; }
    if (u === '/api/friends') return json(FR);
    if (u === '/api/profile/f1') return profileMode === 'ok' ? json({ bio: 'Строю замок\nи фермы', since: '2025-03-02T10:00:00Z', skin: { model: 'slim', png: friendPng.toString('base64') } }) : json({ error: 'нет' }, 404);
    if (u === '/api/profile/f2') return json({ bio: 'x'.repeat(5000), skin: { model: 'classic', png: 'не картинка' } });
    if (u === '/api/profile/r1') return profileMode === 'ok' ? json({}) : json({ error: 'нет' }, 404);
    if (u === '/api/profile' && q.method === 'POST') { seen.posts.push(JSON.parse(body.toString())); return profileMode === 'ok' ? json({}) : json({ error: 'нет' }, 404); }
    if (u.startsWith('/api/chat/')) return json({ messages: [] });
    json({});
  });
}).listen(0, '127.0.0.1');
const mojang = http.createServer((q, r) => { const ch = []; q.on('data', c => ch.push(c)); q.on('end', () => { seen.mojang = { url: q.url, auth: q.headers.authorization, body: Buffer.concat(ch) }; r.writeHead(200, { 'Content-Type': 'application/json' }); r.end('{}'); }); }).listen(0, '127.0.0.1');
const realFetch = global.fetch;
global.fetch = (u, o = {}) => { try { const x = new URL(String(u)); if (x.hostname === 'api.minecraftservices.com') return realFetch(`http://127.0.0.1:${mojang.address().port}${x.pathname}`, o); } catch {} return realFetch(u, o); };

(async () => {
  await Promise.all([new Promise(r => hubSrv.on('listening', r)), new Promise(r => mojang.on('listening', r))]);
  const hubUrl = 'http://127.0.0.1:' + hubSrv.address().port;
  const javaStub = path.join(tmp, 'java'); fs.writeFileSync(javaStub, '#!/bin/sh\nexit 0\n', { mode: 0o755 });
  fs.writeFileSync(path.join(root, 'config.json'), JSON.stringify({ hubUrl, java: javaStub, loader: 'vanilla', mc: '1.21.1', autover: false, onlaunch: 'none', featured: false, nick: 'Player', cfgv: 4 }));
  require('../main.js'); await sleep(100); assert(theWin && handlers.has('skins:list') && handlers.has('profile:get') && handlers.has('hub:profile')); ok('main.js загружен, обработчики скинов и профиля на месте');
  const H = (ch, a) => handlers.get(ch)({}, a), instDir = path.join(root, 'instances', '1.21.1-vanilla'), pack = path.join(instDir, 'resourcepacks', 'MNA-Skin.zip'), opts = path.join(instDir, 'options.txt');
  const play = async arg => { launches.length = 0; const r = await H('play', arg); await until(() => launches.length === 1 || r === false, 4000, 'запуск'); return r; };
  const closeGame = () => { launches[0].client.emit('close'); };

  console.log('Скины: библиотека');
  let p = await H('skins:list'); assert.deepStrictEqual(p.items, []); assert.strictEqual(p.active, ''); assert.strictEqual(p.packOk, true); ok('сначала библиотека пуста');
  assert.strictEqual(await H('skins:pick'), null); ok('отмена выбора файла ничего не делает');
  const bad = path.join(tmp, 'bad.png'); fs.writeFileSync(bad, 'это не картинка, просто текст, достаточно длинный чтобы пройти проверку размера файла............');
  dialogResult = { canceled: false, filePaths: [bad] }; await assert.rejects(H('skins:pick'), /не PNG/);
  const big = path.join(tmp, 'big.png'); fs.writeFileSync(big, Buffer.concat([skinPng, Buffer.alloc(S.MAX_PNG)])); dialogResult = { canceled: false, filePaths: [big] }; await assert.rejects(H('skins:pick'), /слишком большой/);
  const hd = path.join(tmp, 'hd.png'); fs.writeFileSync(hd, (() => { const z = require('zlib'), { crc32 } = require('../zip.js'); const ck = (t, d) => { const l = Buffer.alloc(4); l.writeUInt32BE(d.length); const td = Buffer.concat([Buffer.from(t), d]), c = Buffer.alloc(4); c.writeUInt32BE(crc32(td)); return Buffer.concat([l, td, c]); }; const ih = Buffer.alloc(13); ih.writeUInt32BE(128, 0); ih.writeUInt32BE(128, 4); ih[8] = 8; ih[9] = 6; return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), ck('IHDR', ih), ck('IDAT', z.deflateSync(Buffer.alloc(128 * 513))), ck('IEND', Buffer.alloc(0))]); })());
  dialogResult = { canceled: false, filePaths: [hd] }; await assert.rejects(H('skins:pick'), /64×64/); assert.deepStrictEqual((await H('skins:list')).items, []); ok('не PNG, огромный файл и 128×128: понятные ошибки, в библиотеку ничего не попало');
  dialogResult = { canceled: false, filePaths: [skinFile] }; p = await H('skins:pick');
  assert.strictEqual(p.items.length, 1); assert.strictEqual(p.items[0].name, 'my skin'); assert.strictEqual(p.items[0].model, 'classic'); assert.strictEqual(p.active, p.items[0].id); assert(p.items[0].png.startsWith('data:image/png;base64,')); ok('скин из файла добавлен, выбран, модель определена как «обычные руки»');
  const sid = p.active; assert(fs.existsSync(path.join(root, 'skins', sid + '.png'))); assert(S.decodePng(fs.readFileSync(path.join(root, 'skins', sid + '.png'))).rgba.equals(rgba)); ok('в папке .mna/skins лежит пересохранённый PNG с теми же пикселями');
  p = await H('skins:pick'); assert.strictEqual(p.items.length, 1); ok('тот же файл второй раз не дублируется');
  await assert.rejects(H('skins:select', { id: 's-00000000' }), /нет в библиотеке/); await assert.rejects(H('skins:remove', { id: '../../x' }), /нет в библиотеке/); await assert.rejects(H('skins:model', { id: sid, model: 'evil' }), /модель/); ok('чужие id и неверная модель отклоняются');
  p = await H('skins:rename', { id: sid, name: '  Мой\u0000 герой  ' }); assert.strictEqual(p.items[0].name, 'Мой герой'); ok('имя очищается от управляющих символов');

  console.log('Скины: в игре');
  await H('hub:login', { nick: 'Anna', password: 'secret12' }); await until(() => H('hub:snapshot').then(s => s.state.loggedIn), 3000, 'вход в Hub'); await until(() => H('hub:snapshot').then(s => s.state.connected), 3000, 'SSE');
  assert.strictEqual(await play(), true); assert(fs.existsSync(pack)); ok('перед запуском в сборку кладётся MNA-Skin.zip');
  const T = 'assets/minecraft/textures/entity/'; const want = S.arms(S.opaqueBase(Buffer.from(rgba)), 'classic', 'classic');
  assert(S.decodePng(readZipFile(pack, T + 'player/wide/steve.png')).rgba.equals(want)); assert.strictEqual(JSON.parse(readZipFile(pack, 'pack.mcmeta')).pack.pack_format, 34); ok('в паке скин игрока (широкие руки), формат 34 для 1.21.1');
  assert.strictEqual(fs.readFileSync(opts, 'utf8'), 'resourcePacks:["vanilla","file/MNA-Skin.zip"]\n'); ok('options.txt создан, пак включён');
  const mt = fs.statSync(pack).mtimeMs; closeGame(); await sleep(20); fs.writeFileSync(opts, 'lang:ru_ru\r\nresourcePacks:["vanilla","file/other.zip"]\r\nfov:0.5\r\n'); await play(); assert.strictEqual(fs.readFileSync(opts, 'utf8'), 'lang:ru_ru\r\nresourcePacks:["vanilla","file/other.zip","file/MNA-Skin.zip"]\r\nfov:0.5\r\n'); assert.strictEqual(fs.statSync(pack).mtimeMs, mt); ok('чужие настройки и переводы строк не тронуты, неизменный пак не переписывается');
  closeGame(); await play('srv.test.net'); assert(fs.existsSync(pack)); assert.strictEqual(launches[0].o.quickPlay.identifier, 'srv.test.net'); closeGame();
  p = await H('skins:servers', { on: false }); assert.strictEqual(p.servers, false); await play('srv.test.net'); assert(!fs.existsSync(pack)); assert(!/MNA-Skin/.test(fs.readFileSync(opts, 'utf8'))); assert(/other\.zip/.test(fs.readFileSync(opts, 'utf8'))); closeGame(); await play(); assert(fs.existsSync(pack)); closeGame(); ok('«не применять на серверах»: на сервере пака нет, в одиночной он на месте');
  await H('skins:servers', { on: true }); await H('skins:select', { id: '' }); await play(); assert(!fs.existsSync(pack)); assert(!/MNA-Skin/.test(fs.readFileSync(opts, 'utf8'))); assert(/other\.zip/.test(fs.readFileSync(opts, 'utf8'))); closeGame(); ok('«убрать скин»: пак и запись в options.txt исчезают, чужой пак остаётся');
  await H('skins:select', { id: sid }); await H('skins:model', { id: sid, model: 'slim' }); await play(); const slimWide = S.decodePng(readZipFile(pack, T + 'player/slim/steve.png')).rgba; assert(S.detectSlim(slimWide)); closeGame(); await H('skins:model', { id: sid, model: 'classic' }); ok('смена модели рук сразу попадает в следующий пак');

  console.log('Статистика и профиль');
  const realNow = Date.now; let shift = 0; Date.now = () => realNow() + shift;
  await play('mc.test.net'); shift = 90 * 60000; const live = await H('profile:get'); assert.strictEqual(live.me.status, 'ingame'); assert.strictEqual(live.me.server, 'mc.test.net'); assert(/1 ч 30 мин/.test(live.stats.playText)); closeGame(); await sleep(30); shift = 0; Date.now = realNow;
  await until(async () => (await H('profile:get')).friends.length === 2, 8000, 'список друзей в профиле'); const pr = await H('profile:get'); assert.strictEqual(pr.me.nick, 'Anna'); assert.strictEqual(pr.me.loggedIn, true); assert.strictEqual(pr.me.tierName, 'Pro'); assert.strictEqual(pr.me.since, Date.UTC(2025, 0, 15)); assert.strictEqual(pr.me.status, 'online');
  assert(pr.stats.launches >= 6); assert(pr.stats.playMs >= 90 * 60000 && pr.stats.playMs < 91 * 60000 + 5000 * 60000); assert.strictEqual(pr.stats.servers.find(x => x.key === 'mc.test.net').n, 1); assert(pr.stats.servers.find(x => x.key === 'mc.test.net').ms >= 90 * 60000); assert(pr.stats.versions.some(v => v.key === '1.21.1')); ok('время игры и серверы считаются: 1 ч 30 мин на mc.test.net, запуски и версии учтены');
  assert(!pr.badges.some(b => b.id === 'h10')); assert(pr.badges.some(b => b.id === 'skin') && pr.badges.some(b => b.id === 'first')); assert.strictEqual(pr.skin.id, sid); assert.strictEqual(pr.friends.length, 2); ok('значки, текущий скин и друзья в профиле');
  const st = JSON.parse(fs.readFileSync(path.join(root, 'stats.json'), 'utf8')); assert.strictEqual(st.launches, pr.stats.launches); ok('статистика записана в stats.json');
  const bio = await H('profile:bio', { bio: '  Люблю Create\u0000 и фермы\n\n\n\nприходи  ' }); assert.strictEqual(bio, 'Люблю Create и фермы\n\nприходи'); assert.strictEqual((await H('profile:get')).me.bio, bio); ok('«о себе» очищается и сохраняется');
  await until(() => seen.posts.length && seen.posts[seen.posts.length - 1].bio === bio, 8000, 'Hub получил «о себе»'); const last = seen.posts[seen.posts.length - 1]; assert.strictEqual(last.bio, bio); assert.strictEqual(last.skin.model, 'classic'); assert(S.decodePng(Buffer.from(last.skin.png, 'base64')).rgba.equals(rgba)); assert.strictEqual((await H('profile:get')).sync, true); ok('Hub получил «о себе» и скин (если он умеет профили)');
  const fp = await H('hub:profile', { id: 'f1' }); assert.strictEqual(fp.supported, true); assert.strictEqual(fp.rel, 'friend'); assert.strictEqual(fp.friend.nick, 'Boris'); assert.strictEqual(fp.remote.bio, 'Строю замок\nи фермы'); assert.strictEqual(fp.remote.since, Date.UTC(2025, 2, 2, 10)); assert.strictEqual(fp.remote.skin.model, 'slim'); assert(S.decodePng(Buffer.from(fp.remote.skin.png.split(',')[1], 'base64')).rgba.equals(friendRgba)); ok('профиль друга: «о себе», дата регистрации и скин пришли с Hub и проверены');
  const f2 = await H('hub:profile', { id: 'f2' }); assert.strictEqual(f2.remote.bio.length, 300); assert.strictEqual(f2.remote.skin, null); ok('слишком длинное «о себе» обрезается, битый скин друга отбрасывается');
  assert.strictEqual((await H('hub:profile', { id: 'r1' })).rel, 'incoming'); await assert.rejects(H('hub:profile', { id: 'zzz' }), /у друзей/); ok('профиль заявки открывается, чужой id отклоняется');

  console.log('Mojang');
  await H('login'); let sp = await H('skins:list'); assert.strictEqual(sp.ms, true); assert.strictEqual(sp.msName, 'MsPlayer');
  closeGame(); await play(); assert(!fs.existsSync(pack)); closeGame(); ok('с аккаунтом Microsoft пак не кладётся: скин берётся из аккаунта');
  assert.strictEqual(await H('skins:upload', { id: sid }), true); assert.strictEqual(seen.mojang.url, '/minecraft/profile/skins'); assert.strictEqual(seen.mojang.auth, 'Bearer MSTOKEN'); assert(seen.mojang.body.includes(Buffer.from('classic'))); assert(seen.mojang.body.includes(skinPng.subarray(0, 8))); ok('загрузка скина в аккаунт: токен Microsoft и PNG ушли в Mojang');

  console.log('Интерфейс');
  const browser = await chromium.launch(), page = await browser.newPage({ viewport: { width: 1180, height: 760 } });
  const pageErrors = []; page.on('pageerror', e => pageErrors.push(e.message));
  await page.exposeFunction('__invoke', async (ch, d) => { const h = handlers.get(ch); if (!h) throw new Error('нет обработчика ' + ch); return h({}, d); });
  await page.addInitScript(() => { window.__l = {}; window.mna = { invoke: (c, d) => window.__invoke(c, d), on: (c, f) => { (window.__l[c] = window.__l[c] || []).push(f); }, pathFor: () => '' }; });
  pageSend = (ch, d) => page.evaluate(([c, x]) => (window.__l[c] || []).forEach(f => f(x)), [ch, d]).catch(() => {});
  await page.goto('file://' + path.join(LAUNCHER, 'index.html'));
  const shot = async nm => { if (process.env.SHOTS) { fs.mkdirSync(process.env.SHOTS, { recursive: true }); await page.screenshot({ path: path.join(process.env.SHOTS, nm + '.png') }); } };
  const vis = sel => page.isVisible(sel), txt = sel => page.textContent(sel), nav = t => page.click(`nav button:has-text("${t}")`);
  const px = (sel, x, y) => page.evaluate(([s, a, b]) => Array.from(document.querySelector(s).getContext('2d').getImageData(a, b, 1, 1).data), [sel, x, y]);
  await until(async () => (await txt('#who')).includes('Anna'), 4000, 'вход виден в интерфейсе');

  const all = await page.evaluate(() => document.body.innerText + [...document.querySelectorAll('input,textarea')].map(i => i.placeholder || '').join(' '));
  const emoji = /[\u{1F000}-\u{1FAFF}☀-⛿✀-➿⬀-⯿️]/u; const OKCH = '⚙✕'; // ⚙ у «Настроек» и ✕ на кнопках удаления: простые знаки, не картинки
  const hits = [...all].filter(ch => emoji.test(ch) && !OKCH.includes(ch)); assert.deepStrictEqual(hits, []); ok('в видимом тексте главной нет эмодзи');
  const navText = (await page.evaluate(() => [...document.querySelectorAll('nav button')].map(b => b.textContent))).map(t => t.replace(/ \d+$/, ''));  // «Друзья 1»: счётчик заявок
  assert.deepStrictEqual(navText, ['Главная', 'Мои сборки', 'Версии', 'Каталог', 'Сервер', 'Мой сервер', 'Друзья', 'Профиль', 'Миры', 'Внешний вид', '⚙ Настройки']); ok('в меню значок только у «Настроек»');
  await shot('01-home');
  for (const t of ['Мои сборки', 'Версии', 'Каталог', 'Сервер', 'Друзья', 'Миры', 'Внешний вид', 'Настройки']) { await nav(t); await sleep(120); const txt2 = await page.evaluate(() => document.querySelector('section.on').innerText + [...document.querySelectorAll('section.on button, section.on input')].map(e => e.title + (e.placeholder || '')).join(' ')); assert.deepStrictEqual([...txt2].filter(ch => emoji.test(ch) && !OKCH.includes(ch)), [], t); }
  ok('на всех вкладках нет эмодзи и символов-картинок (остались ⚙ в меню и ✕ на кнопках удаления)');

  await nav('Профиль'); await until(async () => (await txt('#pfnick')).includes('Anna'), 4000, 'свой профиль');
  assert((await txt('#pfmeta')).includes('Pro') && (await txt('#pfmeta')).includes('аккаунт MNA') && (await txt('#pfmeta')).includes('15.01.2025')); assert((await txt('#pfstat')).includes('в сети')); assert((await txt('#pfbio')).includes('Люблю Create'));
  assert((await txt('#pfnum')).includes('1 ч 30 мин') || (await txt('#pfnum')).includes('1 ч 3')); assert((await txt('#pfbadges')).includes('Первый запуск') && (await txt('#pfbadges')).includes('Свой образ')); assert((await txt('#pfrec')).includes('mc.test.net')); assert((await txt('#pffr')).includes('Boris') && (await txt('#pffr')).includes('Clara')); ok('свой профиль: ник, уровень, дата, статус, «о себе», часы, значки, серверы, друзья');
  await until(async () => (await px('#pfcv', 64, 32))[3] === 255, 3000, 'скин нарисован'); await sleep(100);
  const front = { head: [64, 32, C.red], body: [64, 112, C.blue], 'правая рука (слева)': [16, 112, C.green], 'левая рука (справа)': [112, 112, C.yellow], 'правая нога': [48, 208, C.purple], 'левая нога': [80, 208, C.orange] };
  for (const [nm, [x, y, c]] of Object.entries(front)) assert.deepStrictEqual((await px('#pfcv', x, y)).slice(0, 3), c, 'спереди: ' + nm); assert.deepStrictEqual((await px('#pfcv', 0, 255)).slice(3), [0], 'вне фигуры прозрачно'); ok('предпросмотр спереди: голова, тело, руки и ноги на своих местах');
  await shot('02-profile-own');
  const decoded = await page.evaluate(async () => { const it = SK.items[0], im = await loadImg(it.png), c = document.createElement('canvas'); c.width = 64; c.height = 64; const x = c.getContext('2d'); x.drawImage(im, 0, 0); return Array.from(x.getImageData(0, 0, 64, 64).data); }); assert(Buffer.from(decoded).equals(rgba)); ok('Chromium читает наш PNG и видит те же пиксели');
  assert((await page.getAttribute('#av', 'src')).startsWith('data:image/png')); ok('аватар в углу — голова выбранного скина');

  await page.click('#pfedit'); assert(await vis('#pfta')); await page.fill('#pfta', 'Новый текст\nо себе'); assert((await txt('#pfcnt')).includes('/ 300')); await page.click('#pfsave'); await until(async () => (await txt('#pfbio')).includes('Новый текст'), 3000, 'новое о себе'); assert(!await vis('#pfta')); assert.strictEqual((await H('profile:get')).me.bio, 'Новый текст\nо себе'); ok('«о себе» редактируется прямо в профиле');

  await page.click('#pfskin'); await until(() => vis('#skpick'), 3000, 'вкладка скинов'); await until(async () => (await px('#skf', 64, 32))[3] === 255, 3000, 'предпросмотр скина');
  assert.deepStrictEqual((await px('#skf', 64, 32)).slice(0, 3), C.red);
  const back = { 'голова сзади': [64, 32, C.dred], 'тело сзади': [64, 112, C.dblue], 'правая рука (справа)': [112, 112, C.dgreen], 'левая рука (слева)': [16, 112, C.dyellow], 'правая нога (справа)': [80, 208, C.dpurple], 'левая нога (слева)': [48, 208, C.dorange] };
  for (const [nm, [x, y, c]] of Object.entries(back)) assert.deepStrictEqual((await px('#skb', x, y)).slice(0, 3), c, 'сзади: ' + nm); ok('вид сзади: руки и ноги меняются местами правильно');
  assert((await txt('#skname')).includes('Мой герой')); assert((await txt('#skms')).includes('MsPlayer')); assert(!await page.isDisabled('#skup')); await shot('03-skins');
  assert.strictEqual((await page.$$('#sklib .sk')).length, 1); assert.deepStrictEqual((await px('#sklib canvas', 24, 24)).slice(0, 3), C.red); ok('библиотека: карточка скина с головой, вход Microsoft виден');
  dialogResult = { canceled: false, filePaths: [skinFile] };
  await page.click('#skmodel button[data-m="slim"]'); await until(async () => (await H('skins:list')).items[0].model === 'slim', 3000, 'модель'); await until(async () => !!await page.$('#skmodel button.on[data-m="slim"]'), 3000, 'кнопка «тонкие» подсвечена'); await page.click('#skmodel button[data-m="classic"]'); await until(async () => (await H('skins:list')).items[0].model === 'classic', 3000, 'модель назад'); ok('переключатель модели рук работает');
  await page.uncheck('#sksrv'); await until(async () => (await H('skins:list')).servers === false, 3000, 'галка'); await page.check('#sksrv'); await until(async () => (await H('skins:list')).servers === true, 3000, 'галка назад'); ok('галка «применять на серверах» сохраняется');
  await page.click('#skup'); await page.click('#my'); await until(() => seen.mojang && seen.mojang.auth === 'Bearer MSTOKEN', 3000, 'загрузка'); ok('кнопка загрузки в аккаунт спрашивает подтверждение и отправляет скин');
  await page.click('#skoff'); await until(async () => (await H('skins:list')).active === '', 3000, 'убран'); await until(async () => (await txt('#skname')).includes('не выбран'), 3000, 'подпись «не выбран»'); await page.click('#sklib button[data-a="sel"]'); await until(async () => (await H('skins:list')).active === sid, 3000, 'выбран'); ok('«убрать скин» и повторный выбор из библиотеки');
  await page.click('#sklib button[data-a="del"]'); await page.click('#my'); await until(async () => (await H('skins:list')).items.length === 0, 3000, 'удалён'); await until(async () => (await txt('#sklib')).includes('пока пусто'), 3000, 'пустая библиотека'); assert(!fs.existsSync(path.join(root, 'skins', sid + '.png'))); ok('удаление скина с подтверждением, файл стёрт');
  dialogResult = { canceled: false, filePaths: [skinFile] }; await page.click('#skpick'); await until(async () => (await H('skins:list')).items.length === 1, 3000, 'добавлен снова'); ok('«Загрузить PNG» из интерфейса');
  dialogResult = { canceled: false, filePaths: [bad] }; await page.click('#skpick'); await until(async () => (await txt('#toast')).includes('не PNG'), 3000, 'тост об ошибке'); ok('плохой файл: ошибка в уведомлении');

  await nav('Друзья'); await until(async () => (await txt('#flist')).includes('Boris'), 4000, 'друзья');
  await page.click('#flist .item:has-text("Boris") button[data-p]'); await until(async () => (await txt('#pfnick')).includes('Boris') && (await txt('#pfbio')).includes('Строю замок'), 4000, 'профиль друга');
  assert((await txt('#pfstat')).includes('В игре') && (await txt('#pfstat')).includes('mc.test.net')); assert((await txt('#pfmeta')).includes('02.03.2025')); assert(!await vis('#pfseg') && !await vis('#pfnum') && !await vis('#pfbc')); assert(await page.isVisible('#pfact button[data-pa="chat"]') && await page.isVisible('#pfact button[data-pa="inv"]') && await page.isVisible('#pfact button[data-pa="join"]') && await page.isVisible('#pfact button[data-pa="del"]'));
  // сплошной скин: поверх лица рисуется шапка, берём её пиксель
  await until(async () => (await px('#pfcv', 64, 32))[3] === 255, 3000, 'скин друга'); const fpx = await px('#pfcv', 64, 32); assert.deepStrictEqual(fpx.slice(0, 3), [...friendRgba.subarray((12 * 64 + 44) * 4, (12 * 64 + 44) * 4 + 3)]);
  await shot('04-profile-friend'); ok('профиль друга: ник, статус «в игре», дата, «о себе», его скин и кнопки действий');
  launches.length = 0; await page.click('#pfact button[data-pa="join"]'); await until(() => launches.length === 1, 4000, 'запуск к другу'); assert.strictEqual(launches[0].o.quickPlay.identifier, 'mc.test.net'); closeGame(); ok('«К другу» запускает игру сразу на сервере друга');
  await nav('Друзья'); await page.click('#flist .item:has-text("Boris") button[data-p]'); await until(async () => (await txt('#pfnick')).includes('Boris') && await vis('#pfact button[data-pa="chat"]'), 4000, 'снова профиль друга');
  await page.click('#pfact button[data-pa="chat"]'); await until(() => vis('#fchat'), 3000, 'чат'); assert((await txt('#fcn')).includes('Boris')); await page.click('#fprof'); await until(async () => (await txt('#pfnick')).includes('Boris'), 3000, 'из чата в профиль'); ok('«Написать» открывает чат, а в чате есть кнопка «Профиль»');
  await page.click('#pfact button[data-pa="back"]'); await until(() => vis('#flist'), 3000, 'назад'); await nav('Профиль'); await until(async () => (await txt('#pfnick')).includes('Anna'), 3000, 'своё после меню'); ok('«К друзьям» возвращает в список, пункт меню «Профиль» всегда открывает свой');
  await page.click('#pffr .f:has-text("Clara")'); await until(async () => (await txt('#pfnick')).includes('Clara'), 3000, 'профиль Clara'); assert((await txt('#pfstat')).includes('не в сети')); assert((await txt('#pfbio')).length <= 300); ok('клик по другу в сетке открывает его профиль; длинный текст обрезан до 300');
  profileMode = 'old'; Date.now = () => realNow() + 40000; // кэш профилей живёт 30 секунд: «проматываем» время
  await page.click('#pfact button[data-pa="back"]'); await page.click('#freq button[data-p]'); await until(async () => (await txt('#pfnick')).includes('Dan'), 4000, 'профиль заявки');
  assert((await txt('#pfbio')).includes('Hub пока не хранит профили')); assert((await txt('#pfstat')).includes('хочет добавить тебя в друзья')); assert(await vis('#pfact button[data-pa="acc"]') && !await vis('#pfact button[data-pa="chat"]')); await shot('05-request-old-hub'); ok('старый Hub без профилей: у заявки честная подпись и кнопки «Принять» / «Отклонить»');
  await page.click('#pfact button[data-pa="back"]'); await nav('Профиль'); await until(async () => (await txt('#pfnick')).includes('Anna'), 3000, 'своё'); await H('profile:bio', { bio: 'ещё раз' }); assert.strictEqual((await H('profile:get')).sync, false); await nav('Друзья'); await nav('Профиль'); await until(async () => (await txt('#pfnote')).includes('не умеет хранить профили'), 3000, 'заметка про старый Hub'); ok('в своём профиле подсказка: «о себе» и скин видишь только ты');
  assert.deepStrictEqual(pageErrors, []); ok('в интерфейсе нет ошибок JavaScript');
  await browser.close(); hubSrv.close(); mojang.close(); for (const r of sseClients) r.end(); for (const f of quits) f();
  console.log(`\nГотово: ${n} проверок прошли`); process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
