'use strict';
// Сквозная проверка 0.20: сохранённый вход и список друзей, правка/удаление сообщений и журнал, свой сервер, нечёткий поиск в интерфейсе.
// Настоящие main.js + index.html в Chromium; подменены Electron, Minecraft, Mojang, Fabric, Java и Hub (test/mock-hub.js).
// Запуск: NODE_PATH=$(npm root -g) node test/features.js   (нужен playwright с Chromium; SHOTS=папка сохранит скриншоты)
const fs = require('fs'), os = require('os'), path = require('path'), http = require('http'), net = require('net'), crypto = require('crypto'), assert = require('assert');
const EventEmitter = require('events'), Module = require('module');
let chromium; try { ({ chromium } = require('playwright')); } catch { console.log('playwright не найден: проверка пропущена'); process.exit(0); }
const { createMockHub } = require('./mock-hub');

const LAUNCHER = path.join(__dirname, '..'), tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'mna-feat-')), appData = path.join(tmp, 'appdata'), root = path.join(appData, '.mna');
fs.mkdirSync(root, { recursive: true });
let n = 0; const ok = s => { n++; console.log('  ✔', s); };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const until = async (fn, ms = 6000, what = '') => { const t = Date.now(); for (;;) { const v = await fn(); if (v) return v; if (Date.now() - t > ms) throw new Error('не дождались: ' + what); await sleep(30); } };
const exists = f => fs.existsSync(path.join(root, f)), read = f => fs.readFileSync(path.join(root, f), 'utf8');

// ---------- подмена Electron / Minecraft / Microsoft ----------
const handlers = new Map(), sent = [], quits = []; let pageSend = () => {}, encOk = true, quitCalled = 0, theWin = null;
class BW { constructor() { theWin = this; this.destroyed = false; this.webContents = { send: (ch, d) => { sent.push([ch, d]); pageSend(ch, d); }, focus() {}, isFocused: () => true }; } loadFile() {} on() {} isDestroyed() { return this.destroyed; } isFocused() { return true; } isMinimized() { return false; } show() {} setIcon() {} focus() {} restore() {} minimize() {} destroy() { this.destroyed = true; } }
const opened = [];
const electron = {
  app: { getPath: () => appData, getVersion: () => '0.20.0', setAppUserModelId() {}, requestSingleInstanceLock: () => true, whenReady: () => Promise.resolve(), on(ev, f) { if (ev === 'before-quit') quits.push(f); }, quit() { quitCalled++; } },
  BrowserWindow: BW, ipcMain: { handle: (ch, fn) => handlers.set(ch, fn) }, shell: { openPath(p) { opened.push(p); return Promise.resolve(''); }, showItemInFolder() {}, openExternal(u) { opened.push(u); } }, dialog: { showOpenDialog: async () => ({ canceled: true, filePaths: [] }) },
  safeStorage: { isEncryptionAvailable: () => encOk, encryptString: s => Buffer.from('ENC' + Buffer.from(s).toString('base64')), decryptString: b => { const t = String(b); if (!t.startsWith('ENC')) throw new Error('bad'); return Buffer.from(t.slice(3), 'base64').toString(); } },
  Tray: class { setToolTip() {} setContextMenu() {} on() {} destroy() {} }, Menu: { buildFromTemplate: x => x },
  nativeImage: { createFromPath: () => ({ isEmpty: () => true, resize() { return this; } }) }, Notification: class { static isSupported() { return false; } }
};
class MCClient extends EventEmitter { launch(o) { launches.push(o); return Promise.resolve({ pid: 1 }); } } const launches = [];
const origLoad = Module._load;
Module._load = function (req) {
  if (req === 'electron') return electron;
  if (req === 'minecraft-launcher-core') return { Client: MCClient, Authenticator: { getAuth: nick => ({ name: nick, access_token: 'x', uuid: 'u' }) } };
  if (req === 'msmc') return { Auth: class { async refresh() { throw new Error('нет сохранённого входа'); } async launch() { throw new Error('нет'); } } };
  return origLoad.apply(this, arguments);
};
// «Перезапуск»: сначала выходит прежний экземпляр (закрывает своё соединение с Hub), потом main.js читается заново
const loadMain = () => { quits.splice(0).forEach(f => f({ preventDefault() {} })); delete require.cache[require.resolve('../main.js')]; handlers.clear(); sent.length = 0; require('../main.js'); };

// ---------- подмена сети: Mojang, Fabric ----------
const JAR = Buffer.from('PK-fake-server-jar-' + 'x'.repeat(200)), SHA = crypto.createHash('sha1').update(JAR).digest('hex'), BAD_SHA = 'b'.repeat(40);
const net_ = { hits: [] };
const netSrv = http.createServer((q, r) => {
  const u = q.url, json = o => { r.writeHead(200, { 'Content-Type': 'application/json' }); r.end(JSON.stringify(o)); }; net_.hits.push(u);
  if (u === '/launchermeta.mojang.com/mc/game/version_manifest_v2.json') return json({ versions: [['1.21.1', 'good'], ['1.20.1', 'badsum'], ['1.2.4', 'old'], ['1.19.4', 'evil']].map(([id, k]) => ({ id, type: 'release', releaseTime: '2024-01-01T00:00:00Z', url: k === 'evil' ? 'https://evil.example.com/' + k + '.json' : 'https://piston-meta.mojang.com/v1/packages/' + k + '.json' })) });
  if (u === '/piston-meta.mojang.com/v1/packages/good.json') return json({ downloads: { server: { url: 'https://piston-data.mojang.com/v1/objects/' + SHA + '/server.jar', sha1: SHA, size: JAR.length } } });
  if (u === '/piston-meta.mojang.com/v1/packages/badsum.json') return json({ downloads: { server: { url: 'https://piston-data.mojang.com/v1/objects/' + SHA + '/server.jar', sha1: BAD_SHA, size: JAR.length } } });
  if (u === '/piston-meta.mojang.com/v1/packages/old.json') return json({ downloads: { client: {} } });
  if (u.startsWith('/piston-data.mojang.com/v1/objects/')) { r.writeHead(200); return r.end(JAR); }
  if (u.startsWith('/api.modrinth.com/v2/search')) { const q = new URL('http://x' + u.slice(u.indexOf('/v2'))).searchParams.get('query') || ''; const hits = q.toLowerCase() === 'sodium' ? [{ project_id: 'AANobbMI', title: 'Sodium', description: 'Rendering engine', downloads: 5000, icon_url: '' }] : []; return json({ total_hits: hits.length, hits }); }
  if (u === '/meta.fabricmc.net/v2/versions/loader/1.21.1') return json([{ loader: { version: '0.17.0-beta.1', stable: false } }, { loader: { version: '0.16.5', stable: true } }].reverse());
  if (u === '/meta.fabricmc.net/v2/versions/installer') return json([{ version: '1.0.1', stable: true }]);
  if (u === '/meta.fabricmc.net/v2/versions/loader/1.21.1/0.16.5/1.0.1/server/jar') { r.writeHead(200); return r.end(JAR); }
  r.writeHead(404); r.end('{}');
});
const MOCK_HOSTS = new Set(['api.modrinth.com', 'launchermeta.mojang.com', 'piston-meta.mojang.com', 'piston-data.mojang.com', 'meta.fabricmc.net']);
const realFetch = global.fetch;
global.fetch = (u, o = {}) => { try { const x = new URL(String(u)); if (MOCK_HOSTS.has(x.hostname)) return realFetch(`http://127.0.0.1:${netSrv.address().port}/${x.hostname}${x.pathname}${x.search}`, o); } catch {} return realFetch(u, o); };

(async () => {
  await new Promise(r => netSrv.listen(0, '127.0.0.1', r));
  let mock = createMockHub({ tier: 'admin', features: ['edit', 'journal'] }); const hubUrl = await mock.listen(), hubPort = +hubUrl.split(':').pop();
  const javaStub = path.join(tmp, 'java'); fs.writeFileSync(javaStub, '#!/bin/sh\necho "args: $@"\necho \'[12:00:00] [Server thread/INFO]: Done (0.5s)! For help, type "help"\'\nwhile read line; do echo "got: $line"; if [ "$line" = "stop" ]; then echo "Stopping"; exit 0; fi; done\n', { mode: 0o755 });
  fs.writeFileSync(path.join(root, 'config.json'), JSON.stringify({ hubUrl, java: javaStub, loader: 'vanilla', mc: '1.21.1', autover: false, onlaunch: 'none', featured: false, nick: 'Player', cfgv: 4 }));
  loadMain(); await sleep(100); assert(theWin && handlers.has('hub:msgedit') && handlers.has('srv:create') && handlers.has('hub:chatlog')); ok('main.js загружен, новые обработчики на месте');
  const H = async (ch, a) => handlers.get(ch)({}, a), snap = () => H('hub:snapshot'), ev = t => sent.filter(([c, d]) => c === 'hub:ev' && d.t === t).map(([, d]) => d.d);
  // после перезапуска фальшивого Hub старое keep-alive соединение может оборваться: один повтор, как сделал бы пользователь
  const login = async o => { try { return await H('hub:login', o); } catch (e) { if (!/недоступен/.test(e.message)) throw e; await sleep(300); return H('hub:login', o); } };
  const connected = () => until(async () => { const s = await snap(); return s.state.loggedIn && s.state.connected && s; }, 4000, 'вход и связь');

  console.log('Сохранённый вход');
  let s0 = await snap(); assert.deepStrictEqual(s0.saved, { nick: '', pass: false, remember: true, canSave: true }); ok('сначала ничего не сохранено, хранилище доступно');
  await assert.rejects(H('hub:login', { nick: 'Anna', password: 'wrong' }), /Неверный/); assert(!exists('hub-login.json') && !exists('hub-cred.bin')); ok('неверный пароль ничего не сохраняет');
  await H('hub:login', { nick: 'anna', password: 'secret12', remember: true }); await connected();
  assert.strictEqual(JSON.parse(read('hub-login.json')).nick, 'Anna'); assert(!/secret12/.test(read('hub-login.json'))); assert(exists('hub-cred.bin')); assert(!/secret12/.test(fs.readFileSync(path.join(root, 'hub-cred.bin'), 'latin1'))); assert(!/secret12/.test(fs.readFileSync(path.join(root, 'hub.bin'), 'latin1'))); ok('ник сохранён открыто (в каноническом виде), пароль только зашифрованным и нигде больше');
  s0 = await snap(); assert.deepStrictEqual(s0.saved, { nick: 'Anna', pass: true, remember: true, canSave: true }); ok('форма получает: ник, «пароль сохранён», флажок');
  await until(() => exists('friends-cache.json'), 3000, 'кэш друзей'); const fc = JSON.parse(read('friends-cache.json')); assert.strictEqual(fc.uid, 'u1'); assert.deepStrictEqual(fc.data.friends.map(f => f.nick), ['Boris', 'Clara']); assert(fc.data.friends.every(f => f.online === false && f.server === '')); ok('список друзей записан на диск (без статусов «в сети»)');
  await H('hub:logout'); assert(!exists('hub-cred.bin') && !exists('friends-cache.json') && !exists('hub.bin')); assert.deepStrictEqual(JSON.parse(read('hub-login.json')), { url: hubUrl, nick: 'Anna', remember: false }); assert.deepStrictEqual((await snap()).friends.friends, []); ok('«Выйти»: пароль, сессия и список друзей стёрты, ник остался для формы');
  s0 = await snap(); assert.deepStrictEqual(s0.saved, { nick: 'Anna', pass: false, remember: false, canSave: true }); ok('после выхода форма знает ник, но пароля нет');
  await H('hub:login', { nick: 'Anna', password: 'secret12', remember: false }); await connected(); assert(!exists('hub-cred.bin')); assert.strictEqual((await snap()).saved.remember, false); ok('«Запомнить меня» выключен: пароль не сохраняется');
  await H('hub:logout'); encOk = false; await H('hub:login', { nick: 'Anna', password: 'secret12', remember: true }); await connected(); assert(!exists('hub-cred.bin')); assert.strictEqual((await snap()).saved.canSave, false); assert.strictEqual(JSON.parse(read('hub-login.json')).nick, 'Anna'); ok('нет защищённого хранилища: пароль не пишется вообще, ник сохраняется');
  await H('hub:logout'); encOk = true;
  await assert.rejects(H('hub:login', { nick: 'Anna', password: '' }), /Неверный/); ok('пустой пароль без сохранённого не проходит');

  // ---- свежий вход с запоминанием, затем «перезапуск» лаунчера при недоступном Hub ----
  await H('hub:login', { nick: 'Anna', password: 'secret12', remember: true }); await connected(); await until(() => exists('friends-cache.json'), 3000, 'кэш друзей');
  await mock.close(); await sleep(50);
  loadMain(); await sleep(150);
  const cold = await snap(); assert.strictEqual(cold.state.loggedIn, true); assert.strictEqual(cold.state.connected, false); assert.strictEqual(cold.friends.cached, true); assert.deepStrictEqual(cold.friends.friends.map(f => f.nick), ['Boris', 'Clara']); assert(cold.friends.friends.every(f => !f.online)); ok('перезапуск без связи с Hub: вход и список друзей на месте, помечены как сохранённые');
  mock = createMockHub({ tier: 'admin', features: ['edit', 'journal'] }); await mock.listen(hubPort);
  const warm = await until(async () => { const s = await snap(); return s.state.connected && !s.friends.cached && s; }, 15000, 'автовход после возвращения Hub'); assert.strictEqual(warm.state.user.nick, 'Anna'); assert.deepStrictEqual(warm.friends.friends.map(f => f.nick), ['Boris', 'Clara']); ok('Hub вернулся с пустой базой токенов: лаунчер вошёл сам по сохранённому паролю и обновил друзей');

  console.log('Потеря сессии');
  const evAfter = (t, from) => sent.slice(from).filter(([c, d]) => c === 'hub:ev' && d.t === t).map(([, d]) => d.d);
  const drop = () => { mock.st.tokens.clear(); for (const r of mock.st.events) r.end(); }; // сервер «забыл» все сессии и оборвал соединение
  const live = () => mock.st.events.size === 1 && mock.st.tokens.size === 1;
  await until(live, 4000, 'исходное соединение');
  let from = sent.length; drop(); await until(async () => live() && evAfter('lost', from).length && (await snap()).state.connected, 15000, 'повторный вход');
  assert(evAfter('lost', from).every(d => d.auto === true && !d.badpass)); ok('токен отозван на сервере: лаунчер сам входит заново по сохранённому паролю, в интерфейсе только короткое уведомление');
  const oldPass = mock.st.password; mock.st.password = 'new-pass-1'; from = sent.length; drop();
  await until(() => evAfter('lost', from).some(d => d.badpass), 15000, 'сообщение о смене пароля'); assert(!exists('hub-cred.bin')); assert.strictEqual((await snap()).saved.pass, false); assert.strictEqual((await snap()).state.loggedIn, false); assert.strictEqual(mock.st.events.size, 0); ok('пароль сменили на другом устройстве: сохранённый пароль забыт, в интерфейсе понятное сообщение');
  mock.st.password = oldPass; await H('hub:login', { nick: 'Anna', password: oldPass, remember: true }); await connected(); assert(exists('hub-cred.bin')); await until(live, 4000, 'соединение после входа');
  const loginsBefore = mock.st.calls.filter(c => c === 'POST /api/login').length; mock.st.failLogin = 1; from = sent.length; drop();
  await until(() => mock.st.calls.filter(c => c === 'POST /api/login').length > loginsBefore, 8000, 'попытка входа'); await sleep(200); assert(exists('hub-cred.bin')); assert(evAfter('lost', from).length > 0 && evAfter('lost', from).every(d => !d.badpass)); ok('Hub отвечает ошибкой 503: пароль не стирается, лаунчер повторит позже');
  mock.st.failLogin = 0; await H('hub:login', { nick: 'Anna', password: oldPass, remember: true }); await connected(); await until(live, 4000, 'соединение');
  const pw = await H('hub:password', { old: oldPass, new: 'secret12' }); assert(pw !== undefined); const cr = JSON.parse(Buffer.from(fs.readFileSync(path.join(root, 'hub-cred.bin'), 'latin1').slice(3), 'base64').toString()); assert.strictEqual(cr.password, 'secret12'); ok('смена пароля обновляет и сохранённый');

  console.log('Сообщения: правка, удаление, журнал');
  let sn = await snap(); assert.deepStrictEqual(sn.caps, { edit: true, journal: true }); ok('Hub сообщил, что умеет правку и журнал');
  const m1 = (await H('hub:send', { id: 'f1', text: 'привет' })).message;
  const e1 = await H('hub:msgedit', { scope: 'friend', id: 'f1', mid: m1.id, text: '  привет, Борис  ' }); assert.strictEqual(e1.message.text, 'привет, Борис'); assert(e1.message.edited > 0); assert.strictEqual(mock.st.dm.f1[0].text, 'привет, Борис'); await until(() => ev('message_edit').some(d => d.id === m1.id), 2000, 'событие правки'); ok('личное сообщение изменено, сервер и событие в интерфейс получили новый текст');
  await assert.rejects(H('hub:msgedit', { scope: 'friend', id: 'f1', mid: m1.id, text: '   ' }), /пустым/); await assert.rejects(H('hub:msgedit', { scope: 'friend', id: 'f1', mid: '' , text: 'x' }), /Не выбрано/); await assert.rejects(H('hub:msgedit', { scope: 'friend', id: '', mid: 'm1', text: 'x' }), /Не выбрано/); await assert.rejects(H('hub:msgedit', { scope: 'friend', id: 'f1', mid: 'nope', text: 'x' }), /не найдено/); ok('пустой текст, нет сообщения и чужой id: понятные ошибки');
  const long = await H('hub:msgedit', { scope: 'friend', id: 'f1', mid: m1.id, text: 'я'.repeat(900) }); assert.strictEqual(long.message.text.length, 500); ok('длина правки ограничена теми же 500 знаками');
  assert.strictEqual((await H('hub:msgdel', { scope: 'friend', id: 'f1', mid: m1.id })).ok, true); assert.deepStrictEqual(mock.st.dm.f1, []); await until(() => ev('message_del').some(d => d.id === m1.id), 2000, 'событие удаления'); ok('личное сообщение удалено у всех');
  const g1 = (await H('hub:roomsend', { kind: 'global', text: 'всем привет' })).message, g2 = mock.addForeign('чужое сообщение');
  await H('hub:msgedit', { scope: 'global', mid: g1.id, text: 'всем привет, поправил' }); await until(() => ev('room_edit').some(d => d.msg.id === g1.id && d.msg.text === 'всем привет, поправил'), 2000, 'room_edit');
  await H('hub:msgdel', { scope: 'global', mid: g1.id }); await until(() => ev('room_del').some(d => d.id === g1.id), 2000, 'room_del');
  await H('hub:msgdel', { scope: 'global', mid: g2.id }); ok('глобальный чат: правка, удаление своего и (как админ) чужого сообщения');
  const lg = await H('hub:chatlog', {}); const kinds = lg.entries.map(e => e.kind + ':' + e.text); assert.deepStrictEqual(kinds, ['delete:чужое сообщение', 'delete:всем привет, поправил', 'edit:всем привет, поправил', 'send:чужое сообщение', 'send:всем привет']); assert.strictEqual(lg.entries[2].old, 'всем привет'); assert.strictEqual(lg.entries[1].by.nick, 'Anna'); assert.strictEqual(lg.more, false); ok('журнал сохранил всё: что написано, что и как изменено, что удалено (и кем), хотя в чате этих сообщений уже нет');
  assert.deepStrictEqual((await H('hub:chatlog', { kind: 'edit' })).entries.map(e => e.kind), ['edit']); const pg = await H('hub:chatlog', { limit: 2 }); assert.strictEqual(pg.entries.length, 2); assert.strictEqual(pg.more, true); const pg2 = await H('hub:chatlog', { limit: 2, before: pg.entries[1].id }); assert.strictEqual(pg2.entries.length, 2); assert(pg2.entries[0].id < pg.entries[1].id); ok('журнал: фильтр по виду записи и постраничная загрузка');
  const dmLogged = mock.st.log.some(e => /привет, Борис|яяя/.test(e.text)); assert.strictEqual(dmLogged, false); ok('личные сообщения в журнал не попадают');
  mock.st.tier = 'pro'; await H('hub:logout'); await H('hub:login', { nick: 'Anna', password: 'secret12', remember: true }); await connected(); await assert.rejects(H('hub:chatlog', {}), /только администратору/); ok('обычному игроку журнал не отдаётся (и лаунчер не спрашивает)');
  const calls0 = mock.st.calls.length; await H('hub:chatlog', {}).catch(() => {}); assert(!mock.st.calls.slice(calls0).some(c => c.includes('chatlog'))); mock.st.tier = 'admin';
  // старый Hub
  await H('hub:logout'); await mock.close(); mock = createMockHub({ tier: 'pro' }); await mock.listen(hubPort); await login({ nick: 'Anna', password: 'secret12', remember: false }); await connected();
  const old = (await H('hub:send', { id: 'f1', text: 'старый hub' })).message; await assert.rejects(H('hub:msgedit', { scope: 'friend', id: 'f1', mid: old.id, text: 'x' }), /не умеет изменять и удалять/); assert.strictEqual((await snap()).caps.edit, false); await assert.rejects(H('hub:msgdel', { scope: 'friend', id: 'f1', mid: old.id }), /не умеет/); ok('старый Hub (ответ 404 без текста): честное сообщение и кнопки больше не показываются');
  await H('hub:logout'); await mock.close(); mock = createMockHub({ tier: 'admin', features: ['edit', 'journal'] }); await mock.listen(hubPort); await login({ nick: 'Anna', password: 'secret12', remember: true }); await connected();

  console.log('Профиль: повторная отправка');
  const posts = () => mock.st.calls.filter(c => c === 'POST /api/profile').length, p0 = posts(); mock.st.failProfile = 1;
  await H('profile:bio', { bio: 'Привет из теста' }); assert.strictEqual(posts() - p0, 1);
  await until(() => posts() - p0 >= 2, 7000, 'повторная отправка профиля'); await sleep(300); assert.strictEqual(posts() - p0, 2); ok('Hub мигнул (503): «о себе» и скин отправляются повторно и больше не дублируются');
  mock.st.failProfile = 1; await H('profile:bio', { bio: 'Ещё раз' }); await H('hub:logout'); await sleep(2600); assert.strictEqual(posts() - p0, 3); mock.st.failProfile = 0; ok('после выхода повторы прекращаются');
  await login({ nick: 'Anna', password: 'secret12', remember: true }); await connected();
  mock.st.profiles.length = 0; mock.st.slowProfile = 500; const pa = H('profile:bio', { bio: 'Первое' }); await sleep(50); const pb = H('profile:bio', { bio: 'Второе' }); await Promise.all([pa, pb]);
  assert.deepStrictEqual(mock.st.profiles.map(x => x.bio), ['Первое', 'Второе']); ok('две быстрые правки «о себе» уходят в Hub по очереди: старая не затрёт новую, даже если Hub ответил медленно');

  console.log('Свой сервер');
  const listPort = async () => { const s = net.createServer(); await new Promise(r => s.listen(0, '0.0.0.0', r)); const p = s.address().port; await new Promise(r => s.close(r)); return p; };
  const port1 = await listPort(), srvPath = id => path.join(root, 'servers', id);
  const mk = o => H('srv:create', { name: 'Мой тестовый', mc: '1.21.1', type: 'vanilla', ram: 2048, port: port1, motd: 'Привет, мир', maxPlayers: 6, onlineMode: false, eula: true, ...o });
  await assert.rejects(mk({ eula: false }), /EULA/); await assert.rejects(mk({ eula: 'true' }), /EULA/); await assert.rejects(mk({ name: '  \u0000 ' }), /название/); await assert.rejects(mk({ mc: '../../x' }), /версию/); await assert.rejects(mk({ port: 80 }), /Порт/); await assert.rejects(mk({ port: 'abc' }), /Порт/);
  assert(!exists('servers') || fs.readdirSync(path.join(root, 'servers')).length === 0); ok('без согласия с EULA, с пустым названием, плохой версией или портом сервер не создаётся и папок не остаётся');
  await assert.rejects(mk({ mc: '1.20.1' }), /повреждён|контрольная/); assert.strictEqual(fs.readdirSync(path.join(root, 'servers')).length, 0); await assert.rejects(mk({ mc: '1.2.4' }), /нет серверной сборки/); await assert.rejects(mk({ mc: '1.19.4' }), /не найдена/); await assert.rejects(mk({ mc: '1.99' }), /не найдена/); assert.strictEqual(fs.readdirSync(path.join(root, 'servers')).length, 0); ok('подменённый (не сошлась сумма) jar, версия без сервера, чужой адрес и неизвестная версия: отказ и чистая папка');
  const sv = await mk({}); assert.strictEqual(sv.name, 'Мой тестовый'); assert.strictEqual(sv.type, 'vanilla'); assert.strictEqual(sv.state, 'stopped'); assert.strictEqual(sv.props.motd, 'Привет, мир'); assert.strictEqual(sv.props['online-mode'], 'false'); assert.strictEqual(sv.props['max-players'], '6'); assert.strictEqual(sv.port, port1);
  const dir = srvPath(sv.id); assert(/^server-[a-z0-9]{4}$/.test(sv.id)); assert(fs.readFileSync(path.join(dir, 'server.jar')).equals(JAR)); assert(/eula=true/.test(fs.readFileSync(path.join(dir, 'eula.txt'), 'utf8'))); assert(!/[^\x00-\x7f]/.test(fs.readFileSync(path.join(dir, 'server.properties'), 'utf8'))); assert(!fs.existsSync(path.join(dir, 'server.jar.part'))); ok('сервер создан: jar проверен по sha1, eula.txt, server.properties целиком в ASCII, русский MOTD читается обратно');
  await assert.rejects(mk({ name: 'Второй' }), /уже занят другим/); const port2 = await listPort(); const fb = await mk({ name: 'Fabric one', type: 'fabric', port: port2, onlineMode: true }); assert.strictEqual(fb.type, 'fabric'); assert(fs.readFileSync(path.join(srvPath(fb.id), 'server.jar')).equals(JAR)); assert(net_.hits.includes('/meta.fabricmc.net/v2/versions/loader/1.21.1/0.16.5/1.0.1/server/jar')); assert.strictEqual(fb.props['online-mode'], 'true'); ok('второй сервер с тем же портом отклонён; Fabric берёт стабильные версии загрузчика и установщика');
  const lst = await H('srv:list'); assert.deepStrictEqual(lst.servers.map(x => x.name).sort(), ['Fabric one', 'Мой тестовый']); assert(Array.isArray(lst.lan) && lst.maxRam >= 1024 && lst.busy === false); ok('список серверов: оба на месте, адреса сети и предел памяти приходят');
  for (const bad of ['../x', '..', '/etc', 'a/b', '', 'SERVER']) { await assert.rejects(H('srv:start', { id: bad }), /нет/); await assert.rejects(H('srv:delete', { id: bad }), /нет/); await assert.rejects(H('srv:folder', { id: bad }), /нет/); } ok('чужие id и «../» не пускаются ни в запуск, ни в удаление, ни в папку');
  const st = id => sent.filter(([c, d]) => c === 'srv:state' && d.id === id).map(([, d]) => d.state);
  const started = await H('srv:start', { id: sv.id }); assert.strictEqual(started.id, sv.id); await until(() => st(sv.id).includes('running'), 5000, 'сервер запущен'); assert.deepStrictEqual(st(sv.id).slice(0, 2), ['starting', 'running']);
  const log1 = await H('srv:log', { id: sv.id }); assert(log1.some(l => l.includes('-Xmx2048M -jar server.jar nogui')) && log1.some(l => /Done \(0\.5s\)/.test(l))); ok('запуск: Java получила параметры, строка Done переводит сервер в «работает»');
  await assert.rejects(H('srv:start', { id: sv.id }), /уже запущен/); await assert.rejects(H('srv:delete', { id: sv.id }), /Останови/); await assert.rejects(H('srv:setprops', { id: sv.id, changes: { pvp: false } }), /Останови/); await assert.rejects(H('srv:ram', { id: sv.id, ram: 4096 }), /Останови/); ok('работающий сервер нельзя запустить второй раз, удалить или перенастроить');
  assert.strictEqual(await H('srv:cmd', { id: sv.id, text: '/say привет\nstop' }), true); await until(async () => (await H('srv:log', { id: sv.id })).some(l => l === 'got: say привет stop'), 3000, 'эхо команды'); assert(!st(sv.id).includes('stopping')); assert.strictEqual(await H('srv:cmd', { id: sv.id, text: '   ' }), false); assert.strictEqual(await H('srv:cmd', { id: fb.id, text: 'list' }), false); ok('команды доходят до консоли; перевод строки не превращает её в две команды, пустая и для чужого сервера отклоняются');
  assert.strictEqual(await H('srv:stop', { id: sv.id }), true); await until(() => st(sv.id).includes('stopped'), 5000, 'остановка'); assert.deepStrictEqual(st(sv.id).slice(-2), ['stopping', 'stopped']); assert.strictEqual((await H('srv:list')).servers.find(x => x.id === sv.id).state, 'stopped'); assert.strictEqual(await H('srv:stop', { id: sv.id }), false); ok('остановка: сервер получил «stop», завершился, состояние вернулось');
  const blocker = net.createServer(); await new Promise(r => blocker.listen(port1, '0.0.0.0', r)); await assert.rejects(H('srv:start', { id: sv.id }), /Порт \d+ занят/); await new Promise(r => blocker.close(r)); assert(!(await H('srv:list')).servers.find(x => x.id === sv.id).state.match(/start|run/)); ok('порт занят другой программой: понятная ошибка, сервер не «зависает» в состоянии запуска');
  const up = await H('srv:setprops', { id: sv.id, changes: { motd: 'Новый мир ёж', 'max-players': '20', gamemode: 'creative', difficulty: 'hard', pvp: false, 'online-mode': true, 'view-distance': 8 } }); assert.strictEqual(up.props.motd, 'Новый мир ёж'); assert.strictEqual(up.props['max-players'], '20'); assert.strictEqual(up.props.pvp, 'false'); assert(/motd=\\u041d/.test(fs.readFileSync(path.join(dir, 'server.properties'), 'utf8')));
  await assert.rejects(H('srv:setprops', { id: sv.id, changes: { gamemode: 'god' } }), /Режим/); await assert.rejects(H('srv:setprops', { id: sv.id, changes: { 'rcon.password': '1' } }), /нельзя/); await assert.rejects(H('srv:setprops', { id: sv.id, changes: { 'server-port': port2 } }), /уже занят/); const np = await listPort(); const up2 = await H('srv:setprops', { id: sv.id, changes: { 'server-port': np } }); assert.strictEqual(up2.port, np); assert.strictEqual(up2.props['server-port'], String(np)); assert.strictEqual(JSON.parse(fs.readFileSync(path.join(dir, 'server.json'), 'utf8')).port, np); assert.strictEqual((await H('srv:ram', { id: sv.id, ram: 4096 })).ram, Math.min(4096, (await H('srv:list')).maxRam)); ok('настройки: сохраняются, проверяются, нельзя трогать rcon, порт согласуется между файлами, память меняется');
  await H('srv:folder', { id: sv.id }); assert.strictEqual(opened.pop(), dir); await H('srv:eula'); assert.strictEqual(opened.pop(), 'https://aka.ms/MinecraftEULA'); ok('«Папка» открывает именно папку сервера, EULA открывается по официальной ссылке');
  await H('srv:start', { id: sv.id }); await until(() => st(sv.id).filter(x => x === 'running').length === 2, 5000, 'второй запуск'); quits.forEach(f => f({ preventDefault() {} })); await until(() => quitCalled > 0, 8000, 'выход из лаунчера'); assert.strictEqual((await H('srv:list')).servers.find(x => x.id === sv.id).state, 'stopped'); ok('закрытие лаунчера сначала останавливает запущенные серверы (мир сохраняется), потом выходит');
  assert.strictEqual(await H('srv:delete', { id: sv.id }), true); assert(!fs.existsSync(dir)); assert(fs.existsSync(srvPath(fb.id))); assert.strictEqual((await H('srv:list')).servers.length, 1); ok('удаление убирает только папку этого сервера');
  await H('srv:delete', { id: fb.id });


  console.log('Поиск в каталоге');
  await H('cfg:set', { repo: 'modrinth' });
  const found = await H('mods:search', { q: 'ыщвшгь', type: 'mod', sort: 'relevance', offset: 0 }); assert.strictEqual(found.hits[0].title, 'Sodium'); assert.strictEqual(found.fixed, 'sodium'); ok('запрос набран в русской раскладке: каталог сам повторяет его в английской и сообщает об этом');
  const direct = await H('mods:search', { q: 'sodium', type: 'mod', sort: 'relevance', offset: 0 }); assert.strictEqual(direct.hits[0].title, 'Sodium'); assert.strictEqual(direct.fixed, undefined); const none = await H('mods:search', { q: 'zzzzzz', type: 'mod', sort: 'relevance', offset: 0 }); assert.strictEqual(none.hits.length, 0); assert.strictEqual(none.fixed, undefined); ok('обычный запрос и запрос без результатов подсказки не вызывают');

  // ================= интерфейс =================
  console.log('Интерфейс');
  const EIGHT = ['Boris', 'Clara', 'Daria', 'Egor', 'Fedor', 'Galina', 'Ivan', 'Kira'].map((nick, i) => ({ id: 'f' + (i + 1), nick, online: i % 2 === 0, state: i === 0 ? 'ingame' : 'online', server: i === 0 ? 'mc.test.net' : '', unread: 0, style: null, tier: i === 0 ? 'plus' : '' }));
  const newMock = async tier => { const m = createMockHub({ tier: tier || 'admin', features: ['edit', 'journal'], friends: EIGHT }); await m.listen(hubPort); return m; };
  await until(() => exists('friends-cache.json'), 3000, 'кэш друзей'); await mock.close(); fs.rmSync(path.join(root, 'hub.bin'), { force: true });
  loadMain(); await sleep(200);
  const browser = await chromium.launch(), page = await browser.newPage({ viewport: { width: 1180, height: 760 } });
  const pageErrors = []; page.on('pageerror', e => pageErrors.push(e.message));
  await page.exposeFunction('__invoke', async (ch, d) => { const h = handlers.get(ch); if (!h) throw new Error('нет обработчика ' + ch); return h({}, d); });
  await page.addInitScript(() => { window.__l = {}; window.mna = { invoke: (c, d) => window.__invoke(c, d), on: (c, f) => { (window.__l[c] = window.__l[c] || []).push(f); }, pathFor: () => '' }; });
  pageSend = (ch, d) => page.evaluate(([c, x]) => (window.__l[c] || []).forEach(f => f(x)), [ch, d]).catch(() => {});
  const shot = async nm => { if (process.env.SHOTS) { fs.mkdirSync(process.env.SHOTS, { recursive: true }); await page.screenshot({ path: path.join(process.env.SHOTS, nm + '.png') }); } };
  const vis = sel => page.isVisible(sel), txt = sel => page.textContent(sel), nav = t => page.click(`nav button:has-text("${t}")`), count = sel => page.$$(sel).then(a => a.length);
  const hover = sel => page.hover(sel), val = sel => page.inputValue(sel);
  const modalOk = async (text, set) => { await until(() => vis('#modal'), 3000, 'окно'); if (text) assert((await txt('#mt')).includes(text), 'в окне: ' + (await txt('#mt'))); if (set != null) await page.fill('#mi', set); await page.click('#my'); await until(async () => !await vis('#modal'), 3000, 'окно закрылось'); };
  const open = async () => { await page.goto('file://' + path.join(LAUNCHER, 'index.html')); await until(async () => (await txt('#nav')).includes('Друзья'), 4000, 'меню'); };

  // --- форма входа: ник и пароль уже сохранены, Hub пока недоступен, но друзья видны ---
  await open(); await nav('Друзья'); await until(() => vis('#fgate'), 4000, 'форма входа');
  assert.strictEqual(await val('#fnick'), 'Anna'); assert((await page.getAttribute('#fpass', 'placeholder')).includes('сохранён')); assert.strictEqual(await val('#fpass'), ''); assert(await page.isChecked('#frem')); assert((await txt('#fremh')).includes('зашифрованном')); ok('форма входа: ник подставлен, «пароль сохранён», «запомнить меня» включено');
  await until(() => vis('#fsaved'), 3000, 'сохранённые друзья'); assert((await txt('#fsavedl')).includes('Boris') && (await txt('#fsavedl')).includes('Clara')); assert.strictEqual(await vis('#fmain'), false); await shot('09-login-saved'); ok('без входа и без связи под формой видны сохранённые друзья');
  await page.click('#flogin'); await until(async () => (await txt('#ferr')).includes('недоступен'), 5000, 'ошибка связи'); ok('пустой пароль берёт сохранённый; пока Hub недоступен, показана ошибка связи');
  mock = await newMock('admin'); await sleep(300);
  for (let i = 0; i < 20 && !await vis('#fmain'); i++) { await page.click('#flogin').catch(() => {}); await sleep(400); }
  await until(() => vis('#fmain'), 5000, 'вход'); await until(async () => (await count('#flist .item.fr')) === 8, 4000, '8 друзей'); assert((await txt('#who')).includes('Anna')); ok('Hub вернулся: вход по сохранённому паролю без ввода, видны все 8 друзей');

  // --- поиск друга с опечатками и в другой раскладке ---
  assert(await vis('#fq')); await page.fill('#fq', 'galna'); await until(async () => (await count('#flist .item.fr')) === 1, 2000, 'фильтр'); assert((await txt('#flist')).includes('Galina'));
  await page.fill('#fq', 'пфдштф'); await until(async () => (await count('#flist .item.fr')) === 1 && (await txt('#flist')).includes('Galina'), 2000, 'раскладка'); await page.fill('#fq', 'zzzzzz'); await until(async () => (await count('#flist .item.fr')) === 0, 2000, 'пусто'); await page.fill('#fq', ''); await until(async () => (await count('#flist .item.fr')) === 8, 2000, 'все'); ok('поиск друга: «galna» и «пфдштф» находят Galina, мусор ничего, пустое поле возвращает всех');

  // --- чат: правка и удаление ---
  mock.st.dm.f1 = [{ id: 'mx', from: 'f1', to: 'u1', nick: 'Boris', text: 'привет от Бориса', ts: Date.now() - 60000, type: 'text' }];
  await page.click('#flist .item.fr:has-text("Boris") button:has-text("Чат")'); await until(async () => (await txt('#fmsgs')).includes('привет от Бориса'), 4000, 'чат'); assert.strictEqual(await count('#fmsgs [data-me], #fmsgs [data-md]'), 0); ok('чужое сообщение: кнопок «Изменить» и «Удалить» нет');
  await page.fill('#fmsg', 'моё сообщение'); await page.click('#fsend'); await until(() => page.$('#fmsgs .msg.me .bub'), 3000, 'своё сообщение'); assert.strictEqual(await vis('#fmsgs .msg.me [data-me]'), false); await hover('#fmsgs .msg.me .bub'); assert(await vis('#fmsgs .msg.me [data-me]')); assert(await vis('#fmsgs .msg.me [data-md]')); ok('у своего сообщения при наведении появляются «Изменить» и «Удалить»');
  await page.click('#fmsgs .msg.me [data-me]'); await until(() => vis('#modal'), 3000, 'окно правки'); assert.strictEqual(await val('#mi'), 'моё сообщение'); await modalOk('Изменить', 'моё сообщение, исправлено');
  await until(async () => (await txt('#fmsgs .msg.me .bub')).includes('исправлено') && (await txt('#fmsgs .msg.me .bub')).includes('изменено'), 3000, 'правка видна'); assert.strictEqual(mock.st.dm.f1.find(m => m.from === 'u1').text, 'моё сообщение, исправлено'); await shot('06-chat-edit'); ok('правка: окно с текущим текстом, новый текст и пометка «изменено» в чате и на сервере');
  const mine = mock.st.dm.f1.find(m => m.from === 'u1'); mock.sse('message_edit', { ...mine, text: 'правка с другого устройства', edited: Date.now() }); await until(async () => (await txt('#fmsgs .msg.me .bub')).includes('с другого устройства'), 3000, 'правка с другого устройства'); ok('правка с другого устройства приходит в открытый чат сама');
  await hover('#fmsgs .msg.me .bub'); await page.click('#fmsgs .msg.me [data-md]'); await modalOk('Удалить'); await until(async () => (await count('#fmsgs .msg.me')) === 0, 3000, 'удалено'); assert.strictEqual(mock.st.dm.f1.some(m => m.from === 'u1'), false); ok('удаление: подтверждение, сообщение пропадает в чате и на сервере');
  await page.fill('#fmsg', 'второе'); await page.click('#fsend'); await until(() => page.$('#fmsgs .msg.me .bub'), 3000, 'второе'); const second = mock.st.dm.f1.find(m => m.from === 'u1'); mock.sse('message_del', { id: second.id, from: 'u1', to: 'f1' }); await until(async () => (await count('#fmsgs .msg.me')) === 0, 3000, 'удалено извне'); ok('удаление с другого устройства тоже убирает сообщение из открытого чата');
  await page.click('#fback'); await until(() => vis('#flist'), 3000, 'назад');

  // --- глобальный чат и журнал ---
  await page.click('#fseg button[data-k="global"]'); await until(() => vis('#rchat'), 3000, 'глобальный чат'); assert((await txt('#rnote')).includes('журнал')); assert(await vis('#rnote')); assert(await vis('#rlogb')); ok('в глобальном чате пользователь видит, что ведётся журнал; админ видит кнопку «Журнал»');
  const foreign = mock.addForeign('чужое сообщение'); mock.sse('room', { kind: 'global', msg: foreign }); await until(async () => (await txt('#rmsgs')).includes('чужое сообщение'), 3000, 'чужое в глобальном');
  await hover('#rmsgs .msg:not(.me) .bub'); assert(await vis('#rmsgs .msg:not(.me) [data-md]')); assert.strictEqual(await count('#rmsgs .msg:not(.me) [data-me]'), 0); ok('админ может удалить чужое сообщение, но не может «изменить» его');
  await page.fill('#rmsg', 'привет всем'); await page.click('#rsend'); await until(() => page.$('#rmsgs .msg.me .bub'), 3000, 'своё глобальное'); await hover('#rmsgs .msg.me .bub'); await page.click('#rmsgs .msg.me [data-me]'); await modalOk('Изменить', 'привет всем, это я');
  await until(async () => (await txt('#rmsgs .msg.me .bub')).includes('изменено'), 3000, 'правка в глобальном'); await hover('#rmsgs .msg:not(.me) .bub'); await page.click('#rmsgs .msg:not(.me) [data-md]'); await modalOk('журнале'); await until(async () => !(await txt('#rmsgs')).includes('чужое сообщение'), 3000, 'удалено админом'); ok('глобальный чат: правка своего, удаление чужого админом (в окне подтверждения сказано про журнал)');
  await page.click('#rlogb'); await until(() => vis('#rlog'), 3000, 'журнал'); assert.strictEqual(await vis('#rview'), false); await until(async () => (await count('#rlogl .lgrow')) >= 4, 3000, 'записи'); const rows = await txt('#rlogl'); assert(rows.includes('написал') && rows.includes('изменил') && rows.includes('удалил') && rows.includes('чужое сообщение') && rows.includes('привет всем, это я') && rows.includes('привет всем')); await shot('07-journal'); ok('журнал админа: написано, изменено (было и стало), удалено, в том числе то, чего в чате уже нет');
  await page.click('#rlk .chip[data-k="edit"]'); await until(async () => (await count('#rlogl .lgrow')) === 1, 3000, 'фильтр «изменено»'); assert((await txt('#rlogl')).includes('изменил')); await page.click('#rlk .chip[data-k=""]'); await until(async () => (await count('#rlogl .lgrow')) >= 4, 3000, 'все записи');
  await page.fill('#rlq', 'чужое сообщние'); await until(async () => (await count('#rlogl .lgrow')) >= 1 && (await count('#rlogl .lgrow')) <= 2 && (await txt('#rlogl')).includes('чужое'), 2000, 'поиск по журналу с опечаткой'); assert(!(await txt('#rlogl')).includes('привет всем')); await page.fill('#rlq', ''); ok('журнал: фильтр по виду записи и поиск с опечатками');
  await page.click('#rlback'); await until(() => vis('#rview'), 3000, 'назад в чат'); assert.strictEqual(await vis('#rlog'), false);
  await page.click('#fseg button[data-k="local"]'); await until(async () => (await txt('#rtitle')).includes('Локальный'), 3000, 'локальный'); assert.strictEqual(await vis('#rnote'), false); assert.strictEqual(await vis('#rlogb'), false); ok('в локальном чате заметки про журнал и кнопки «Журнал» нет');
  await page.click('#fseg button[data-k="global"]'); await until(async () => (await txt('#rtitle')).includes('Глобальный'), 3000, 'глобальный снова');

  // --- обычный игрок: журнала нет, чужое удалить нельзя ---
  mock.st.tier = 'pro'; await H('hub:logout'); await mock.close(); mock = await newMock('pro'); await sleep(200); await login({ nick: 'Anna', password: 'secret12', remember: true }); await connected();
  mock.addForeign('второе чужое'); await page.click('#fseg button[data-k="friends"]'); await page.click('#fseg button[data-k="global"]'); await until(async () => (await txt('#rmsgs')).includes('второе чужое'), 4000, 'сообщения обычного игрока');
  assert.strictEqual(await vis('#rlogb'), false); assert(await vis('#rnote')); await hover('#rmsgs .msg:not(.me) .bub'); assert.strictEqual(await count('#rmsgs .msg:not(.me) [data-md]'), 0); ok('обычный игрок: кнопки «Журнал» нет, чужие сообщения удалить нельзя, а предупреждение про журнал видит');
  await page.click('#rmsg'); await page.fill('#rmsg', 'своё у обычного'); await page.click('#rsend'); await until(() => page.$('#rmsgs .msg.me .bub'), 3000, 'своё'); await hover('#rmsgs .msg.me .bub'); assert(await vis('#rmsgs .msg.me [data-me]'));
  pageSend('hub:ev', { t: 'caps', d: { edit: false, journal: false } }); await until(async () => (await count('#rmsgs [data-me], #rmsgs [data-md]')) === 0, 3000, 'кнопки скрыты'); ok('если Hub не умеет правку (старый), кнопки скрываются');
  pageSend('hub:ev', { t: 'caps', d: { edit: true, journal: true } });

  // --- перезапуск без связи: баннер и список из сохранённого ---
  await page.click('#fseg button[data-k="friends"]'); await mock.close(); loadMain(); await sleep(200); await open(); await nav('Друзья');
  await until(() => vis('#fmain'), 4000, 'сразу вошёл'); assert(await vis('#fcache')); assert.strictEqual(await count('#flist .item.fr'), 8); assert((await txt('#fmes')).includes('нет связи')); await shot('10-friends-cached'); ok('перезапуск без связи: сразу «в аккаунте», все 8 друзей из сохранённого списка и пояснение про нет связи');
  mock = await newMock('admin'); await until(async () => !await vis('#fcache') && (await txt('#fmes')).includes('в сети'), 20000, 'автовход'); assert.strictEqual(await count('#flist .item.fr'), 8); assert.strictEqual(await vis('#fgate'), false); ok('связь вернулась: токен не подошёл, лаунчер вошёл по сохранённому паролю, баннер исчез');
  await page.click('#flogout'); await modalOk('сотрутся'); await until(() => vis('#fgate'), 3000, 'форма после выхода'); assert.strictEqual(await val('#fnick'), 'Anna'); assert.strictEqual(await val('#fpass'), ''); assert.strictEqual(await page.getAttribute('#fpass', 'placeholder') || '', ''); assert.strictEqual(await page.isChecked('#frem'), false); assert.strictEqual(await vis('#fsaved'), false); assert(!exists('hub-cred.bin') && !exists('friends-cache.json')); ok('«Выйти»: форма с ником, без пароля, без списка друзей, «запомнить» выключено, файлы стёрты');
  await page.fill('#fpass', 'secret12'); await page.check('#frem'); await page.click('#flogin'); await until(() => vis('#fmain'), 5000, 'вход через форму'); assert(exists('hub-cred.bin')); ok('вход через форму с включённым «запомнить» снова сохраняет пароль');

  // --- нечёткий поиск в списках ---
  const instDir = path.join(root, 'instances', '1.21.1-vanilla', 'mods'); fs.mkdirSync(instDir, { recursive: true }); for (const f of ['sodium-fabric-0.5.11.jar', 'lithium-fabric-0.12.jar', 'iris-1.7.2.jar']) fs.writeFileSync(path.join(instDir, f), 'x');
  await nav('Каталог'); await until(async () => (await count('#ml .item')) === 3, 4000, 'моды'); await page.fill('#mf', 'sodiun'); await until(async () => (await count('#ml .item')) === 1 && (await txt('#ml')).includes('sodium'), 2000, 'sodiun');
  await page.fill('#mf', 'ыщвшгь'); await until(async () => (await count('#ml .item')) === 1 && (await txt('#ml')).includes('sodium'), 2000, 'раскладка'); await page.fill('#mf', 'litium'); await until(async () => (await count('#ml .item')) === 1 && (await txt('#ml')).includes('lithium'), 2000, 'litium'); await page.fill('#mf', 'xyzxyz'); await until(async () => (await txt('#ml')).includes('Модов нет'), 2000, 'ничего'); await page.fill('#mf', ''); await until(async () => (await count('#ml .item')) === 3, 2000, 'все моды'); ok('установленные моды: «sodiun», «litium» и «ыщвшгь» находят нужный мод, мусор ничего');
  await nav('Версии'); await until(async () => (await count('#vl .item')) > 3, 6000, 'версии'); await page.fill('#vq', '1.20.1'); await until(async () => (await count('#vl .item')) === 1 && (await txt('#vl')).includes('1.20.1'), 2000, 'версия'); await page.fill('#vq', '1.2'); await until(async () => (await count('#vl .item')) >= 2, 2000, 'часть версии'); await page.fill('#vq', ''); ok('версии ищутся строго по номеру: «1.20.1» находит только 1.20.1');
  const items = ['Creative world', 'Survival base', 'Tech pack', 'Magic pack', 'Skyblock', 'Hardcore run'].map((name, i) => ({ id: 'p' + i, name, icon: '', mc: '1.21.1', loader: 'vanilla', lv: '' })); await H('cfg:set', { instances: items }); await page.reload(); await until(async () => (await txt('#nav')).includes('Друзья'), 4000, 'перезагрузка'); await nav('Мои сборки'); await until(() => vis('#iq'), 3000, 'поле поиска сборок');
  await page.fill('#iq', 'creatve'); await until(async () => (await txt('#ilist')).includes('Creative world') && !(await txt('#ilist')).includes('Skyblock'), 2000, 'сборка'); await page.fill('#iq', 'hardcor'); await until(async () => (await txt('#ilist')).includes('Hardcore run') && !(await txt('#ilist')).includes('Creative'), 2000, 'сборка 2'); await page.fill('#iq', ''); ok('сборки: поле поиска появляется от 5 сборок, «creatve» и «hardcor» находят нужную');

  const dup = await page.evaluate(() => { const c = {}; document.querySelectorAll('[id]').forEach(e => { c[e.id] = (c[e.id] || 0) + 1; }); return Object.keys(c).filter(k => c[k] > 1); }); assert.deepStrictEqual(dup, [], 'повторяющиеся id: ' + dup); ok('в разметке нет двух элементов с одним id (новые поля не перебивают старые)');
  // --- лёгкий режим сам ---
  const anim = async () => (await H('cfg:get')).anim, perf = (js) => page.evaluate(js);
  await H('cfg:set', { anim: true, perfCheck: true }); await page.evaluate(() => load());
  await perf('perfWatch.feed(5); perfWatch.feed(5)'); assert.strictEqual(await perf('perfWatch.bad'), 2); await perf('perfWatch.feed(60)'); assert.strictEqual(await perf('perfWatch.bad'), 0);
  await perf('perfWatch.feed(5); perfWatch.feed(5)'); assert.notStrictEqual(await anim(), false); ok('два медленных замера подряд ничего не меняют, один нормальный обнуляет счёт');
  await perf('gameOn = true; perfWatch.feed(1); perfWatch.feed(1); perfWatch.feed(1); perfWatch.feed(1)'); await perf('gameOn = false'); assert.notStrictEqual(await anim(), false); assert.strictEqual(await perf('perfWatch.bad'), 0); ok('пока идёт игра, замеры не считаются');
  await perf('perfWatch.feed(5); perfWatch.feed(5); perfWatch.feed(5)'); await until(async () => (await anim()) === false, 3000, 'анимации отключились');
  const c1 = await H('cfg:get'); assert.strictEqual(c1.perfCheck, false); assert(await page.evaluate(() => document.body.classList.contains('noanim'))); await until(async () => (await txt('#toast')).includes('лёгкий режим'), 2000, 'сообщение о лёгком режиме'); ok('три медленных замера подряд: анимации выключены, лаунчер об этом сказал, повторять не будет');
  await perf('for (let i = 0; i < 6; i++) perfWatch.feed(1)'); assert.strictEqual(await anim(), false); ok('после отключения замеры ничего не делают');
  await nav('Настройки'); await page.check('#anim'); await page.click('#save'); await until(async () => (await anim()) !== false, 3000, 'анимации включены вручную'); assert.strictEqual((await H('cfg:get')).perfCheck, false);
  await perf('for (let i = 0; i < 6; i++) perfWatch.feed(1)'); assert.notStrictEqual(await anim(), false); ok('если игрок сам включил анимации обратно, лаунчер их больше не отключает');
  await H('cfg:set', { anim: true, perfCheck: true }); await page.evaluate(() => load());
  await perf("window.__raf = window.requestAnimationFrame; window.requestAnimationFrame = cb => setTimeout(() => cb(performance.now()), 100)");
  for (let i = 0; i < 3; i++) { await perf('perfWatch.sample()'); await sleep(1900); }
  await until(async () => (await anim()) === false, 3000, 'настоящий замер медленных кадров'); await perf('window.requestAnimationFrame = window.__raf'); ok('настоящий замер: кадры раз в 100 мс (10 в секунду) три раза подряд отключают анимации');
  await H('cfg:set', { anim: true, perfCheck: true }); await page.evaluate(() => load()); await perf('perfWatch.sample()'); await sleep(1900); assert.strictEqual(await perf('perfWatch.bad'), 0); assert.notStrictEqual(await anim(), false); ok('обычные 60 кадров в секунду: замер ничего не меняет');
  await H('cfg:set', { anim: true, perfCheck: false }); await page.evaluate(() => load());

  // --- мой сервер ---
  await nav('Мой сервер'); await until(async () => (await count('#hsv option')) > 0 && (await txt('#hlist')).includes('пока нет'), 6000, 'версии и пустой список серверов'); assert(await page.isChecked('#honl')); await shot('08-server-new');
  const port3 = await listPort(); await page.fill('#hn', 'UI сервер'); await page.selectOption('#hsv', '1.21.1'); await page.fill('#hport', String(port3)); await page.click('#hcreate'); await until(async () => (await txt('#toast')).includes('EULA'), 3000, 'просьба принять EULA'); assert.strictEqual(await count('#hone:visible'), 0); ok('без галочки EULA кнопка «Создать» только напоминает про соглашение');
  await page.check('#heula'); await page.click('#hcreate'); await until(() => vis('#hone'), 12000, 'сервер создан'); assert((await txt('#hname')).includes('UI сервер')); assert.strictEqual(await txt('#hgo'), 'Запустить'); assert((await txt('#haddr')).includes('localhost:' + port3)); const created = (await H('srv:list')).servers[0]; assert.strictEqual(created.props['online-mode'], 'false'); assert.strictEqual(await page.isChecked('#heula'), false); ok('сервер создаётся из формы, открывается его страница с адресом; лицензия по умолчанию не проверяется (вход без Microsoft)');
  await page.click('#hgo'); await until(async () => (await txt('#hst')).includes('работает'), 8000, 'запущен'); await until(async () => (await txt('#hlog')).includes('Done (0.5s)'), 3000, 'лог'); assert.strictEqual(await page.isDisabled('#hcmd'), false); assert.strictEqual(await page.isDisabled('#hsave'), true); assert.strictEqual(await txt('#hgo'), 'Остановить');
  await page.fill('#hcmd', 'say привет'); await page.press('#hcmd', 'Enter'); await until(async () => (await txt('#hlog')).includes('got: say привет'), 3000, 'эхо команды'); assert((await txt('#hlog')).includes('> say привет')); await shot('08-server'); ok('сервер запускается, лог идёт в окно, команда доходит, настройки на время работы заблокированы');
  await page.click('#hplay'); await until(() => launches.length === 1, 6000, 'игра на своём сервере'); assert.strictEqual(launches[0].quickPlay.identifier, '127.0.0.1:' + port3); ok('«Зайти на сервер» запускает игру сразу на 127.0.0.1 с нужным портом');
  await nav('Мой сервер'); await until(() => vis('#hone'), 3000, 'вернулись на страницу сервера'); assert((await txt('#hname')).includes('UI сервер'));
  await page.click('#hadd'); await until(async () => ((await H('cfg:get')).servers || []).some(x => x.addr === '127.0.0.1:' + port3), 3000, 'добавлен в список'); ok('«В мои серверы» добавляет адрес во вкладку «Сервер»');
  await page.click('#hgo'); await modalOk('Остановить'); await until(async () => (await txt('#hst')).includes('остановлен'), 8000, 'остановлен'); await until(async () => (await txt('#hlog')).includes('Сервер остановлен'), 3000, 'строка об остановке в журнале'); assert.strictEqual(await page.isDisabled('#hsave'), false);
  await page.fill('#hp-motd', 'Мой мир'); await page.fill('#hp-max', '12'); await page.selectOption('#hp-gm', 'creative'); await page.uncheck('#hp-pvp'); await page.click('#hsave'); await until(async () => (await txt('#hsmsg')).includes('Сохранено'), 3000, 'сохранено'); const sp = (await H('srv:list')).servers[0].props; assert.strictEqual(sp.motd, 'Мой мир'); assert.strictEqual(sp['max-players'], '12'); assert.strictEqual(sp.gamemode, 'creative'); assert.strictEqual(sp.pvp, 'false'); ok('остановленный сервер: настройки меняются и сохраняются в server.properties');
  await page.fill('#hp-max', '5000'); await page.click('#hsave'); await until(async () => (await txt('#hsmsg')).includes('Игроков'), 3000, 'ошибка в настройках'); ok('неверное значение: понятное сообщение под формой, файл не испорчен');
  await page.click('#hdel'); await modalOk('вместе с миром'); await until(() => vis('#hlistc'), 3000, 'список'); assert((await txt('#hlist')).includes('пока нет')); assert.strictEqual(fs.readdirSync(path.join(root, 'servers')).length, 0); ok('удаление сервера из интерфейса: подтверждение, папка стёрта');

  assert.deepStrictEqual(pageErrors, []); ok('в интерфейсе нет ошибок JavaScript');
  await browser.close(); await mock.close(); netSrv.close(); quits.splice(0).forEach(f => f({ preventDefault() {} }));
  console.log(`\nГотово: ${n} проверок прошли`); process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
