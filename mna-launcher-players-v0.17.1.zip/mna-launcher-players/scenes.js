(()=>{
const U=7,mx=(c,p,t)=>`color-mix(in srgb,${c} ${p}%,${t})`,cols=c=>[c,mx(c,72,'#000'),mx(c,78,'#000'),mx(c,84,'#000'),mx(c,82,'#fff'),mx(c,50,'#000')];
const SK='#d68e69',HR='#3a2615',SH='#12a8b4',PN='#3b3fa6',PL='repeating-linear-gradient(0deg,#7d5a2b 0 3px,#a77a3d 3px 18px)';
const GR='repeating-linear-gradient(0deg,#5a3b1c 0 4px,transparent 4px 33.4%),repeating-linear-gradient(90deg,#5a3b1c 0 4px,transparent 4px 33.4%),#b88a4a';
const DOM=(t,c,s)=>{const e=document.createElement(t);if(c)e.className=c;if(s)e.style.cssText=s;return e};
const FIT=new Set(),TX=n=>{const f=n.endsWith('~'),u=`url(assets/tex/${f?n.slice(0,-1):n}.png)`;if(f)FIT.add(u);return u},tex=(...n)=>n.map(TX),all=n=>Array(6).fill(TX(n));
const bsz=c=>{c=String(c);if(c.startsWith('url')&&!FIT.has(c)){const m=c.match(/tex\/(.+)\.png/),d=window.TD&&m&&TD[m[1]];if(d)return `${d[0]*U/2}px ${d[1]*U/2}px`}return '100% 100%'};
function bx(w,h,d,c,css='',front=''){const e=DOM('div','bx',`width:${w}px;height:${h}px;${css}`),k=Array.isArray(c)?c:cols(c);
[[w,h,`translateZ(${d/2}px)`],[w,h,`rotateY(180deg) translateZ(${d/2}px)`],[d,h,`rotateY(-90deg) translateZ(${w/2}px)`],[d,h,`rotateY(90deg) translateZ(${w/2}px)`],[w,d,`rotateX(90deg) translateZ(${h/2}px)`],[w,d,`rotateX(-90deg) translateZ(${h/2}px)`]]
.forEach(([a,b,t],i)=>{const s=DOM('i','',`width:${a}px;height:${b}px;left:${(w-a)/2}px;top:${(h-b)/2}px;transform:${t};background:${k[i]};background-size:${bsz(k[i])};image-rendering:pixelated${String(k[i]).startsWith('url')?`;filter:brightness(${[1,.74,.82,.88,1.1,.55][i]})`:''}`);if(i==0)s.innerHTML=front;e.append(s)});return e}
const place=(e,w,h,x,y,z,ry=0,rz=0,cl='pl')=>{const p=DOM('div',cl,`transform:translate3d(${x}px,${y}px,${z}px) rotateY(${ry}deg) rotateZ(${rz}deg)`);e.style.left=-w/2+'px';e.style.top=-h/2+'px';p.append(e);return p};
const grp=(x,y,z,ry=0)=>DOM('div','pl',`transform:translate3d(${x}px,${y}px,${z}px) rotateY(${ry}deg)`);
function steve(g,o={}){const s=DOM('div','st'),P=(c,e,l,t)=>{e.classList.add(c);e.style.left=l+'px';e.style.top=t+'px';s.append(e);return e},K=(w,h,d,c,l,t,z=0)=>bx(w,h,d,c,`left:${l}px;top:${t}px;transform:translateZ(${z}px)`);
const hp=o.h||'h',bp=o.b||'b',ap=o.a||'a',lp=o.l||'l',sk=o.skin||SK;
const hd=P('h',bx(8*U,8*U,8*U,tex(`${hp}_f`,`${hp}_b`,`${hp}_l`,`${hp}_r`,`${hp}_t`,`${hp}_d`),'',`<b class="bl" style="background:${sk}"></b>`),0,0);
if(!o.nohair){const hl=bx(8.8*U,8.8*U,8.8*U,tex('hl_f~','hl_b~','hl_l~','hl_r~','hl_t~','hl_d~'));hl.style.left=hl.style.top=-.4*U+'px';hd.append(hl)}
const nw=o.big?[1.8*U,3.4*U,2.2*U]:[1.6*U,1.8*U,1.2*U];
if(o.big)hd.append(K(nw[0],nw[1],nw[2],o.nc||'#78a64e',(8*U-nw[0])/2,4.2*U,4*U+nw[2]/2-.2*U));
if(g)hd.append(K(8.6*U,1.9*U,1.2*U,[typeof g=='string'?g:'linear-gradient(110deg,#2c4a6e,#06080b 50%,#16283d)','#000','#000','#000','#111','#000'],-.3*U,3.3*U,4.2*U));
const tr=P('t',bx(8*U,12*U,4*U,tex(`${bp}_f`,`${bp}_b`,`${bp}_s`,`${bp}_s`,`${bp}_t`,`${bp}_d`)),0,8*U);
if(!o.plain)tr.append(K(8.5*U,1.3*U,4.5*U,'#4a3022',-.25*U,10*U),K(1.5*U,1.2*U,.5*U,'#f0c640',3.25*U,10.05*U,2.35*U));
const A=tex(`${ap}_f`,`${ap}_b`,`${ap}_s`,`${ap}_s`,`${ap}_t`,`${ap}_d`),L=tex(`${lp}_f`,`${lp}_b`,`${lp}_s`,`${lp}_s`,`${lp}_t`,`${lp}_d`);
const al=P('al',bx(4*U,12*U,4*U,A),-4*U,8*U),ar=P('ar',bx(4*U,12*U,4*U,A),8*U,8*U);if(!o.plain)[al,ar].forEach(a=>a.append(K(4.5*U,1.1*U,4.5*U,'#1c2a66',-.25*U,8.4*U)));
P('ll',bx(4*U,12*U,4*U,L),0,20*U);P('lr',bx(4*U,12*U,4*U,L),4*U,20*U);return s}
const table=()=>bx(16*U,16*U,16*U,tex('ct_front','ct_side','ct_side2','ct_side','ct_top','planks_d'));
const torch=(k=1)=>{const g=grp(0,0,0);g.append(place(bx(U*k,6*U*k,U*k,all('wood')),U*k,6*U*k,0,-3*U*k,0));const f=bx(1.5*U*k,1.5*U*k,1.5*U*k,'#ffd25a');f.classList.add('fl');g.append(place(f,1.5*U*k,1.5*U*k,0,-6.7*U*k,0));return g};
const at=(g,x,y,z,ry=0)=>{g.style.transform=`translate3d(${x}px,${y}px,${z}px) rotateY(${ry}deg)`;return g};
const wr=(e,x,z,ry=0,y=0)=>{const g=grp(x,y,z,ry);g.append(e);return g};
const anvil=()=>{const g=grp(0,0,0);[[8*U,2*U,5*U,-U],[4*U,3*U,3*U,-3.5*U],[10*U,3*U,4.5*U,-6.5*U]].forEach(([a,b,c,y])=>g.append(place(bx(a,b,c,all('anvil')),a,b,0,y,0)));return g};
const barrel=()=>place(bx(8*U,10*U,8*U,tex('barrel8s','barrel8s','barrel8s','barrel8s','barrel8t','barrel8t')),8*U,10*U,0,-5*U,0);
const chest=()=>place(bx(10*U,8*U,8*U,tex('chest_f','chest_f','chest_s','chest_s','chest_t','chest_t')),10*U,8*U,0,-4*U,0);
const crate=()=>place(bx(8*U,8*U,8*U,all('crate8')),8*U,8*U,0,-4*U,0);
const wall=()=>{const p=DOM('div','pl','transform:translate3d(0,-200px,-300px)');p.append(DOM('div','wall'));return p};
const hatW=()=>{const c='#4b2a7a',B=(w,h,l,t,tf='')=>bx(w,h,w,c,`left:${l}px;top:${t}px;${tf}`);
return[B(13*U,.8*U,-2.5*U,-.4*U),B(8.8*U,2.2*U,-.4*U,-2.4*U),B(6*U,2.2*U,U,-4.5*U,'transform:rotateZ(5deg)'),B(3.8*U,2.2*U,2.1*U,-6.6*U,'transform:rotateZ(12deg)'),B(1.8*U,2*U,3.3*U,-8.5*U,'transform:rotateZ(22deg)'),bx(8.9*U,.8*U,8.9*U,'#1d1030',`left:${-.45*U}px;top:${-1.3*U}px`)]};
const capP=()=>[bx(8.9*U,2*U,8.9*U,'#d63a2e',`left:${-.45*U}px;top:${-.9*U}px`),bx(8*U,.5*U,4*U,'#a82a20',`left:0;top:${.6*U}px;transform:translateZ(${-6*U}px)`)];
const helm=()=>[bx(9*U,5.2*U,9*U,tex('helm_f','iron','iron','iron','iron','iron'),`left:${-.5*U}px;top:${-.7*U}px`),bx(.9*U,4*U,6*U,all('iron'),`left:${-.95*U}px;top:${3*U}px`),bx(.9*U,4*U,6*U,all('iron'),`left:${8.05*U}px;top:${3*U}px`),bx(U,3*U,6*U,'#c0392b',`left:${3.5*U}px;top:${-3.6*U}px`)];
const cauldron=()=>{const a=[place(bx(12*U,12*U,12*U,tex('cauldron_s','cauldron_s','cauldron_s','cauldron_s','cauldron_t','cauldron_s')),12*U,12*U,0,-8*U,0)];
[[-5,-5],[5,-5],[-5,5],[5,5]].forEach(([x,z])=>a.push(place(bx(1.6*U,2*U,1.6*U,all('anvil')),1.6*U,2*U,x*U,-U,z*U)));
a.push(place(bx(10*U,U,U,all('wood')),10*U,U,0,-.5*U,0),place(bx(U,U,10*U,all('wood')),U,U,0,-.5*U,0));
[[-3,0],[3,2],[0,-3]].forEach(([x,z])=>{const f=bx(2*U,2*U,2*U,'#ffb03a');f.classList.add('fl');a.push(place(f,2*U,2*U,x*U,-1.5*U,z*U))});
for(let i=0;i<8;i++){const b=bx(9,9,9,'#9bff7a');b.style.animation=`bub ${1.6+i*.2}s ${-i*.35}s linear infinite`;a.push(place(b,9,9,(Math.random()-.5)*5*U,-14*U,(Math.random()-.5)*5*U))}
return a};
const dragon=()=>{const g=grp(0,0,0),DS=all('dscale'),sg=(w,h,d,x,y,z,rz=0)=>g.append(place(bx(w,h,d,DS),w,h,x,y,z,0,rz));
sg(18*U,6*U,8*U,0,0,0);for(let k=0;k<4;k++)sg(4*U,4*U,4*U,(10+2.5*k)*U,-(1.2+1.7*k)*U,0,-(15+8*k));
sg(7*U,3.6*U,5*U,22*U,-9*U,0);sg(6*U,1.4*U,4*U,22.5*U,-6.6*U,0,8);
[-1,1].forEach(z=>{g.append(place(bx(.8*U,.8*U,.5*U,'#d9b3ff'),.8*U,.8*U,23.6*U,-10*U,z*2.6*U),place(bx(U,2.4*U,U,'#2a2a2a'),U,2.4*U,20.4*U,-11.5*U,z*1.6*U,0,-30));
sg(2*U,3.5*U,2*U,6*U,3.5*U,z*3.6*U);sg(2*U,3.5*U,2*U,-6*U,3.5*U,z*3.6*U)});
for(let k=0;k<5;k++)sg((5-.8*k)*U,(4-.6*k)*U,(5-.8*k)*U,-(10.5+2.8*k)*U,.4*k*U,0,k*5);
[1,-1].forEach(z=>{const w=grp(0,-3*U,z*3.5*U);w.classList.add(z>0?'wg1':'wg2');w.append(place(bx(14*U,.5*U,16*U,all('dwing~')),14*U,.5*U,0,0,z*8*U),place(bx(.8*U,.8*U,16*U,'#1a1426'),.8*U,.8*U,6*U,0,z*8*U));g.append(w)});
return g};
const cloud=(y,z,d,dl,k)=>{const q=grp(0,0,0);q.className='pl cl';q.style.cssText=`--cy:${y}px;--cz:${z}px;animation:cld ${d}s ${dl}s linear infinite`;
q.append(place(bx(70*k,18*k,40*k,all('cloud')),70*k,18*k,0,0,0),place(bx(44*k,16*k,30*k,all('cloud')),44*k,16*k,26*k,-10*k,8),place(bx(40*k,14*k,26*k,all('cloud')),40*k,14*k,-24*k,-8*k,-6));return q};
function pick(){const g=DOM('div','pk',`width:${8*U}px;height:${12*U}px`),m='#6b4a22',s='#8fd0d8',A=(e,l,t)=>{e.style.left=l+'px';e.style.top=t+'px';g.append(e)};
A(bx(U,10*U,U,all('wood')),3.5*U,2*U);A(bx(8*U,1.6*U,U,all('diamond')),0,0);A(bx(1.6*U,2.4*U,U,all('diamond')),0,1.6*U);A(bx(1.6*U,2.4*U,U,all('diamond')),6.4*U,1.6*U);return g}
const cb=()=>bx(6*U,5*U,6*U,tex('crate6s','crate6s','crate6s','crate6s','crate6t','crate6t'));
function shelf(){const g=grp(0,0,0);[-7.5,7.5].forEach(x=>g.append(place(bx(U,22*U,6*U,all('planks_d')),U,22*U,x*U,-11*U,0)));
[0.5,10.5,21].forEach((y,i)=>{g.append(place(bx(16*U,U,6*U,all('planks')),16*U,U,0,-y*U-U/2,0));if(i<2)g.append(place(cb(),6*U,5*U,(i?-3:3)*U,-(y+1)*U-2.5*U,0))});return g}
const TXT=(t)=>`<div class="vt">${t}</div>`;
const CUBES=[['1.7','stone'],['1.12','dirt'],['1.16','gold'],['1.20','diamond'],['1.21','redstone'],['26.2','grass']];
const S={
home(w){w.append(place(table(),16*U,16*U,0,-8*U,60),place(steve(),8*U,32*U,0,-16*U,0),place(pick(),8*U,12*U,95,-42,62,0,-18))},
cat(w){const act=(i,fn)=>{const g=grp(0,0,0);g.className='pl act a'+i;fn(g);w.append(g)},head=s=>s.querySelector('.h'),stv=(o,x=0,y=-16*U,z=0,ry=0)=>{const s=steve(o.g,o);return[s,place(s,8*U,32*U,x,y,z,ry)]};
act(0,g=>g.append(stv({})[1]));
act(1,g=>{const[s,p]=stv({b:'wb',a:'wa',l:'wl',h:'wh',nohair:1,plain:1,big:1,nc:'#78a64e',skin:'#7eb052'});head(s).append(...hatW());
s.querySelector('.ar').append(bx(8,92,8,all('wood'),'left:10px;top:70px;transform-origin:50% 0;transform:rotateX(-58deg)'));const c=grp(0,0,70);c.append(...cauldron());g.append(p,c)});
act(2,g=>{[[-140,56],[0,84],[140,56]].forEach(([x,h])=>g.append(place(bx(8*U,h,8*U,tex('cobble','cobble','cobble','cobble','grass_top','cobble')),8*U,h,x,-h/2,0)));
const[s,p]=stv({b:'pb',a:'pa',l:'pl',plain:1},0,0,0,90),o=DOM('div','pl pkw');head(s).append(...capP());o.append(p);g.append(o)});
act(3,g=>{const[s,p]=stv({b:'rb',a:'ra',l:'rl',plain:1,g:'linear-gradient(110deg,#ffb86b,#7a3a00 55%,#ffcf94)'},4*U,-7*U,0,90),d=dragon();d.classList.add('dg');
s.querySelector('.t').append(bx(8.6*U,1.2*U,4.6*U,'#c0392b',`left:${-.3*U}px;top:${-.4*U}px`),bx(1.6*U,.5*U,7*U,'#c0392b',`left:${3.2*U}px;top:${.2*U}px;transform:translateZ(${-6.5*U}px)`));
d.append(p);g.append(d,cloud(-330,-120,9,-2,1.3),cloud(-250,100,7,-5,1),cloud(-420,0,11,-7,1.5),cloud(-160,-160,8,-1,1.1),cloud(-300,140,10,-9,.9))});
act(4,g=>{const[s,p]=stv({b:'gb',a:'ga',l:'gl',plain:1});head(s).append(...helm());const R=s.querySelector('.ar'),Lf=s.querySelector('.al');
R.append(bx(.7*U,30*U,.7*U,all('wood'),`left:${11.5}px;top:-35px`),bx(11,22,3.5,all('iron'),'left:8.5px;top:-57px'));
Lf.append(bx(6*U,8*U,.8*U,['url(assets/tex/shield.png)','#2a2f4a','#2a2f4a','#2a2f4a','#2a2f4a','#2a2f4a'],'left:-7px;top:14px;transform:translateZ(22px) rotateX(-40deg)'));g.append(p)});
for(let i=0;i<5;i++){const b=DOM('div','pl',`transform:translate3d(0,${-110}px,0)`);for(let j=0;j<6;j++){const t=Math.random()*6.28,v=[Math.cos(t)*120,-60+(Math.random()-.5)*130,Math.sin(t)*90],c=bx(16,16,16,['#f4ecff','#cdb0ff','#9be7ff'][j%3]);
c.style.cssText+=`;--x:${v[0].toFixed(0)};--y:${v[1].toFixed(0)};--z:${v[2].toFixed(0)};animation:pf${i} 30s linear infinite`;b.append(place(c,16,16,0,0,0))}w.append(b)}},
inst(w){const sh=shelf();sh.style.transform='translate3d(130px,0,-10px) rotateY(-12deg)';w.append(sh);
w.append(place(steve(),8*U,32*U,0,-16*U,0,90,0,'pl cw'),place(cb(),6*U,5*U,-178,-137,95,0,0,'pl bxw'))},
versions(w){const r=DOM('div','ring','left:0;top:0');CUBES.forEach(([t,c],i)=>{const q=DOM('div','pl cube',`transform:rotateY(${i*60}deg) translateZ(120px);animation-delay:${i*.4}s`),b=bx(56,56,56,c=='grass'?tex('grass_side~','grass_side~','grass_side~','grass_side~','grass_top~','dirt~'):all(c+'~'),'',TXT(t));b.style.left='-28px';b.style.top='-28px';q.append(b);r.append(q)});
w.append(place(r,0,0,85,-130,0),place(steve(),8*U,32*U,0,-16*U,0,0),Object.assign(DOM('div'),{}))},
server(w){const c=grp(-95,0,15,-10);c.append(place(bx(8*U,8,8*U,'#222'),8*U,8,0,-46,0),place(bx(8*U,66,8,'#2a2a2a'),8*U,66,0,-88,-32),place(bx(8,40,8,'#444'),8,40,0,-22,0),place(bx(60,6,8,'#333'),60,6,0,-3,0),place(bx(8,6,60,'#333'),8,6,0,-3,0));
const st=steve(1),tb=bx(30,40,4,'#10202e','left:0;top:62px;transform:translate3d(0,0,22px) rotateX(-70deg)'),cu=bx(16,18,16,['#f4f4f4','#ddd','#ddd','#ddd','#5a3a22','#eee'],'left:6px;top:70px;transform:translate3d(0,0,20px)');
st.querySelector('.al').append(tb);st.querySelector('.ar').append(cu);c.append(place(st,8*U,32*U,0,-78,6));w.append(c);
const d=grp(105,0,-10,-42),wd='#a77a3d';d.append(place(bx(130,8,70,all('planks')),130,8,0,-70,0));[[-58,-28],[58,-28],[-58,28],[58,28]].forEach(([x,z])=>d.append(place(bx(8,66,8,'#6b4a22'),8,66,x,-33,z)));
d.append(place(bx(12,22,12,'#222'),12,22,0,-85,-10),place(bx(98,62,8,['#0a1620','#111','#111','#111','#111','#111'],'', '<div class="scr"></div>'),98,62,0,-127,-10),place(bx(50,3,16,'#333'),50,3,0,-76,20));w.append(d);
const leds=[...Array(6)].map((_,i)=>`<div class="rk"><b class="led" style="animation-delay:${i*.23}s"></b><b class="led" style="animation-delay:${i*.41}s;background:#1e8cff"></b></div>`).join('');
const rk=grp(200,0,-55,-42);rk.append(place(bx(56,154,42,'#1c2430','','<div class="rkf">'+leds+'</div>'),56,154,0,-77,0));w.append(rk)}
};
const EX={
home(w){w.append(wr(anvil(),-150,25,35),wr(barrel(),150,-50),wr(chest(),-135,-70,20),at(torch(),-50,-133,15))},
cat(w){},
inst(w){w.append(wr(crate(),60,-95,10),wr(crate(),60,-95,0,-8*U),wr(crate(),-5,-110,-15),wr(barrel(),-140,-60),wr(chest(),-160,30,40))},
versions(w){w.append(place(bx(110,14,110,all('cobble')),110,14,85,-7,0),place(bx(18,300,18,Array(6).fill('rgba(140,220,255,.30)')),18,300,85,-164,0),place(bx(8,300,8,Array(6).fill('rgba(220,245,255,.45)')),8,300,85,-164,0))},
server(w){w.append(place(bx(170,2,8,'#1e8cff'),170,2,105,-1,32),wr(chest(),-190,-60,30),wr(barrel(),-175,40))}
};
const kf=(n,s)=>ks+=`@keyframes ${n}{${s}}`;let ks='';
let lw='0%,3%{transform:rotateX(0)}',lw2=lw;
for(let i=0;i<=11;i++){const t=3+i*2.6,a=i%2?-28:28;lw+=`${t}%{transform:rotateX(${a}deg)}`;lw2+=`${t}%{transform:rotateX(${-a}deg)}`}
lw+='33%,43%{transform:rotateX(0)}';lw2+='33%,43%{transform:rotateX(0)}';
[44,46.3,48.6,50.9].forEach((t,i)=>{const a=i%2?-24:24;lw+=`${t}%{transform:rotateX(${a}deg)}`;lw2+=`${t}%{transform:rotateX(${-a}deg)}`});
lw+='52%,100%{transform:rotateX(0)}';lw2+='52%,100%{transform:rotateX(0)}';kf('lw',lw);kf('lw2',lw2);
let cr='';for(let i=0;i<=8;i++)cr+=`${i*4.4}%{transform:rotateX(${i%2?72:48}deg)}`;
kf('crf',cr+'46%,70%{transform:rotateX(160deg)}86%,100%{transform:rotateX(55deg)}');
kf('hm','0%,100%{transform:rotateX(55deg)}50%{transform:rotateX(42deg)}');kf('hm2','0%,100%{transform:rotateX(45deg) rotateZ(8deg)}50%{transform:rotateX(62deg) rotateZ(-8deg)}');
kf('lk','0%,100%{transform:rotateX(18deg)}50%{transform:rotateX(10deg) rotateY(-26deg)}');
kf('lk2','0%,40%{transform:rotateX(20deg)}50%,70%{transform:rotateX(-8deg) rotateY(-22deg)}85%,100%{transform:rotateX(20deg)}');
kf('pk','0%,30%{transform:translateY(40px) scale(0)}40%{transform:translateY(-10px) scale(1)}55%{transform:translateY(-30px) rotateY(180deg)}70%{transform:translateY(-30px) rotateY(360deg)}85%{transform:translateY(40px) scale(.1) rotateY(540deg)}100%{transform:translateY(40px) scale(0)}');
kf('bob','0%,100%{transform:translateY(0)}50%{transform:translateY(-4px)}');
kf('cwk','0%{transform:translate3d(-230px,-112px,95px) rotateY(90deg);visibility:hidden}3%{transform:translate3d(-230px,-112px,95px) rotateY(90deg);visibility:visible}24%{transform:translate3d(130px,-112px,95px) rotateY(90deg)}29%{transform:translate3d(130px,-112px,95px) rotateY(180deg)}36%,43%{transform:translate3d(130px,-112px,66px) rotateY(180deg)}52%{transform:translate3d(55px,-112px,95px) rotateY(8deg)}68%{transform:translate3d(55px,-112px,95px) rotateY(8deg);visibility:visible}70%,100%{transform:translate3d(55px,-112px,95px) rotateY(8deg);visibility:hidden}');
kf('ca','0%,29%{transform:rotateX(85deg)}36%{transform:rotateX(95deg)}40%{transform:rotateX(125deg)}45%,100%{transform:rotateX(0)}');
kf('car','0%,29%{transform:rotateX(85deg)}36%{transform:rotateX(95deg)}40%{transform:rotateX(125deg)}45%,52%{transform:rotateX(0)}54%,58%,62%,66%{transform:rotateX(125deg) rotateZ(30deg)}56%,60%,64%{transform:rotateX(125deg) rotateZ(55deg)}68%,100%{transform:rotateX(0)}');
kf('bxk2','0%{transform:translate3d(-178px,-137px,95px);visibility:hidden}3%{transform:translate3d(-178px,-137px,95px);visibility:visible}24%{transform:translate3d(182px,-137px,95px)}29%{transform:translate3d(130px,-137px,43px)}36%{transform:translate3d(130px,-137px,14px)}39%,99%{transform:translate3d(130px,-172px,-8px) rotateY(-12deg);visibility:visible}100%{transform:translate3d(130px,-172px,-8px) rotateY(-12deg);visibility:hidden}');
kf('clk','0%,70%{opacity:0;transform:translateY(90px) rotateX(35deg)}77%,94%{opacity:1;transform:translateY(0) rotateX(8deg) rotate(-2deg)}100%{opacity:0;transform:translateY(90px) rotateX(35deg)}');
kf('spin','to{transform:rotateY(360deg)}');kf('fl','from{margin-top:-6px}to{margin-top:8px}');
kf('pt','0%,100%{transform:rotateX(150deg) rotateZ(-10deg)}50%{transform:rotateX(110deg) rotateZ(-25deg)}');kf('lk3','0%,100%{transform:rotateY(-20deg)}50%{transform:rotateY(25deg)}');
kf('sip','0%,25%{transform:rotateX(70deg)}40%,55%{transform:rotateX(125deg)}70%,100%{transform:rotateX(70deg)}');kf('hs','0%,35%{transform:rotateX(8deg)}42%,55%{transform:rotateX(-14deg)}65%,100%{transform:rotateX(8deg)}');
kf('bl','0%,100%{opacity:.25}50%{opacity:1}');kf('blink','0%,94%,100%{opacity:0}96%,98%{opacity:1}');kf('fire','from{transform:scale(.9)}to{transform:scale(1.12)}');kf('rise','0%{transform:translateY(0);opacity:0}15%{opacity:.9}100%{transform:translateY(-130px) rotateY(180deg);opacity:0}');kf('sc','to{background-position:0 -124px}');kf('sway','from{transform:rotateX(-12deg) rotateY(-20deg)}to{transform:rotateX(-10deg) rotateY(20deg)}');
const css=`.wall{position:absolute;left:-400px;top:-200px;width:800px;height:400px;background:linear-gradient(#071428b0,#071428b0),url(assets/tex/cobble.png) 0 0/112px 112px;image-rendering:pixelated;-webkit-mask:radial-gradient(ellipse at 50% 58%,#000 30%,transparent 72%)}.fl i{background:#ffd25a!important;box-shadow:0 0 18px 9px #ffa63dbb}.fl{animation:fire .4s infinite alternate}.bl{left:7px;top:28px;width:42px;height:7px;background:${SK};animation:blink 4.5s infinite}.shd{position:absolute;border-radius:50%;background:radial-gradient(#000d,#0000 70%)}#stage:before{content:"";position:absolute;inset:0;background:radial-gradient(ellipse at 50% 62%,#1e8cff3d,transparent 62%)}#stage{position:fixed;right:0;top:0;bottom:0;width:46%;perspective:1100px;pointer-events:none;z-index:0;overflow:hidden}
#world{position:absolute;left:50%;top:68%;width:0;height:0;transform-style:preserve-3d;animation:sway 9s ease-in-out infinite alternate}
.pl,.bx,.st,.pk,.ring,.cube{position:absolute;transform-style:preserve-3d}.pl{left:0;top:0}.bx i{position:absolute;backface-visibility:hidden}.bx i b,.bx i div{position:absolute;display:block}
.floor{position:absolute;left:-380px;top:-380px;width:760px;height:760px;transform:rotateX(90deg);background:repeating-linear-gradient(0deg,#1e8cff40 0 1px,transparent 1px 56px),repeating-linear-gradient(90deg,#1e8cff40 0 1px,transparent 1px 56px),linear-gradient(#071428c4,#071428c4),url(assets/tex/cobble.png) 0 0/112px 112px;image-rendering:pixelated;-webkit-mask:radial-gradient(circle,#000 25%,transparent 68%)}
.st{left:-28px;top:0;width:56px;height:224px}.al,.ar,.ll,.lr{transform-origin:50% 0}.h{transform-origin:50% 100%}
.hr{left:0;top:0;width:100%;height:18px;background:${HR}}.ey{top:28px;width:14px;height:7px}.e1{left:7px;background:linear-gradient(90deg,#fff 50%,#3d3fdc 50%)}.e2{left:35px;background:linear-gradient(90deg,#3d3fdc 50%,#fff 50%)}
.mo{left:14px;top:43px;width:28px;height:8px;background:#7a4a2e}.gl{left:-2px;top:24px;width:60px;height:16px;border-radius:3px;background:linear-gradient(120deg,#1b2a3a,#050505 60%);box-shadow:0 0 8px #1e8cffaa}
.vt{left:0;top:0;width:100%;height:100%;display:flex!important;align-items:center;justify-content:center;font:700 17px Segoe UI;color:#fff;text-shadow:0 1px 3px #000;background:#0003}.cube{animation:fl 3s ease-in-out infinite alternate}
.scr{inset:0;background:url(assets/tex/screen.png);background-size:100% 124px;image-rendering:pixelated;animation:sc 9s linear infinite}
.rkf{inset:0;padding:6px}.rk{height:21px;margin-bottom:4px;background:#0c1118;border:1px solid #2b3a4c;display:flex;gap:4px;align-items:center;padding:0 6px}.led{position:relative!important;width:7px;height:7px;border-radius:50%;background:#2ecc71;box-shadow:0 0 6px currentColor;animation:bl 1.2s infinite}
.s-home .ar{animation:hm 2.6s ease-in-out infinite}.s-home .al{animation:hm2 2s ease-in-out infinite}.s-home .h{animation:lk 5s ease-in-out infinite}.s-home .st{animation:bob 3s ease-in-out infinite}
.s-cat .al{animation:hm2 1.1s infinite}.s-cat .ar{animation:crf 8s infinite}.s-cat .h{animation:lk2 8s infinite}.s-cat .pk2{animation:pk 8s infinite}
.s-inst .cw{animation:cwk 16s infinite}.s-inst .al{animation:ca 16s infinite}.s-inst .ar{animation:car 16s infinite}.s-inst .ll{animation:lw 16s infinite}.s-inst .lr{animation:lw2 16s infinite}.s-inst .bxw{animation:bxk2 16s infinite}
.s-versions .ring{animation:spin 18s linear infinite}.s-versions .ar{animation:pt 3s ease-in-out infinite}.s-versions .h{animation:lk3 6s ease-in-out infinite}.s-versions .al{transform:rotateX(10deg)}
.s-server .al{transform:rotateX(78deg)}.s-server .ar{animation:sip 6s ease-in-out infinite}.s-server .h{animation:hs 6s ease-in-out infinite}.s-server .ll,.s-server .lr{transform:rotateX(88deg)}
#clip{position:absolute;left:50%;top:14%;width:290px;margin-left:-145px;opacity:0;perspective:600px;display:none;animation:clk 16s infinite}
#clip .bd{background:#7b5427;border-radius:10px;padding:34px 16px 16px;box-shadow:0 14px 40px #000a;position:relative}#clip .bd:before{content:"";position:absolute;left:50%;top:6px;width:90px;height:20px;margin-left:-45px;border-radius:5px;background:linear-gradient(#cfd6de,#8a95a3)}
#clip .pp{background:#f6f1e3;border-radius:4px;padding:12px 14px;min-height:300px;color:#222;font:15px Segoe UI;background-image:repeating-linear-gradient(transparent 0 25px,#9db6d255 25px 26px)}#clip h4{margin:0 0 8px;color:#1a3b73}#clip div.n{line-height:26px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#fp{position:absolute;left:50%;bottom:-30px;width:120px;margin-left:-60px;height:120px;display:none;background:linear-gradient(${SK} 0 45%,${SH} 45%);border-radius:10px 10px 0 0;animation:clk 16s infinite}`;
{const pc=t=>(40+t*.2).toFixed(2)+'%',v=(f,sc,vis)=>`transform:translate3d(calc(var(--x)*${f}px),calc(var(--y)*${f}px),calc(var(--z)*${f}px)) scale(${sc});visibility:${vis}`;
for(let i=0;i<5;i++){const a=20*i,e=a+20;kf('av'+i,(a?`0%{visibility:hidden}${a-.01}%{visibility:hidden}`:'')+`${a}%{visibility:visible}${a?'':''}${e}%{visibility:visible}`+(e<100?`${e+.01}%{visibility:hidden}100%{visibility:hidden}`:''));
kf('pf'+i,a?`0%{visibility:hidden}${a-2.6}%{visibility:hidden}${a-2.5}%{${v(0,.2,'visible')}}${a}%{${v(.55,1.5,'visible')}}${a+2.5}%{${v(1,.1,'visible')}}${a+2.6}%{visibility:hidden}100%{visibility:hidden}`:`0%{${v(.55,1.5,'visible')}}2.5%{${v(1,.1,'visible')}}2.6%{visibility:hidden}97.4%{visibility:hidden}97.5%{${v(0,.2,'visible')}}100%{${v(.55,1.5,'visible')}}`)}
kf('pkj',[[0,-140,-168,0],[12,-140,-168,0],[21,-105,-262,85],[31,-70,-300,180],[41,-35,-262,275],[50,0,-196,360],[62,0,-196,360],[70,35,-270,430],[79,70,-306,540],[88,105,-262,640],[95,140,-168,720],[100,140,-168,720]].map(([t,x,y,r])=>`${pc(t)}{transform:translate3d(${x}px,${y}px,0) rotateZ(${r}deg)}`).join(''));
kf('wave','0%,55%,100%{transform:rotateX(0)}62%{transform:rotateX(150deg) rotateZ(25deg)}70%,86%{transform:rotateX(150deg) rotateZ(-5deg)}78%{transform:rotateX(150deg) rotateZ(25deg)}93%{transform:rotateX(0)}');
kf('stir','0%,50%,100%{transform:rotateX(55deg) rotateZ(0)}25%{transform:rotateX(62deg) rotateZ(10deg)}75%{transform:rotateX(48deg) rotateZ(-10deg)}');
kf('cack','0%,100%{transform:rotateX(14deg)}50%{transform:rotateX(22deg) rotateY(8deg)}');
kf('run','0%,100%{transform:rotateX(38deg)}50%{transform:rotateX(-38deg)}');kf('run2','0%,100%{transform:rotateX(-38deg)}50%{transform:rotateX(38deg)}');
kf('gs','0%,60%,100%{transform:rotateX(12deg)}70%{transform:rotateX(30deg)}80%{transform:rotateX(12deg)}');
kf('dbob','from{transform:translate3d(-30px,-210px,0) rotateZ(-3deg)}to{transform:translate3d(-30px,-240px,0) rotateZ(3deg)}');
kf('wf1',`0%,100%{transform:translate3d(0,${-3*U}px,${3.5*U}px) rotateX(-28deg)}50%{transform:translate3d(0,${-3*U}px,${3.5*U}px) rotateX(38deg)}`);
kf('wf2',`0%,100%{transform:translate3d(0,${-3*U}px,${-3.5*U}px) rotateX(28deg)}50%{transform:translate3d(0,${-3*U}px,${-3.5*U}px) rotateX(-38deg)}`);
kf('cld','from{transform:translate3d(320px,var(--cy),var(--cz))}to{transform:translate3d(-340px,var(--cy),var(--cz))}');
kf('bub','0%{transform:translateY(0) scale(.4);opacity:0}25%{opacity:1}100%{transform:translateY(-70px) scale(1.2);opacity:0}');
kf('scf','0%,100%{transform:translateZ(-45px) rotateX(10deg)}50%{transform:translateZ(-45px) rotateX(-16deg)}')}
const CAT=[0,1,2,3,4].map(i=>`.s-cat .a${i}{animation:av${i} 30s linear infinite}`).join('')+`.s-cat .a0 .h{animation:lk3 6s ease-in-out infinite}.s-cat .a0 .ar{animation:wave 5s ease-in-out infinite}.s-cat .a0 .st{animation:bob 3s ease-in-out infinite}
.s-cat .a1 .ar{animation:stir 1.6s ease-in-out infinite}.s-cat .a1 .al{transform:rotateX(25deg) rotateZ(-14deg)}.s-cat .a1 .h{animation:cack .8s ease-in-out infinite}
.s-cat .pkw{animation:pkj 30s linear infinite}.s-cat .a2 .ll,.s-cat .a2 .ar{animation:run .45s linear infinite}.s-cat .a2 .lr,.s-cat .a2 .al{animation:run2 .45s linear infinite}
.s-cat .dg{animation:dbob 3.2s ease-in-out infinite alternate}.s-cat .wg1{animation:wf1 .9s ease-in-out infinite}.s-cat .wg2{animation:wf2 .9s ease-in-out infinite}
.s-cat .a3 .ll,.s-cat .a3 .lr{transform:rotateX(78deg)}.s-cat .a3 .al,.s-cat .a3 .ar{transform:rotateX(55deg)}
.s-cat .a4 .ar{animation:gs 2.6s ease-in-out infinite}.s-cat .a4 .al{transform:rotateX(40deg)}.s-cat .a4 .h{animation:lk3 7s ease-in-out infinite}`;
const shd=(x,z,a,b)=>{const p=DOM('div','pl',`transform:translate3d(${x}px,-1px,${z}px) rotateX(90deg)`);p.append(DOM('div','shd',`width:${a}px;height:${b}px;left:${-a/2}px;top:${-b/2}px`));return p};
const SHD={home:[[0,0,120,100],[0,60,200,180]],cat:[[0,0,130,110],[0,70,120,100]],inst:[[130,-10,180,110]],versions:[[0,0,120,100],[85,0,300,300]],server:[[-95,15,140,140],[105,-10,210,130],[200,-55,100,90]]};
const dust=w=>{for(let i=0;i<6;i++){const p=place(bx(4,4,4,'#9fd0ff'),4,4,(Math.random()-.5)*440,-30-Math.random()*220,(Math.random()-.5)*320);p.firstChild.style.animation=`rise ${5+Math.random()*5}s ${-Math.random()*9}s linear infinite`;w.append(p)}};
const st=DOM('style');st.textContent=ks+css+CAT;document.head.append(st);
const stage=DOM('div');stage.id='stage';stage.innerHTML='<div id="world"></div><div id="clip"><div class="bd"><div class="pp"><h4>Мои сборки</h4><div id="cn"></div></div></div></div><div id="fp"></div>';
document.body.prepend(stage);const W=stage.firstChild;let cur='';
window.sceneSet=id=>{const k={home:'home',settings:'home',inst:'inst',versions:'versions',cat:'cat',server:'server',host:'server',friends:'server'}[id]||'home';
const ins=(typeof cfg!=='undefined'&&cfg&&cfg.instances)||[];if(k=='inst')document.getElementById('cn').innerHTML=['Обычный профиль',...ins.map(i=>(i.icon?i.icon+' ':'')+i.name)].map(n=>`<div class="n">${n.replace(/[<&]/g,'')}</div>`).join('');
if(k==cur)return;cur=k;W.innerHTML='';W.className='s-'+k;const f=DOM('div','floor');W.append(f);(SHD[k]||[]).forEach(a=>W.append(shd(...a)));W.append(wall(),at(torch(1.5),-190,-175,-300),at(torch(1.5),190,-175,-300));S[k](W);(EX[k]||(()=>0))(W);dust(W);
document.getElementById('clip').style.display=document.getElementById('fp').style.display=k=='inst'?'block':'none'};
})();
