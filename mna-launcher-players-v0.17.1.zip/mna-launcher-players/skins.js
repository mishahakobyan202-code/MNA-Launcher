'use strict';
// Скины: разбор и проверка PNG, перевод старых 64x32 в 64x64, ресурспак для офлайн-игры, правка options.txt,
// загрузка скина в аккаунт Microsoft и получение скина по нику. Без Electron и без внешних модулей: проверяется обычным Node (test/skins.js).
const zlib = require('zlib');
const { crc32 } = require('./zip');

const SIG = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
const W = 64, MAX_PNG = 2 * 1048576, MOJANG_MAX = 24000;
const PACK_NAME = 'MNA-Skin.zip';
const DEFAULTS = ['alex', 'ari', 'efe', 'kai', 'makena', 'noor', 'steve', 'sunny', 'zuri'];

// ---------- PNG ----------
// Читает любой обычный PNG (без чересстрочности) в RGBA 8 бит. Всё проверяется: подписи, контрольные суммы, размер распаковки.
function decodePng(buf) {
  if (!Buffer.isBuffer(buf) || buf.length < 45 || !buf.subarray(0, 8).equals(SIG)) throw new Error('Это не PNG-файл');
  if (buf.length > MAX_PNG) throw new Error('Файл слишком большой для скина');
  let p = 8, ih = null, pal = null, trns = null, end = false; const idat = [];
  while (p + 12 <= buf.length) {
    const len = buf.readUInt32BE(p), type = buf.toString('latin1', p + 4, p + 8);
    if (len > buf.length - p - 12) throw new Error('PNG обрезан или повреждён');
    if (buf.readUInt32BE(p + 8 + len) !== crc32(buf.subarray(p + 4, p + 8 + len))) throw new Error('PNG повреждён (контрольная сумма блока ' + type + ')');
    const d = buf.subarray(p + 8, p + 8 + len);
    if (type === 'IHDR') { if (len !== 13 || ih) throw new Error('PNG повреждён (заголовок)'); ih = { w: d.readUInt32BE(0), h: d.readUInt32BE(4), depth: d[8], color: d[9], comp: d[10], filt: d[11], inter: d[12] }; }
    else if (!ih) throw new Error('PNG повреждён (нет заголовка)');
    else if (type === 'PLTE') pal = d; else if (type === 'tRNS') trns = d; else if (type === 'IDAT') idat.push(d);
    else if (type === 'IEND') { end = true; break; }
    p += 12 + len;
  }
  if (!ih || !end || !idat.length) throw new Error('PNG обрезан или повреждён');
  const okDepth = { 0: [1, 2, 4, 8, 16], 2: [8, 16], 3: [1, 2, 4, 8], 4: [8, 16], 6: [8, 16] }[ih.color];
  if (!okDepth || !okDepth.includes(ih.depth) || ih.comp || ih.filt) throw new Error('Такой вариант PNG не поддерживается: пересохрани скин как обычный PNG (RGBA)');
  if (ih.inter) throw new Error('Чересстрочный PNG не поддерживается: пересохрани скин без чересстрочности');
  if (!((ih.w === 64 && ih.h === 64) || (ih.w === 64 && ih.h === 32))) throw new Error(`Скин должен быть 64×64 пикселя (подходит и старый 64×32). У этого файла ${ih.w}×${ih.h}`);
  const ch = { 0: 1, 2: 3, 3: 1, 4: 2, 6: 4 }[ih.color], bpp = ch * ih.depth, rb = Math.ceil(ih.w * bpp / 8), stride = Math.max(1, bpp >> 3), want = ih.h * (rb + 1);
  let raw; try { raw = zlib.inflateSync(Buffer.concat(idat), { maxOutputLength: want + 64 }); } catch { throw new Error('PNG повреждён (не удалось распаковать)'); }
  if (raw.length !== want) throw new Error('PNG повреждён (неверный размер данных)');
  const px = Buffer.alloc(ih.h * rb);
  for (let y = 0; y < ih.h; y++) {
    const f = raw[y * (rb + 1)], src = raw.subarray(y * (rb + 1) + 1, (y + 1) * (rb + 1)), cur = px.subarray(y * rb, (y + 1) * rb), up = y ? px.subarray((y - 1) * rb, y * rb) : null;
    if (f > 4) throw new Error('PNG повреждён (фильтр строки)');
    for (let i = 0; i < rb; i++) {
      const a = i >= stride ? cur[i - stride] : 0, b = up ? up[i] : 0, c = up && i >= stride ? up[i - stride] : 0; let v = src[i];
      if (f === 1) v += a; else if (f === 2) v += b; else if (f === 3) v += (a + b) >> 1;
      else if (f === 4) { const pp = a + b - c, pa = Math.abs(pp - a), pb = Math.abs(pp - b), pc = Math.abs(pp - c); v += pa <= pb && pa <= pc ? a : pb <= pc ? b : c; }
      cur[i] = v & 255;
    }
  }
  const D = ih.depth, mx = (1 << Math.min(D, 8)) - 1;
  const rawS = (row, i) => D === 8 ? row[i] : D === 16 ? (row[i * 2] << 8) | row[i * 2 + 1] : (row[Math.floor(i * D / 8)] >> (8 - D * ((i % (8 / D)) + 1))) & mx;
  const to8 = v => D === 16 ? v >> 8 : D === 8 ? v : Math.round(v * 255 / mx);
  const key = n => (trns && trns.length >= n * 2 ? Array.from({ length: n }, (_, k) => trns.readUInt16BE(k * 2)) : null);
  const k0 = ih.color === 0 ? key(1) : null, k2 = ih.color === 2 ? key(3) : null;
  const out = Buffer.alloc(ih.w * ih.h * 4);
  for (let y = 0; y < ih.h; y++) {
    const row = px.subarray(y * rb, (y + 1) * rb);
    for (let x = 0; x < ih.w; x++) {
      const o = (y * ih.w + x) * 4; let r, g, b, a = 255;
      if (ih.color === 0) { const v = rawS(row, x); r = g = b = to8(v); if (k0 && v === k0[0]) a = 0; }
      else if (ih.color === 2) { const R = rawS(row, x * 3), G = rawS(row, x * 3 + 1), B = rawS(row, x * 3 + 2); r = to8(R); g = to8(G); b = to8(B); if (k2 && R === k2[0] && G === k2[1] && B === k2[2]) a = 0; }
      else if (ih.color === 3) { const i = rawS(row, x); if (!pal || i * 3 + 2 >= pal.length) throw new Error('PNG повреждён (палитра)'); r = pal[i * 3]; g = pal[i * 3 + 1]; b = pal[i * 3 + 2]; if (trns && i < trns.length) a = trns[i]; }
      else if (ih.color === 4) { r = g = b = to8(rawS(row, x * 2)); a = to8(rawS(row, x * 2 + 1)); }
      else { r = to8(rawS(row, x * 4)); g = to8(rawS(row, x * 4 + 1)); b = to8(rawS(row, x * 4 + 2)); a = to8(rawS(row, x * 4 + 3)); }
      out[o] = r; out[o + 1] = g; out[o + 2] = b; out[o + 3] = a;
    }
  }
  return { w: ih.w, h: ih.h, rgba: out };
}
function chunk(t, d) { const b = Buffer.concat([Buffer.from(t, 'latin1'), d]), o = Buffer.alloc(12 + d.length); o.writeUInt32BE(d.length, 0); b.copy(o, 4); o.writeUInt32BE(crc32(b), 8 + d.length); return o; }
function encodePng(w, h, rgba) {
  const raw = Buffer.alloc((w * 4 + 1) * h);
  for (let y = 0; y < h; y++) rgba.copy(raw, y * (w * 4 + 1) + 1, y * w * 4, (y + 1) * w * 4);
  const ih = Buffer.alloc(13); ih.writeUInt32BE(w, 0); ih.writeUInt32BE(h, 4); ih[8] = 8; ih[9] = 6;
  return Buffer.concat([SIG, chunk('IHDR', ih), chunk('IDAT', zlib.deflateSync(raw, { level: 9 })), chunk('IEND', Buffer.alloc(0))]);
}

// ---------- раскладка скина ----------
function blit(src, sx, sy, dst, dx, dy, w, h, flipX) {
  for (let r = 0; r < h; r++) for (let c = 0; c < w; c++) { const s = ((sy + r) * W + sx + c) * 4, d = ((dy + r) * W + dx + (flipX ? w - 1 - c : c)) * 4; src.copy(dst, d, s, s + 4); }
}
// Те же шаги, что делает сама игра с загруженными скинами: основной слой всегда непрозрачный.
function opaqueBase(rgba) {
  for (const [x0, y0, x1, y1] of [[0, 0, 32, 16], [0, 16, 64, 32], [16, 48, 48, 64]]) for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) rgba[(y * W + x) * 4 + 3] = 255;
  return rgba;
}
// Старый скин 64x32 → 64x64: левые руки и ноги получаются зеркальным копированием правых (как в игре).
function fromLegacy(src) {
  const out = Buffer.alloc(W * W * 4); src.copy(out, 0, 0, W * 32 * 4);
  let solid = true; for (let y = 0; y < 16 && solid; y++) for (let x = 32; x < 64; x++) if (out[(y * W + x) * 4 + 3] < 128) { solid = false; break; }
  if (solid) for (let y = 0; y < 16; y++) for (let x = 32; x < 64; x++) out[(y * W + x) * 4 + 3] = 0; // шапка нарисована сплошным фоном: её нет
  for (const [x, y, xo, yo, w, h] of [[4, 16, 16, 32, 4, 4], [8, 16, 16, 32, 4, 4], [0, 20, 24, 32, 4, 12], [4, 20, 16, 32, 4, 12], [8, 20, 8, 32, 4, 12], [12, 20, 16, 32, 4, 12],
    [44, 16, -8, 32, 4, 4], [48, 16, -8, 32, 4, 4], [40, 20, 0, 32, 4, 12], [44, 20, -8, 32, 4, 12], [48, 20, -16, 32, 4, 12], [52, 20, -8, 32, 4, 12]]) blit(out, x, y, out, x + xo, y + yo, w, h, true);
  return opaqueBase(out);
}
// Тонкие руки (Alex) занимают на 1 пиксель меньше у лица, затылка, плеча и ладони.
const ARM_ORIGINS = [[40, 16], [40, 32], [32, 48], [48, 48]];
const FACES = {
  classic: { top: [4, 0, 4, 4], bottom: [8, 0, 4, 4], outer: [0, 4, 4, 12], front: [4, 4, 4, 12], inner: [8, 4, 4, 12], back: [12, 4, 4, 12] },
  slim: { top: [4, 0, 3, 4], bottom: [7, 0, 3, 4], outer: [0, 4, 4, 12], front: [4, 4, 3, 12], inner: [7, 4, 4, 12], back: [11, 4, 3, 12] }
};
const COLMAP = { '3>4': [0, 1, 1, 2], '4>3': [0, 1, 3] };
// Меняет раскладку рук скина с одной модели на другую (чтобы скин выглядел правильно и на широкой, и на тонкой модели).
function arms(rgba, from, to) { // при from === to просто наводит порядок: пустые столбцы тонкой модели остаются пустыми
  const out = Buffer.from(rgba);
  for (const [ox, oy] of ARM_ORIGINS) {
    const faces = {};
    for (const [k, [fx, fy, fw, fh]] of Object.entries(FACES[from])) { const cols = []; for (let c = 0; c < fw; c++) { const col = []; for (let r = 0; r < fh; r++) { const s = ((oy + fy + r) * W + ox + fx + c) * 4; col.push(rgba.subarray(s, s + 4)); } cols.push(col); } faces[k] = cols; }
    for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) out.fill(0, ((oy + y) * W + ox + x) * 4, ((oy + y) * W + ox + x) * 4 + 4);
    for (const [k, [tx, ty, tw, th]] of Object.entries(FACES[to])) {
      const src = faces[k], map = src.length === tw ? [...Array(tw).keys()] : COLMAP[src.length + '>' + tw];
      for (let c = 0; c < tw; c++) for (let r = 0; r < th; r++) src[map[c]][r].copy(out, ((oy + ty + r) * W + ox + tx + c) * 4);
    }
  }
  return out;
}
// Тонкая модель оставляет два последних столбца руки пустыми. Если они пустые, скин «тонкий».
function detectSlim(rgba) {
  for (const [x0, y0, x1, y1] of [[54, 20, 56, 32], [46, 52, 48, 64]]) for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) if (rgba[(y * W + x) * 4 + 3] !== 0) return false;
  return true;
}
// Любой файл со скином → { png (64x64 RGBA), rgba, model }. Бросает понятную ошибку.
function normalize(buf) {
  const d = decodePng(buf), rgba = d.h === 32 ? fromLegacy(d.rgba) : d.rgba;
  return { rgba, png: encodePng(W, W, rgba), model: detectSlim(rgba) ? 'slim' : 'classic' };
}
const isModel = m => m === 'classic' || m === 'slim';

// ---------- ресурспак ----------
// Номер формата ресурспака по версии игры; 0 = версия неизвестна (до 1.6.1, снапшоты нестандартного вида).
const FMT = [[6, 1, 1], [9, 0, 2], [11, 0, 3], [13, 0, 4], [15, 0, 5], [16, 2, 6], [17, 0, 7], [18, 0, 8], [19, 0, 9], [19, 3, 12], [19, 4, 13], [20, 0, 15], [20, 2, 18], [20, 3, 22], [20, 5, 32], [21, 0, 34], [21, 2, 42], [21, 4, 46], [21, 5, 55], [21, 6, 63], [21, 7, 64], [21, 9, 69]];
function packFormat(mc) {
  const m = /^(\d+)\.(\d+)(?:\.(\d+))?/.exec(String(mc || '')); if (!m) return 0;
  const a = +m[1], b = +m[2], c = +(m[3] || 0);
  if (a >= 26) return 69; if (a !== 1) return 0;
  let f = 0; for (const [mi, pa, fm] of FMT) if (b > mi || (b === mi && c >= pa)) f = fm; return f;
}
const isLegacyNames = mc => { const m = /^1\.(\d+)/.exec(String(mc || '')); return !!m && +m[1] <= 12; };
const packId = mc => (isLegacyNames(mc) ? PACK_NAME : 'file/' + PACK_NAME);
function mcmeta(mc) {
  const f = packFormat(mc), pack = { description: 'MNA Launcher skin' };
  if (f >= 69) { pack.min_format = 69; pack.max_format = 999; } else pack.pack_format = f;
  return Buffer.from(JSON.stringify({ pack }));
}
// Детерминированный zip (дата 1980-01-01), чтобы можно было сравнить с уже лежащим файлом.
function zipBuffer(files) {
  const parts = [], cd = []; let off = 0;
  for (const [name, buf] of Object.entries(files)) {
    const nb = Buffer.from(name), crc = crc32(buf); let comp = zlib.deflateRawSync(buf, { level: 9 }), method = 8; if (comp.length >= buf.length) { comp = buf; method = 0; }
    const lh = Buffer.alloc(30); lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(0x800, 6); lh.writeUInt16LE(method, 8); lh.writeUInt16LE(0x21, 12); lh.writeUInt32LE(crc, 14); lh.writeUInt32LE(comp.length, 18); lh.writeUInt32LE(buf.length, 22); lh.writeUInt16LE(nb.length, 26);
    const c = Buffer.alloc(46); c.writeUInt32LE(0x02014b50, 0); c.writeUInt16LE(20, 4); c.writeUInt16LE(20, 6); c.writeUInt16LE(0x800, 8); c.writeUInt16LE(method, 10); c.writeUInt16LE(0x21, 14); c.writeUInt32LE(crc, 16); c.writeUInt32LE(comp.length, 20); c.writeUInt32LE(buf.length, 24); c.writeUInt16LE(nb.length, 28); c.writeUInt32LE(off, 42);
    parts.push(lh, nb, comp); cd.push(c, nb); off += 30 + nb.length + comp.length;
  }
  const dir = Buffer.concat(cd), e = Buffer.alloc(22), n = Object.keys(files).length;
  e.writeUInt32LE(0x06054b50, 0); e.writeUInt16LE(n, 8); e.writeUInt16LE(n, 10); e.writeUInt32LE(dir.length, 12); e.writeUInt32LE(off, 16);
  return Buffer.concat([...parts, dir, e]);
}
// Подменяем все «обычные» скины игры (Стив, Алекс и новые 1.19.3+) на скин игрока: в офлайне игра берёт один из них по UUID.
// В папке wide лежит скин с широкими руками, в slim с тонкими: какую бы модель ни выбрала игра, руки будут правильные.
function buildPack(rgba, model, mc) {
  if (!packFormat(mc)) throw new Error('для версии ' + mc + ' скин через ресурспак не поддерживается');
  const base = opaqueBase(Buffer.from(rgba)), wide = encodePng(W, W, arms(base, model, 'classic')), thin = encodePng(W, W, arms(base, model, 'slim')), T = 'assets/minecraft/textures/entity/';
  const files = { 'pack.mcmeta': mcmeta(mc), 'pack.png': model === 'slim' ? thin : wide, [T + 'steve.png']: wide, [T + 'alex.png']: thin };
  for (const n of DEFAULTS) { files[T + 'player/wide/' + n + '.png'] = wide; files[T + 'player/slim/' + n + '.png'] = thin; }
  return zipBuffer(files);
}

// Включает или выключает наш ресурспак в options.txt, не трогая остальное. Возвращает { text, changed }.
// «incompat»: для версий, где мы не уверены в номере формата, игра иначе выкинула бы пак как несовместимый.
function withPack(text, mc, on, incompat) {
  const id = packId(mc), both = [PACK_NAME, 'file/' + PACK_NAME], src = String(text || ''), eol = src.includes('\r\n') ? '\r\n' : '\n';
  const lines = src === '' ? [] : src.split(/\r?\n/); if (lines.length && lines[lines.length - 1] === '') lines.pop();
  const edit = (key, fn, make, seed) => {
    const i = lines.findIndex(l => l.startsWith(key + ':')); let list = i < 0 && seed ? seed : [];
    if (i >= 0) { try { const v = JSON.parse(lines[i].slice(key.length + 1)); if (Array.isArray(v)) list = v.filter(x => typeof x === 'string'); } catch {} }
    const line = key + ':' + JSON.stringify(fn(list.filter(x => !both.includes(x)))); // наш пак всегда последний: у него высший приоритет
    if (i >= 0) lines[i] = line; else if (make) lines.push(line);
  };
  edit('resourcePacks', rest => (on ? [...rest, id] : rest), on, isLegacyNames(mc) ? null : ['vanilla']);
  edit('incompatibleResourcePacks', rest => (on && incompat ? [...rest, id] : rest), on && incompat);
  const out = lines.join(eol) + (lines.length ? eol : '');
  return { text: out, changed: out !== src };
}
// Если options.txt нет, а скин выключен, писать нечего.
function optionsFor(text, mc, on, incompat) {
  if (!on && !text) return { text: '', changed: false };
  return withPack(text, mc, on, incompat);
}

// ---------- Mojang ----------
// Загрузка скина в аккаунт Microsoft (его потом видят все игроки на серверах с лицензией).
async function uploadSkin(png, model, token, base, f) {
  if (!token) throw new Error('Нужен вход через Microsoft (Настройки)');
  if (png.length > MOJANG_MAX) throw new Error('Mojang принимает скины до 24 КБ, а этот весит ' + Math.ceil(png.length / 1024) + ' КБ');
  const fd = new FormData(); fd.append('variant', model === 'slim' ? 'slim' : 'classic'); fd.append('file', new Blob([png], { type: 'image/png' }), 'skin.png');
  let r; try { r = await (f || fetch)((base || 'https://api.minecraftservices.com') + '/minecraft/profile/skins', { method: 'POST', headers: { Authorization: 'Bearer ' + token }, body: fd, signal: AbortSignal.timeout(30000) }); }
  catch { throw new Error('нет соединения с Mojang'); }
  if (r.status === 401 || r.status === 403) throw new Error('Вход через Microsoft устарел: выйди и войди снова в Настройках');
  if (r.status === 429) throw new Error('Mojang просит подождать: скин меняют слишком часто');
  if (!r.ok) throw new Error('Mojang не принял скин (HTTP ' + r.status + ')');
  return true;
}
// Из ответа sessionserver достаём ссылку на скин и модель. Принимаем только textures.minecraft.net.
function texturesOf(profile) {
  const p = ((profile && profile.properties) || []).find(x => x && x.name === 'textures'); if (!p || typeof p.value !== 'string') return null;
  let t; try { t = JSON.parse(Buffer.from(p.value, 'base64').toString('utf8')); } catch { return null; }
  const s = t && t.textures && t.textures.SKIN; if (!s || typeof s.url !== 'string') return null;
  let u; try { u = new URL(s.url); } catch { return null; }
  if (u.protocol !== 'https:' && u.protocol !== 'http:') return null;
  if (u.hostname !== 'textures.minecraft.net') return null;
  return { url: 'https://textures.minecraft.net' + u.pathname, model: s.metadata && s.metadata.model === 'slim' ? 'slim' : 'classic' };
}
const NICK_RE = /^[A-Za-z0-9_]{1,16}$/;
// Скин любого лицензионного игрока по нику. net = { getJson, getBuffer }; hosts можно подменить в тестах.
async function skinByNick(nick, net, hosts) {
  nick = String(nick || '').trim(); if (!NICK_RE.test(nick)) throw new Error('Ник: латиница, цифры и _, до 16 символов');
  const H = hosts || { lookup: 'https://api.minecraftservices.com/minecraft/profile/lookup/name/', session: 'https://sessionserver.mojang.com/session/minecraft/profile/', tex: '' };
  let prof; try { prof = await net.getJson(H.lookup + encodeURIComponent(nick)); } catch (e) { throw new Error(/HTTP 404|HTTP 204/.test(e.message) ? 'Игрок «' + nick + '» не найден: скины берутся только у лицензионных ников' : /HTTP 429/.test(e.message) ? 'Mojang просит подождать, попробуй через минуту' : e.message); }
  if (!prof || !/^[0-9a-f]{32}$/i.test(prof.id || '')) throw new Error('Игрок «' + nick + '» не найден');
  let sess; try { sess = await net.getJson(H.session + prof.id); } catch (e) { throw new Error(/HTTP 429/.test(e.message) ? 'Mojang просит подождать, попробуй через минуту' : e.message); }
  const t = texturesOf(sess); if (!t) throw new Error('У игрока «' + prof.name + '» нет своего скина');
  const url = H.tex ? H.tex + new URL(t.url).pathname : t.url;
  const buf = await net.getBuffer(url, MAX_PNG), n = normalize(buf);
  return { name: String(prof.name || nick).slice(0, 16), png: n.png, rgba: n.rgba, model: t.model };
}

module.exports = { decodePng, encodePng, normalize, fromLegacy, arms, detectSlim, opaqueBase, isModel, packFormat, packId, isLegacyNames, mcmeta, zipBuffer, buildPack, withPack, optionsFor, uploadSkin, texturesOf, skinByNick, PACK_NAME, DEFAULTS, MOJANG_MAX, MAX_PNG, NICK_RE };
